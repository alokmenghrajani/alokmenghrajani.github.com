#!/usr/bin/ruby

require 'sdl'
require 'maze.rb'
require 'player.rb'

# constants 
$screen_w = 640
$screen_h = 480
$wall = 0.5

$pi = 3.141592654
$twopi = 2*$pi

$fov = 60.0 * $pi / 180.0 # in radians

# functions
def drawVerticalLine(screen, x, y1, y2, color)
#  if y1<y2
#    y1.upto(y2) {|y|
#      screen.putPixel(x+$screen_w/2, y+$screen_h/2, color)
#    }
#  else
#    y2.upto(y1) {|y|
#      screen.putPixel(x+$screen_w/2, y+$screen_h/2, color)
#    }
#  end
  screen.fillRect(x+$screen_w/2, y1+$screen_h/2, 1, y2-y1, color)
end

def drawScreen(screen, maze, player)
  # let's cast rays
  blue=screen.format.mapRGB(0, 0, 0xff)
  green=screen.format.mapRGB(0, 0x50, 0x0)

  d1=$screen_w / 2 / Math.tan($fov/2)
  
  screen.fillRect(0, 0, $screen_w, $screen_h, 0)
  for w in (-$screen_w/2..$screen_w/2)
    ang = Math.atan2(w, d1)
    a = (ang+player.pos_a) % $twopi
    ray = maze.rayCast(player.pos_x, player.pos_y, a)
    d2 = ray[0]

    # fish eye correction
    d2 = d2 * Math.cos(ang)

    x = $wall * d1 / d2
    if x < 0
      x = 0
    end
    if x > $screen_h
      x = $screen_h
    end

    # fog of war
    color = ray[1]
    c = Array.new(3)
    for i in (0..2)
      c[i]=color[i]*2/d2
      if c[i] > color[i]
        c[i] = color[i]
      end
    end
    fog=screen.format.mapRGB(c[0], c[1], c[2])
    drawVerticalLine(screen, w, -(x/2).floor, (x/2).floor, fog)

    # floor effect
#    oldn=(x/2).floor
#    while oldn<($screen_h/2)
#      newn = oldn+2
#      m = $wall * d1 / 2 / oldn/Math.cos(ang)
#      c = 255*2/m
#      if c>255
#        c=255
#        newn = $screen_h/2
#      end
#      drawVerticalLine(screen, w, oldn, newn, screen.format.mapRGB(c, c, c))
#      oldn = newn
#    end

  end
  screen.flip
end


# Main
SDL.init( SDL::INIT_VIDEO )
screen = SDL::setVideoMode($screen_w, $screen_h, 32, SDL::SWSURFACE)

event=SDL::Event.new
SDL::Key.enable_key_repeat(100, 100)

maze = Maze.new(25)
player = Player.new(maze)


# calculate your distance to screen
# tan(fov/2)=screen_w/2 / screen_d
#screen_d = $screen_w / 2 / Math.tan($fov/2)
#puts screen_d

drawScreen(screen, maze, player)

mousex = -1
ignore = 1
SDL::Mouse.hide

while true
  if  event.poll != 0 then
    if event.type==SDL::Event::QUIT then
      break
    end
    if event.type==SDL::Event::KEYDOWN then
      exit if event.keySym==SDL::Key::ESCAPE
    end

    if event.type==SDL::Event::KEYDOWN then
      if event.keySym==SDL::Key::LEFT
        player.turnLeft
      end

      if event.keySym==SDL::Key::RIGHT
	player.turnRight
      end

      if event.keySym==SDL::Key::P
        player.debug
      end
      drawScreen(screen, maze, player)
    end
  end

  if SDL::Mouse.state[2]
    player.moveForward
    drawScreen(screen, maze, player)
  end

  if SDL::Mouse.state[4]
    player.moveBackward
    drawScreen(screen, maze, player)
  end

  mx = SDL::Mouse.state[0]
  if ignore==1
    mousex = mx
    ignore=0
  else
    d = mx-mousex
    if d>5
      player.turnRight
      drawScreen(screen, maze, player)
      mousex = mx
      ignore=1
      SDL::Mouse.warp($screen_w/2, $screen_h/2)
    elsif d<-5
      player.turnLeft
      drawScreen(screen, maze, player)
      mousex = mx
      ignore=1
      SDL::Mouse.warp($screen_w/2, $screen_h/2)
    end
  end

end
