
#todo: optimize sin/cos with lookups

class Player
  @pos_x #position in maze
  @pos_y #position in maze
  @pos_a #position angle
  @pos_h #player height

  @maze

  def initialize(maze)
    @maze = maze
    
    @pos_x = 1.5
    @pos_y = 1.5
    @pos_a = 90 * $pi / 180.0
    @pos_h = 1.0
  end

  def pos_a
    return @pos_a
  end

  def pos_x
    return @pos_x
  end

  def pos_y
    return @pos_y
  end

  def turnLeft
    @pos_a = @pos_a - (5 * $pi / 180)
    @pos_a = @pos_a % $twopi
  end

  def turnRight
    @pos_a = @pos_a + (5.0 * $pi / 180.0)
    @pos_a = @pos_a % $twopi
  end

  def moveForward
    speed = 0.2

    # we can only move forward if there is no wall
    # so we can use rayCast to check if there is any wall...
    ray = @maze.rayCast(@pos_x, @pos_y, @pos_a)
    if ray[0] > speed
       @pos_x = @pos_x + speed * Math.sin(@pos_a)
       @pos_y = @pos_y - speed * Math.cos(@pos_a)
    end
  end

  def moveBackward
    # sin(pos_a)=dh/speed
    speed = 0.2

    a = (@pos_a + $pi) % $twopi
    ray = @maze.rayCast(@pos_x, @pos_y, a)
    if ray[0] > speed
      @pos_x = @pos_x - speed * Math.sin(@pos_a)
      @pos_y = @pos_y + speed * Math.cos(@pos_a)
    end
  end

  
  def debug
    puts "Position: (" + @pos_x.to_s + ", " + @pos_y.to_s + ")"
    puts "Angle: " + (@pos_a * 180.0 / $pi).to_s
    puts @maze.rayCast(@pos_x, @pos_y, @pos_a)
  end

end
