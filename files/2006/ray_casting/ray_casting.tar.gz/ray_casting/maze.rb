class Maze
  @@simple_maze = [ 1, 2, 2, 2, 2, 2, 2, 2, 2, 1,
                    1, 0, 0, 0, 0, 0, 1, 0, 0, 3,
                    1, 0, 0, 0, 0, 1, 1, 1, 0, 3,
                    1, 1, 1, 1, 0, 1, 0, 0, 0, 3,
                    1, 0, 0, 1, 0, 0, 0, 0, 0, 3,
                    1, 0, 0, 0, 0, 0, 4, 4, 0, 3,
                    1, 0, 0, 4, 4, 4, 4, 0, 0, 3,
                    1, 0, 0, 0, 0, 0, 4, 0, 0, 3, 
                    1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 
                    1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

  @maze
  @height
  @width
  @colors

  def initialize(size)
    @maze = @@simple_maze
    @height = 10
    @width = 10

    @colors = [[0, 0, 255], [0, 255, 0], [255, 0, 0], [0, 128, 128]]

    # todo: generate random maze
  end

  def maze
    @maze
  end
  
  def height
    @height
  end

  def width
    @width
  end

  def grid(x, y)
    if (x<0) || (x>=@width) || (y<0) || (y>=@height)
      return 1 # doesn't really matter, this case will be discarded by
               # opposite rayCast
    end
    return @maze[x+y*@width]
  end
  
  # rayCasting method
  # returns the distance to the closest wall from (x,y) when looking in direction a
  def rayCast(x, y, a)
    # lets find the next horz intersection
    r1 = rayCastHorz(x, y, a)
    r2 = rayCastVert(x, y, a)
    if r1[0]<r2[0]
      return r1
    else
      return r2
    end
  end

  # rayCasting method for horz grid
  def rayCastHorz(x, y, a)
    nx=0
    ny=0

    if a<$pi/2 || a>$pi*3/2
      tana = Math.tan(a)
      fx = x + (y - y.floor) * tana
      fy = y.floor
      
      nx = tana
      ny = -1
    else
      tana = -Math.tan(a)
      fx = x + (1 - y + y.floor) * tana
      fy = 1 + y.floor

      nx = tana
      ny = 1
    end

    d=10000
    while true
      if fx.floor < 0.to_f || fx.floor > width.to_f
        return [d, @colors[0]]
      end
      if fy.floor < 0 || fy.floor > height
        return [d, @colors[0]]
      end
      if grid(fx.floor, fy.floor)!=0
        dx = fx-x
        dy = fy-y
        d = Math.sqrt(dx*dx+dy*dy)
        return [d, @colors[grid(fx.floor, fy.floor)-1]]
      end
      if grid(fx.floor, fy.floor-1)!=0
        dx = fx-x
        dy = fy-y
        d = Math.sqrt(dx*dx+dy*dy)
        return [d, @colors[grid(fx.floor, fy.floor-1)-1]]
      end
      fx = fx+nx
      fy = fy+ny
    end
  end

  # rayCasting method for vert grid
  def rayCastVert(x, y, a)
    nx=0
    ny=0

    if a<$pi
      tana = Math.tan($pi/2-a)
      fy = y - (1 - x + x.floor) * tana
      fx = 1 + x.floor
      
      ny = -tana
      nx = 1
    else
      tana = Math.tan(3*$pi/2-a)
      fy = y + (x - x.floor) * tana
      fx = x.floor

      ny = tana
      nx = -1
    end

    d=10000
    while true
      if fx.floor < 0.to_f || fx.floor > width.to_f
        return [d, @colors[0]]
      end
      if fy.floor < 0 || fy.floor > height
        return [d, @colors[0]]
      end
      if grid(fx.floor, fy.floor)!=0
        dx = fx-x
        dy = fy-y
        d = Math.sqrt(dx*dx+dy*dy)
        return [d, @colors[grid(fx.floor, fy.floor)-1]]
      end
      if grid(fx.floor-1, fy.floor)!=0
        dx = fx-x
        dy = fy-y
        d = Math.sqrt(dx*dx+dy*dy)
        return [d, @colors[grid(fx.floor-1, fy.floor)-1]]
      end
      fx = fx+nx
      fy = fy+ny
    end
  end

end
