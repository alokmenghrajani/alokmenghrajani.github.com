(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file is used to translate a Tree.stm into a list of          *)
(*              Assem.instr. The resulting assembly can be compiled with nasm.    *)


module A = Assem
module T = Tree

let codegen (stm:T.stm) : A.instr list =

  (* our instruction list *)
  let ilist = ref ([]:A.instr list) in

  (* emit adds x to the begining of ilist *)
  let emit x = ilist := x::!ilist in

  (* result gets a new temporary  t  and passes it to gen.  gen should emit the
     assembly language commands necessary to calculate the value that belongs
     in  t  and store that value there.  result then returns  t  so that
     it can be accessed by the calling function. *)
  let result gen:Temp.temp = let t = Temp.newtemp() in gen t; t in

  let rec munchStm stm =
    let munch_op op =
       match op with
         T.EQ -> "je"
       | T.NE -> "jne"
       | T.LT -> "jl"
       | T.LE -> "jle"
       | T.GT -> "jg"
       | T.GE -> "jge"
    in
    match stm with
      T.MOVE(T.TEMP i, e1)->
        (* load from temporary t1 to register %eax *)
        let r1 = {A.assem="mov   eax, 's0\n";
                  A.src=[munchExp e1];
                  A.dst=[]} in
        (* store from register %eax to temporary i *)
        let r2 = {A.assem="mov    'd0, eax\n";
                  A.src=[];
                  A.dst=[i]} in
        emit(A.OPER r1);
        emit(A.OPER r2)
    | T.SEQ(a, b) -> (munchStm a; munchStm b)
    | T.NIL -> ()
    | T.JUMP(a) -> let r1 = {A.assem="jmp    L" ^ (string_of_int a) ^ "\n";
                             A.src=[];
                             A.dst=[]} in
                   emit(A.OPER r1)
    | T.CJUMP(op, e1, e2, l1, l2) -> let r1 = {A.assem="mov   eax, 's0\n";
                                               A.src=[munchExp e1];
                                               A.dst=[]} in
                                     let r2 = {A.assem="mov   edx, 's0\n";
                                               A.src=[munchExp e2];
                                               A.dst=[]} in
                                     let r3 = {A.assem="cmp    eax, edx\n";
                                               A.src=[]; A.dst=[]} in
                                     let r4 = {A.assem=munch_op(op) ^ "    L" ^ (string_of_int l1) ^ "\n";
                                               A.src=[]; A.dst=[]} in
                                     let r5 = {A.assem="jmp    L" ^ (string_of_int l2) ^ "\n";
                                               A.src=[]; A.dst=[]} in
                                     emit(A.OPER r1);
                                     emit(A.OPER r2);
                                     emit(A.OPER r3);
                                     emit(A.OPER r4);
                                     emit(A.OPER r5)
    | T.LABEL(a) -> emit(A.LABEL a)
    | T.EXP(e) -> let r1 = {A.assem="mov   eax, 's0\n";
                            A.src=[munchExp e];
                            A.dst=[]} in
                  emit(A.OPER r1)
    | T.WRITEINT(e) -> let r1 = {A.assem="mov    eax, 's0\n";
                                 A.src=[munchExp e];
                                 A.dst=[]} in
                       let r2 = {A.assem="push    eax\n";
                                 A.src=[]; A.dst=[]} in
                       let r3 = {A.assem="call write_int\n";
		                 A.src=[]; A.dst=[]} in
                       let r4 = {A.assem="pop    eax\n";
		                 A.src=[]; A.dst=[]} in
                       emit(A.OPER r1);
                       emit(A.OPER r2);
                       emit(A.OPER r3);
                       emit(A.OPER r4)
    | _ -> assert false

  and munchExp exp =
    match exp with
      T.BINOP(T.PLUS, e1, e2) ->
        result(fun r ->
	  let r1 = {A.assem="mov     eax, 's0\n";
                    A.src=[munchExp e1];
                    A.dst=[]} in
          let r2 = {A.assem="mov     ecx, 's0\n";
                    A.src=[munchExp e2];
                    A.dst=[]} in
          let r3 = {A.assem="add     eax, ecx\n";
                    A.src=[];
                    A.dst=[]} in
          let r4 = {A.assem="mov    'd0, eax\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
          emit(A.OPER r2);
          emit(A.OPER r3);
          emit(A.OPER r4))
    | T.BINOP(T.MINUS, e1, e2) ->
        result(fun r ->
          let r1 = {A.assem="mov    eax, 's0\n";
                    A.src=[munchExp e1];
                    A.dst=[]} in
          let r2 = {A.assem="mov    ecx, 's0\n";
                    A.src=[munchExp e2];
                    A.dst=[]} in
          let r3 = {A.assem="sub    eax, ecx\n";
                    A.src=[];
                    A.dst=[]} in
          let r4 = {A.assem="mov    'd0, eax\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
          emit(A.OPER r2);
          emit(A.OPER r3);
          emit(A.OPER r4))
    | T.BINOP(T.MUL, e1, e2) ->
        result(fun r -> 
          let r1 = {A.assem="mov    eax, 's0\n";
                    A.src=[munchExp e1];
                    A.dst=[]} in
          let r2 = {A.assem="mov    ecx, 's0\n";
                    A.src=[munchExp e2];
                    A.dst=[]} in
          let r3 = {A.assem="imul   ecx\n";
                    A.src=[];
                    A.dst=[]} in
          let r4 = {A.assem="mov    'd0, eax\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
          emit(A.OPER r2);
          emit(A.OPER r3);
          emit(A.OPER r4))
    | T.BINOP(T.DIV, e1, e2) ->
        result(fun r -> 
          let r1 = {A.assem="mov    eax, 's0\n";
                    A.src=[munchExp e1];
                    A.dst=[]} in
	  let r2 = {A.assem="mov    edx, 0\n";
                    A.src=[];
                    A.dst=[]} in
          let r3 = {A.assem="mov    ecx, 's0\n";
                    A.src=[munchExp e2];
                    A.dst=[]} in
          let r4 = {A.assem="idiv   ecx\n";
                    A.src=[];
                    A.dst=[]} in
          let r5 = {A.assem="mov    'd0, eax\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
	  emit(A.OPER r2);
          emit(A.OPER r3);
          emit(A.OPER r4);
          emit(A.OPER r5))
    | T.BINOP(T.MOD, e1, e2) ->
        result(fun r -> 
          let r1 = {A.assem="mov    eax, 's0\n";
                    A.src=[munchExp e1];
                    A.dst=[]} in
	  let r2 = {A.assem="mov    edx, 0\n";
                    A.src=[];
                    A.dst=[]} in
          let r3 = {A.assem="mov    ecx, 's0\n";
                    A.src=[munchExp e2];
                    A.dst=[]} in
          let r4 = {A.assem="idiv   ecx\n";
                    A.src=[];
                    A.dst=[]} in
          let r5 = {A.assem="mov    'd0, edx\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
          emit(A.OPER r2);
          emit(A.OPER r3);
          emit(A.OPER r4);
          emit(A.OPER r5))
    | T.CONST i ->
        result(fun r ->
          let r1 = {A.assem="mov    eax, "^(Int32.to_string i)^"\n";
                    A.src=[];
                    A.dst=[]} in
          let r2 = {A.assem="mov    'd0, eax\n";
                    A.src=[];
                    A.dst=[r]} in
          emit(A.OPER r1);
          emit(A.OPER r2))
    | T.TEMP t -> t
in
  munchStm stm;
  List.rev(!ilist)
;;
