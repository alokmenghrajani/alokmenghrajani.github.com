(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file contains the definition of the intermediate             *)
(*              representation trees, created by Translate.translate and used by  *)
(*              Munch.codegen.                                                    *)
(*                                                                                *)
(* X-reference: translate.ml, munch.ml                                            *)


type when_to_do = PRE | POST

and exp  = CONST of int32
          | TEMP of Temp.temp
          | BINOP of binop * exp * exp
          | ESEQ of stm * exp * when_to_do

and  stm  = MOVE of exp * exp
          | NIL
          | SEQ of stm * stm
          | JUMP of Label.label
          | CJUMP of relop * exp * exp * Label.label * Label.label
          | EXP of exp
          | LABEL of Label.label
          | WRITEINT of exp

and binop = PLUS | MINUS | MUL | DIV | MOD | AND | OR | XOR

and relop = EQ | NE | LT | GT | LE | GE;;
