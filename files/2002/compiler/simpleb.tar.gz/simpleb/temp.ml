(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file contains the functions which keep track of the          *)
(*              temporary variables. Each variable is just an integer, and the    *)
(*              counter keeps track of the number of variables already assigned.  *)
(*              The function makestring turns a temporary variable (integer) into *)
(*              a machine specific stack slot.                                    *)
(*              Note: this is not a very good seperation of generic compiliation  *)
(*              and machine specific code.                                        *)
(*                                                                                *)
(* X-reference: assem.ml                                                          *)


type temp = int;;

let start_value:temp = 0;;
let counter = ref start_value;;

let numtemps () = !counter;;

let newtemp () =
  counter := !counter + 1;
  !counter;;

let makestring t =
  " [ebp-"^string_of_int (t*4)^"]";;

