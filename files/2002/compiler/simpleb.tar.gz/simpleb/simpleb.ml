(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this is the main for simpleb                                      *)


let infile = ref None
let outfile = ref None

exception Option
let getopt s = match s with Some foo -> foo | None -> raise Option

let dotme s=
  let expected_name = Str.global_replace (Str.regexp "\\.sim$") ".s" s in
  if compare s expected_name == 0 then s ^ ".s" else expected_name

let setout s =
  match (!outfile) with
  None -> outfile := Some (dotme s)
| Some _ -> ()

let main () =
  Arg.parse [("-o",
	      Arg.String (fun s -> outfile := Some s),
	      "ASSEMBLYFILE")] 
    (fun s -> infile := Some s; setout s)
    "Usage: ./simc [-o ASSEMBLYFILE] SOURCEFILE";
  try
    let infile = getopt (!infile) in
    let outfile = getopt (!outfile) in
    let ic = open_in infile in
    let _ = Errormsg.startFile infile in
    let lexbuf = Lexing.from_channel ic in
    let absyntree =
      (try
        Grammar.program Lexer.token lexbuf
      with
        Parsing.Parse_error -> 
          Errormsg.error (Lexing.lexeme_start lexbuf,
			  Lexing.lexeme_end lexbuf)
	    "syntax eror here"; exit (-1)) in
    let _ = Absyn.print_program absyntree in  
    let irtree = Translate.translate absyntree in
    let _ = print_string("IR:\n") in   
    let _ = Print_debug.print_ir_stmt irtree in  
    let canon = Canon.linearize irtree in
    let _ = print_string("\nCANON:\n") in  
    let _ = Print_debug.print_canon_ir canon in  
    let _ = print_string("\n") in
    let assems = List.flatten (List.map Munch.codegen canon) in
    let code = Assem.format_all Temp.makestring assems in
    let code = Generate.gen code (Temp.numtemps()) in
    let oc = open_out outfile in
    output_string oc code;  
    close_in ic;
    close_out oc
      
  with
    Lexer.Error _ -> exit(-1)
  | Sys_error(s) -> Printf.eprintf "I/O error: %s\n" s; exit(-1)
  | Translate.Error(s) -> exit(-1)
  | Option -> Printf.eprintf "Error: require source file:\nUsage: ./simc SOURCEFILE\n"
;;
 main ()
