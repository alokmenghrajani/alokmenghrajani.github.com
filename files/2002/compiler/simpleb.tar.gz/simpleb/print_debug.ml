(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)



module T = Tree

let rec print_canon_ir p =
   match p with
     head::tail -> print_ir_stmt head;
                   print_canon_ir tail;
   | _ -> ()
and print_ir_stmt ir =
   let print_op op =
     match op with
       T.EQ -> print_string "EQ "
     | T.NE -> print_string "NE "
     | T.LT -> print_string "LT"
     | T.LE -> print_string "LE"
     | T.GT -> print_string "GT"
     | T.GE -> print_string "GE"
   in
   match ir with
     T.MOVE(e1, e2) -> print_string("MOVE "); print_ir_exp e1 ; print_string " <- "; print_ir_exp e2; print_string("\n");
   | T.NIL -> print_string "NIL "
   | T.SEQ(st1, st2) -> print_string "SEQ "; print_ir_stmt st1; print_string ", "; print_ir_stmt st2
   | T.JUMP l -> print_string "JUMP "; print_int l
   | T.CJUMP(relop, e1, e2, l1, l2) -> print_string "CJUMP "; print_ir_exp e1; print_op relop;
                                       print_ir_exp e2; print_string "Labels: "; print_int l1;
                                       print_int l2
   | T.EXP e -> print_string "EXP "; print_ir_exp e
   | T.LABEL l -> print_string "Label: "; print_int l
   | T.WRITEINT e -> print_string "Writeint "; print_ir_exp e

and print_ir_exp ex =
   let print_op op =
      match op with
        T.PLUS -> print_string "+"
      | T.MINUS -> print_string "-"
      | T.MUL -> print_string "*"
      | T.DIV -> print_string "/"
      | T.MOD -> print_string " % "
      | T.AND -> print_string "&&"
      | T.OR -> print_string "||"
      | T.XOR -> print_string "^"
   in
   let print_when w =
     match w with
       T.PRE -> print_string "PRE"
     | T.POST -> print_string "POST"
   in
   match ex with
     T.CONST c -> print_string "CONST "; print_string(Int32.to_string c)
   | T.TEMP t -> print_string "TEMP "; print_int t; print_string(" ")
   | T.BINOP(b, e1, e2) -> print_string "BINOP "; print_op b; print_ir_exp e1; print_ir_exp e2
   | T.ESEQ(s, e, w) -> print_string "ESEQ "; print_ir_stmt s; print_ir_exp e; print_when w
;;
