type token =
  | ID of (Symbol.symbol)
  | INTCONST of (int32)
  | BREAK
  | CONTINUE
  | ELSE
  | FALSE
  | FOR
  | IF
  | INT
  | TRUE
  | WHILE
  | WRITEINT
  | NOT
  | AND
  | OR
  | XOR
  | EQ
  | NE
  | LT
  | LE
  | GT
  | GE
  | COMMA
  | PLUSPLUS
  | MINUSMINUS
  | LBRACE
  | RBRACE
  | LPAREN
  | RPAREN
  | SEMICOL
  | PLUS
  | MINUS
  | TIMES
  | DIVIDE
  | ASSIGN
  | EOF
  | MOD
  | NEG
  | PLUSASSIGN
  | MINUSASSIGN
  | TIMESASSIGN
  | DIVIDEASSIGN
  | MODASSIGN

open Parsing;;
let _ = parse_error;;
# 2 "grammar.mly"
(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file is used by ocamlyacc to create grammar.ml, which        *)
(*              contains the function "Program". Grammar.program takes a lexical  *)
(*              buffer (created by Lexing.from_channel) and constructs an         *)
(*              abstract syntax tree (Absyn.program). If the token stream fails   *)
(*              to match an expected case, parse_error is called and the          *)
(*              exception Parsing.Parse_error is raised.                          *)
(*                                                                                *)
(* X-Reference: absyn.ml, lexer.mll, simpleb.ml (the main program)                *)


module A = Absyn
module E = Errormsg

let parse_error s =
  E.error (symbol_end () + 1, symbol_end() + 1) s

let context l r :A.pos = (rhs_start l, rhs_end r - 1)

# 80 "grammar.ml"
let yytransl_const = [|
  259 (* BREAK *);
  260 (* CONTINUE *);
  261 (* ELSE *);
  262 (* FALSE *);
  263 (* FOR *);
  264 (* IF *);
  265 (* INT *);
  266 (* TRUE *);
  267 (* WHILE *);
  268 (* WRITEINT *);
  269 (* NOT *);
  270 (* AND *);
  271 (* OR *);
  272 (* XOR *);
  273 (* EQ *);
  274 (* NE *);
  275 (* LT *);
  276 (* LE *);
  277 (* GT *);
  278 (* GE *);
  279 (* COMMA *);
  280 (* PLUSPLUS *);
  281 (* MINUSMINUS *);
  282 (* LBRACE *);
  283 (* RBRACE *);
  284 (* LPAREN *);
  285 (* RPAREN *);
  286 (* SEMICOL *);
  287 (* PLUS *);
  288 (* MINUS *);
  289 (* TIMES *);
  290 (* DIVIDE *);
  291 (* ASSIGN *);
    0 (* EOF *);
  292 (* MOD *);
  293 (* NEG *);
  294 (* PLUSASSIGN *);
  295 (* MINUSASSIGN *);
  296 (* TIMESASSIGN *);
  297 (* DIVIDEASSIGN *);
  298 (* MODASSIGN *);
    0|]

let yytransl_block = [|
  257 (* ID *);
  258 (* INTCONST *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\004\000\005\000\005\000\003\000\003\000\
\006\000\006\000\007\000\007\000\010\000\010\000\009\000\009\000\
\009\000\009\000\009\000\009\000\009\000\009\000\009\000\009\000\
\009\000\009\000\009\000\008\000\008\000\008\000\008\000\013\000\
\013\000\011\000\011\000\011\000\011\000\011\000\011\000\011\000\
\011\000\011\000\011\000\014\000\014\000\014\000\014\000\012\000\
\012\000\012\000\012\000\012\000\012\000\012\000\012\000\015\000\
\015\000\015\000\015\000\015\000\015\000\000\000"

let yylen = "\002\000\
\005\000\000\000\002\000\003\000\001\000\003\000\000\000\002\000\
\002\000\001\000\000\000\002\000\000\000\003\000\003\000\003\000\
\003\000\003\000\003\000\003\000\002\000\002\000\002\000\002\000\
\001\000\001\000\002\000\005\000\007\000\005\000\011\000\001\000\
\003\000\001\000\001\000\001\000\002\000\003\000\003\000\003\000\
\003\000\003\000\003\000\002\000\002\000\002\000\002\000\001\000\
\001\000\002\000\003\000\003\000\003\000\003\000\003\000\001\000\
\001\000\001\000\001\000\001\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\062\000\000\000\000\000\000\000\000\000\
\000\000\000\000\025\000\026\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\010\000\000\000\003\000\
\000\000\004\000\022\000\024\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\034\000\000\000\
\000\000\000\000\000\000\000\000\036\000\021\000\023\000\000\000\
\008\000\009\000\000\000\012\000\006\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\049\000\048\000\000\000\000\000\
\000\000\000\000\000\000\045\000\047\000\044\000\046\000\000\000\
\037\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\
\000\000\050\000\000\000\000\000\056\000\057\000\058\000\059\000\
\060\000\061\000\000\000\000\000\000\000\000\000\000\000\000\000\
\043\000\000\000\000\000\039\000\038\000\042\000\014\000\000\000\
\055\000\000\000\051\000\000\000\000\000\000\000\032\000\000\000\
\030\000\000\000\000\000\000\000\000\000\033\000\029\000\000\000\
\000\000\000\000\031\000"

let yydgoto = "\002\000\
\004\000\006\000\019\000\007\000\009\000\111\000\021\000\022\000\
\023\000\052\000\065\000\066\000\112\000\045\000\091\000"

let yysindex = "\012\000\
\247\254\000\000\026\255\000\000\049\255\132\255\026\255\031\255\
\030\255\200\255\000\000\000\000\050\255\055\255\071\255\009\255\
\102\255\128\255\111\255\132\255\112\255\000\000\118\255\000\000\
\049\255\000\000\000\000\000\000\009\255\009\255\009\255\009\255\
\009\255\009\255\154\255\002\255\002\255\000\255\000\000\158\255\
\165\255\009\255\009\255\249\255\000\000\000\000\000\000\158\000\
\000\000\000\000\037\255\000\000\000\000\249\255\249\255\249\255\
\249\255\249\255\249\255\146\255\000\000\000\000\002\255\002\255\
\157\255\061\255\105\255\000\000\000\000\000\000\000\000\214\255\
\000\000\009\255\009\255\009\255\009\255\009\255\000\000\118\255\
\009\255\000\000\151\255\108\255\000\000\000\000\000\000\000\000\
\000\000\000\000\009\255\002\255\002\255\002\255\106\255\106\255\
\000\000\229\254\229\254\000\000\000\000\000\000\000\000\243\255\
\000\000\249\255\000\000\172\255\029\255\132\255\000\000\187\255\
\000\000\002\255\177\255\106\255\082\255\000\000\000\000\037\255\
\178\255\106\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\044\255\000\000\000\000\098\255\044\255\175\255\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\098\255\000\000\000\000\097\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\131\255\000\000\000\000\
\000\000\000\000\000\000\203\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\226\255\228\255\230\255\
\238\255\240\255\242\255\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\097\255\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\193\255\193\255\
\000\000\180\255\199\255\000\000\000\000\000\000\000\000\000\000\
\000\000\086\255\000\000\057\255\065\255\098\255\000\000\081\255\
\000\000\000\000\000\000\193\255\000\000\000\000\000\000\179\255\
\000\000\193\255\000\000"

let yygindex = "\000\000\
\000\000\199\000\237\255\000\000\202\000\250\255\114\000\000\000\
\185\000\157\000\245\255\221\255\176\255\000\000\000\000"

let yytablesize = 285
let yytable = "\020\000\
\049\000\067\000\038\000\039\000\044\000\076\000\077\000\061\000\
\078\000\038\000\039\000\062\000\001\000\020\000\063\000\113\000\
\003\000\054\000\055\000\056\000\057\000\058\000\059\000\068\000\
\069\000\040\000\041\000\082\000\084\000\064\000\072\000\073\000\
\040\000\041\000\005\000\119\000\042\000\010\000\043\000\011\000\
\012\000\123\000\092\000\093\000\002\000\043\000\002\000\002\000\
\016\000\008\000\002\000\002\000\083\000\025\000\002\000\002\000\
\107\000\108\000\109\000\026\000\017\000\018\000\098\000\099\000\
\100\000\101\000\102\000\002\000\002\000\104\000\002\000\052\000\
\052\000\002\000\092\000\093\000\094\000\035\000\117\000\106\000\
\053\000\028\000\036\000\028\000\028\000\052\000\052\000\028\000\
\028\000\095\000\115\000\028\000\028\000\053\000\053\000\092\000\
\093\000\094\000\037\000\054\000\054\000\054\000\046\000\020\000\
\028\000\028\000\010\000\028\000\011\000\012\000\028\000\120\000\
\013\000\014\000\054\000\054\000\015\000\016\000\092\000\093\000\
\094\000\092\000\093\000\094\000\007\000\013\000\013\000\011\000\
\047\000\017\000\018\000\110\000\010\000\096\000\011\000\012\000\
\105\000\048\000\013\000\014\000\051\000\050\000\015\000\016\000\
\035\000\035\000\035\000\035\000\035\000\035\000\035\000\035\000\
\035\000\035\000\060\000\017\000\018\000\079\000\070\000\035\000\
\035\000\035\000\035\000\035\000\035\000\071\000\035\000\085\000\
\086\000\087\000\088\000\089\000\090\000\085\000\086\000\087\000\
\088\000\089\000\090\000\097\000\081\000\074\000\075\000\076\000\
\077\000\092\000\078\000\074\000\075\000\076\000\077\000\116\000\
\078\000\040\000\040\000\040\000\040\000\040\000\040\000\040\000\
\040\000\040\000\040\000\118\000\005\000\024\000\122\000\011\000\
\040\000\040\000\040\000\040\000\041\000\041\000\041\000\041\000\
\041\000\041\000\041\000\041\000\041\000\041\000\011\000\027\000\
\028\000\027\000\053\000\041\000\041\000\041\000\041\000\027\000\
\027\000\121\000\029\000\080\000\103\000\030\000\031\000\032\000\
\033\000\034\000\097\000\000\000\074\000\075\000\076\000\077\000\
\015\000\078\000\016\000\000\000\017\000\000\000\015\000\015\000\
\016\000\016\000\017\000\017\000\018\000\000\000\019\000\000\000\
\020\000\000\000\018\000\018\000\019\000\019\000\020\000\020\000\
\114\000\074\000\075\000\076\000\077\000\000\000\078\000\074\000\
\075\000\076\000\077\000\000\000\078\000"

let yycheck = "\006\000\
\020\000\037\000\001\001\002\001\016\000\033\001\034\001\006\001\
\036\001\001\001\002\001\010\001\001\000\020\000\013\001\096\000\
\026\001\029\000\030\000\031\000\032\000\033\000\034\000\024\001\
\025\001\024\001\025\001\063\000\064\000\028\001\042\000\043\000\
\024\001\025\001\009\001\116\000\028\001\001\001\037\001\003\001\
\004\001\122\000\014\001\015\001\001\001\037\001\003\001\004\001\
\012\001\001\001\007\001\008\001\064\000\023\001\011\001\012\001\
\092\000\093\000\094\000\030\001\024\001\025\001\074\000\075\000\
\076\000\077\000\078\000\024\001\025\001\081\000\027\001\015\001\
\016\001\030\001\014\001\015\001\016\001\028\001\114\000\091\000\
\016\001\001\001\028\001\003\001\004\001\029\001\030\001\007\001\
\008\001\029\001\110\000\011\001\012\001\029\001\030\001\014\001\
\015\001\016\001\028\001\014\001\015\001\016\001\001\001\110\000\
\024\001\025\001\001\001\027\001\003\001\004\001\030\001\030\001\
\007\001\008\001\029\001\030\001\011\001\012\001\014\001\015\001\
\016\001\014\001\015\001\016\001\027\001\029\001\030\001\030\001\
\001\001\024\001\025\001\026\001\001\001\029\001\003\001\004\001\
\029\001\027\001\007\001\008\001\023\001\030\001\011\001\012\001\
\014\001\015\001\016\001\017\001\018\001\019\001\020\001\021\001\
\022\001\023\001\001\001\024\001\025\001\000\000\001\001\029\001\
\030\001\031\001\032\001\033\001\034\001\001\001\036\001\017\001\
\018\001\019\001\020\001\021\001\022\001\017\001\018\001\019\001\
\020\001\021\001\022\001\029\001\035\001\031\001\032\001\033\001\
\034\001\014\001\036\001\031\001\032\001\033\001\034\001\005\001\
\036\001\014\001\015\001\016\001\017\001\018\001\019\001\020\001\
\021\001\022\001\023\001\027\001\030\001\007\000\029\001\029\001\
\029\001\030\001\031\001\032\001\014\001\015\001\016\001\017\001\
\018\001\019\001\020\001\021\001\022\001\023\001\030\001\024\001\
\025\001\023\001\025\000\029\001\030\001\031\001\032\001\029\001\
\030\001\120\000\035\001\051\000\080\000\038\001\039\001\040\001\
\041\001\042\001\029\001\255\255\031\001\032\001\033\001\034\001\
\023\001\036\001\023\001\255\255\023\001\255\255\029\001\030\001\
\029\001\030\001\029\001\030\001\023\001\255\255\023\001\255\255\
\023\001\255\255\029\001\030\001\029\001\030\001\029\001\030\001\
\030\001\031\001\032\001\033\001\034\001\255\255\036\001\031\001\
\032\001\033\001\034\001\255\255\036\001"

let yynames_const = "\
  BREAK\000\
  CONTINUE\000\
  ELSE\000\
  FALSE\000\
  FOR\000\
  IF\000\
  INT\000\
  TRUE\000\
  WHILE\000\
  WRITEINT\000\
  NOT\000\
  AND\000\
  OR\000\
  XOR\000\
  EQ\000\
  NE\000\
  LT\000\
  LE\000\
  GT\000\
  GE\000\
  COMMA\000\
  PLUSPLUS\000\
  MINUSMINUS\000\
  LBRACE\000\
  RBRACE\000\
  LPAREN\000\
  RPAREN\000\
  SEMICOL\000\
  PLUS\000\
  MINUS\000\
  TIMES\000\
  DIVIDE\000\
  ASSIGN\000\
  EOF\000\
  MOD\000\
  NEG\000\
  PLUSASSIGN\000\
  MINUSASSIGN\000\
  TIMESASSIGN\000\
  DIVIDEASSIGN\000\
  MODASSIGN\000\
  "

let yynames_block = "\
  ID\000\
  INTCONST\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'declseq) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'stmtseq) in
    Obj.repr(
# 58 "grammar.mly"
  ( A.Program(A.VarDecSeq _2, A.SeqStmt _3, E.currentContext()) )
# 346 "grammar.ml"
               : Absyn.program))
; (fun __caml_parser_env ->
    Obj.repr(
# 62 "grammar.mly"
  ( [] )
# 352 "grammar.ml"
               : 'declseq))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'decl) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'declseq) in
    Obj.repr(
# 64 "grammar.mly"
  ( _1@_2 )
# 360 "grammar.ml"
               : 'declseq))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'identlist) in
    Obj.repr(
# 68 "grammar.mly"
  ( _2 )
# 367 "grammar.ml"
               : 'decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 72 "grammar.mly"
  ( [(_1, A.IntExp Int32.zero, context 1 1)] )
# 374 "grammar.ml"
               : 'identlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'identlist) in
    Obj.repr(
# 74 "grammar.mly"
  ( (_1, A.IntExp Int32.zero, context 1 1)::_3 )
# 382 "grammar.ml"
               : 'identlist))
; (fun __caml_parser_env ->
    Obj.repr(
# 78 "grammar.mly"
  ([])
# 388 "grammar.ml"
               : 'stmtseq))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'stmt) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'stmtseq) in
    Obj.repr(
# 80 "grammar.mly"
  ( (_1, context 1 1)::_2)
# 396 "grammar.ml"
               : 'stmtseq))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'simps) in
    Obj.repr(
# 84 "grammar.mly"
  ( A.SeqStmt (_1) )
# 403 "grammar.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'control) in
    Obj.repr(
# 86 "grammar.mly"
  ( _1 )
# 410 "grammar.ml"
               : 'stmt))
; (fun __caml_parser_env ->
    Obj.repr(
# 90 "grammar.mly"
  ( [] )
# 416 "grammar.ml"
               : 'simps))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'simp) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'csimps) in
    Obj.repr(
# 92 "grammar.mly"
  ( [(_1, context 1 1)]@_2 )
# 424 "grammar.ml"
               : 'simps))
; (fun __caml_parser_env ->
    Obj.repr(
# 96 "grammar.mly"
  ( [] )
# 430 "grammar.ml"
               : 'csimps))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'simp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'csimps) in
    Obj.repr(
# 98 "grammar.mly"
  ( (_2, context 2 2)::_3 )
# 438 "grammar.ml"
               : 'csimps))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 102 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1), _3, context 1 3) )
# 446 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 104 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
	A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)), 
		A.PlusOp, _3, context 3 3), context 1 3) )
# 456 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 108 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
	A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)), 
		A.MinusOp, _3, context 3 3), context 1 3) )
# 466 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 112 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
	A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)), 
		A.TimesOp, _3, context 3 3), context 1 3) )
# 476 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 116 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
	A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)), 
		A.DivideOp, _3, context 3 3), context 1 3) )
# 486 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Symbol.symbol) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 120 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
	A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)), 
		A.ModOp, _3, context 3 3), context 1 3) )
# 496 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 124 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_2, context 2 2),
        A.OpExp(A.VarExp(A.SimpleVar(_2, context 2 2)),
                A.PlusOp, A.IntExp Int32.one, context 1 1), context 1 2) )
# 505 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Symbol.symbol) in
    Obj.repr(
# 128 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
        A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)),
                A.PlusOp, A.IntExp Int32.one, context 1 1), context 1 2) )
# 514 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 132 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_2, context 2 2),
        A.OpExp(A.VarExp(A.SimpleVar(_2, context 2 2)),
                A.MinusOp, A.IntExp Int32.one, context 1 1), context 1 2) )
# 523 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Symbol.symbol) in
    Obj.repr(
# 136 "grammar.mly"
  ( A.AssignStmt(A.SimpleVar(_1, context 1 1),
        A.OpExp(A.VarExp(A.SimpleVar(_1, context 1 1)),
                A.MinusOp, A.IntExp Int32.one, context 1 1), context 1 2) )
# 532 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    Obj.repr(
# 140 "grammar.mly"
  ( A.BreakStmt(context 1 1) )
# 538 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    Obj.repr(
# 142 "grammar.mly"
  ( A.ContinueStmt(context 1 1) )
# 544 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 144 "grammar.mly"
  ( A.WriteintStmt(_2, context 1 1) )
# 551 "grammar.ml"
               : 'simp))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'boolexp) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 148 "grammar.mly"
  ( A.IfStmt(_3, _5, A.SeqStmt([]), context 1 5) )
# 559 "grammar.ml"
               : 'control))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 4 : 'boolexp) in
    let _5 = (Parsing.peek_val __caml_parser_env 2 : 'block) in
    let _7 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 150 "grammar.mly"
  ( A.IfStmt(_3, _5, _7, context 1 7) )
# 568 "grammar.ml"
               : 'control))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'boolexp) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 152 "grammar.mly"
  ( A.WhileStmt(_3, _5, context 1 5) )
# 576 "grammar.ml"
               : 'control))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 8 : Symbol.symbol) in
    let _5 = (Parsing.peek_val __caml_parser_env 6 : 'intexp) in
    let _7 = (Parsing.peek_val __caml_parser_env 4 : 'boolexp) in
    let _9 = (Parsing.peek_val __caml_parser_env 2 : 'simps) in
    let _11 = (Parsing.peek_val __caml_parser_env 0 : 'block) in
    Obj.repr(
# 154 "grammar.mly"
  ( A.ForStmt(A.SimpleVar(_3, context 1 1), _5, _7, A.SeqStmt(_9), _11, context 1 11) )
# 587 "grammar.ml"
               : 'control))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'stmt) in
    Obj.repr(
# 158 "grammar.mly"
  ( _1 )
# 594 "grammar.ml"
               : 'block))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'stmtseq) in
    Obj.repr(
# 160 "grammar.mly"
  ( A.SeqStmt _2 )
# 601 "grammar.ml"
               : 'block))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int32) in
    Obj.repr(
# 164 "grammar.mly"
  ( A.IntExp(_1) )
# 608 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 166 "grammar.mly"
  ( A.VarExp(A.SimpleVar(_1, context 1 1)) )
# 615 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'incdec) in
    Obj.repr(
# 168 "grammar.mly"
  ( _1 )
# 622 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 170 "grammar.mly"
  ( A.OpExp(A.IntExp Int32.zero, A.MinusOp, _2, context 1 2) )
# 629 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 172 "grammar.mly"
  ( A.OpExp(_1, A.DivideOp, _3, context 1 3) )
# 637 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 174 "grammar.mly"
  ( A.OpExp(_1, A.TimesOp, _3, context 1 3) )
# 645 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 176 "grammar.mly"
  ( A.OpExp(_1, A.PlusOp, _3, context 1 3) )
# 653 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 178 "grammar.mly"
  ( A.OpExp(_1, A.MinusOp, _3, context 1 3) )
# 661 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 180 "grammar.mly"
  ( A.OpExp(_1, A.ModOp, _3, context 1 3) )
# 669 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'intexp) in
    Obj.repr(
# 182 "grammar.mly"
  ( _2 )
# 676 "grammar.ml"
               : 'intexp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 186 "grammar.mly"
  ( A.PreIncExp(A.SimpleVar(_2, context 2 2), context 1 2) )
# 683 "grammar.ml"
               : 'incdec))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Symbol.symbol) in
    Obj.repr(
# 188 "grammar.mly"
  ( A.PostIncExp(A.SimpleVar(_1, context 1 1), context 1 2) )
# 690 "grammar.ml"
               : 'incdec))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Symbol.symbol) in
    Obj.repr(
# 190 "grammar.mly"
  ( A.PreDecExp(A.SimpleVar(_2, context 2 2), context 1 2) )
# 697 "grammar.ml"
               : 'incdec))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Symbol.symbol) in
    Obj.repr(
# 192 "grammar.mly"
  ( A.PostDecExp(A.SimpleVar(_1, context 1 1), context 1 2) )
# 704 "grammar.ml"
               : 'incdec))
; (fun __caml_parser_env ->
    Obj.repr(
# 197 "grammar.mly"
  ( A.True(context 1 1) )
# 710 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    Obj.repr(
# 199 "grammar.mly"
  ( A.False(context 1 1) )
# 716 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'boolexp) in
    Obj.repr(
# 201 "grammar.mly"
  ( A.Unopb(_2, A.NotOp, context 1 2) )
# 723 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'boolexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'boolexp) in
    Obj.repr(
# 203 "grammar.mly"
  ( A.Binopb(_1, A.AndOp, _3, context 1 3) )
# 731 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'boolexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'boolexp) in
    Obj.repr(
# 205 "grammar.mly"
  ( A.Binopb(_1, A.OrOp, _3, context 1 3) )
# 739 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'boolexp) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'boolexp) in
    Obj.repr(
# 207 "grammar.mly"
  ( A.Binopb(_1, A.XorOp, _3, context 1 3) )
# 747 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'intexp) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'cmpop) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'intexp) in
    Obj.repr(
# 209 "grammar.mly"
  ( A.Cmpop(_1, _2, _3, context 1 3) )
# 756 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'boolexp) in
    Obj.repr(
# 211 "grammar.mly"
  ( _2 )
# 763 "grammar.ml"
               : 'boolexp))
; (fun __caml_parser_env ->
    Obj.repr(
# 215 "grammar.mly"
  ( A.EqOp )
# 769 "grammar.ml"
               : 'cmpop))
; (fun __caml_parser_env ->
    Obj.repr(
# 217 "grammar.mly"
  ( A.NeOp )
# 775 "grammar.ml"
               : 'cmpop))
; (fun __caml_parser_env ->
    Obj.repr(
# 219 "grammar.mly"
  ( A.LtOp )
# 781 "grammar.ml"
               : 'cmpop))
; (fun __caml_parser_env ->
    Obj.repr(
# 221 "grammar.mly"
  ( A.LeOp )
# 787 "grammar.ml"
               : 'cmpop))
; (fun __caml_parser_env ->
    Obj.repr(
# 223 "grammar.mly"
  ( A.GtOp )
# 793 "grammar.ml"
               : 'cmpop))
; (fun __caml_parser_env ->
    Obj.repr(
# 225 "grammar.mly"
  ( A.GeOp )
# 799 "grammar.ml"
               : 'cmpop))
(* Entry program *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let program (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Absyn.program)
;;
