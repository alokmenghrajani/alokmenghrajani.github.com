/* 
 * mm.c -  Simple allocator based on implicit free lists, 
 *         first fit placement, and boundary tag coalescing.
 *         Based on provided mm-helper.c
 *
 * Each block has a header, request_id and payload_size, followed by the user blocks
 * and ends with a footer. The blocks are pointed at the id tag, because some blocks are empty.
 * Empty blocks have a pointer to previous empty and next empty blocks (double linked list).
 * Block pointers are incremented by DSIZE before they are returned and decremented by DSIZE when
 * free is called.
 * The lsb of the header and footer is always 0 (DWORD aligned), so it's overloaded to tell if a block is
 * allocated or not (lsb is set if allocated).
 *
 * The heap starts with a padding, followed by an empty block (prologue block), and ends with an epilogue block.
 * These two blocks elminate edge conditions during coalescing.
 * The prologue and epilogue blocks are 32 bits only. There values are hdr(8:a)ftr(8:a) and hdr(0:a) respectivly.
 * (In mm-helper.c there is a bug in the comments about this).
 *
 * So the heap looks something like:
 *
 * pad     | prologue            |       ...user blocks...      | ... | epilogue
 * 3 WORDS | hdr(8:a) | ftr(8:a) | hdr | id | size | usr | foot | ... | hdr(0:a)
 *                                     ^           ^
 *                                block PTR    DWORD aligned
 */
#include <stdio.h>
#include "mm.h"
#include "memlib.h"

/* Team structure */
team_t team = {
    "amenghra", "Alok Menghrajani", "amenghra@andrew.cmu.edu", "", ""
};

/* Basic constants and macros */
#define WSIZE       4       /* word size (bytes) */  
#define DSIZE       8       /* doubleword size (bytes) */
#define CHUNKSIZE  (1<<12)  /* initial heap size (bytes) */
#define OVERHEAD    16      /* overhead of header and footer (bytes) */
/* #define DEBUGMODE */          /* uncomment this define for debugging info */

#define MAX(x, y) ((x) > (y)? (x) : (y))  

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)  ((size) | (alloc))

/* Read and write a word at address p */
#define GET(p)       (*(size_t *)(p))
#define PUT(p, val)  (*(size_t *)(p) = (val))  

/* Read the size and allocated fields from address p */
#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

/* Given block ptr bp, compute address of its header and footer */
/* These macros have been modified to match my new block format */
#define HDRP(bp)       ((char *)(bp) - WSIZE)
/* FTRP macro depends on HDRP, so you better set the header properly before calling
   this macro.... */
#define FTRP(bp)         ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
#define REQUEST_ID(bp)   ((char *) bp)
#define PAYLOAD_SIZE(bp) ((char *)bp + WSIZE)
#define PTR_TO_USER_BLOCK(bp)   ((char *)bp + DSIZE)
#define USER_BLOCK_TO_PTR(bp)   ((char *)bp - DSIZE)
#define PREV_FREE(bp) ((char *)bp)
#define NEXT_FREE(bp) ((char *)bp + WSIZE)

/* Given block ptr bp, compute address of next and previous blocks */
/* These macro has been modified to reuse the HDRP and FTRP macros */
#define NEXT_BLKP(bp)  ((char *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp)  ((char *)(bp) - GET_SIZE((char *)bp-DSIZE))

/* Global variables */
static char *heap_listp;  /* pointer to first block */  
static int request_id;    /* counter of request id. Init to 0 in mm_init and thn incremented at each mm_alloc */
static char *free_list;   /* pointer to first free block (linked list) */

/* function prototypes for internal helper routines */
static void *extend_heap(size_t words);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);
static void *coalesce(void *bp);
static void print_block(int request_id, int payload);

/* Printing routines (Pretty printer, that keeps things aligned) */
#ifdef DEBUGMODE
  static int tab=0;

/* Just print tab spaces */
  void pp_tab() {
    int i;
    for (i=0; i<tab; i++)
      printf(" ");
  }

/* Call this when entering a block. Will increment tab by 2. */
  void pp_enter(char *s) {
    pp_tab();
    printf("Begin %s\n", s);
    tab+=2;
  }

/* Call this to exit a block. */
  void pp_exit(char *s) {
    tab-=2;
    pp_tab();
    printf("End %s\n", s);
  }

/* This is to print a msg, usually not used (cos isn't as fancy as printf) */
  void pp_msg(char *s) {
    pp_tab();
    printf("%s\n", s);
  }

/* FREE LIST MANIPULATION ROUTINS */

/* Check to see if free list is correct. This routine will check that
   the list is properly double linked, and all blocks in here are
   free. It will NOT check that all free blocks are in the free list.
   But will return the number of elements in free list. Since every element is free
   and can only appear once (else the list would loop forever), it's easy to
   check that the returned number of elements matches the one calculated in
   mm_heapcheck, which would emply that every free block is present in this list.
*/
int check_free_list() {
  char *t;
  int numFree = 0;
  t=free_list;
  /* check that first element has a prev pointer set to NULL */
  if (t!=NULL) {
    if ((char *)GET(PREV_FREE(t)) != NULL) {
      printf("Prev of first element of free list not NULL !!! - error\n");
    }
  }
  /* Go through each element in the list and check that the next element points back properly */
  while (t!=NULL) {
    char *n;
    numFree++;
    /* check if next element points to this one */
    n=(char *)GET(NEXT_FREE(t));
    /* special case of last element, that doesn't have any other element pointing back to it */
    if (n!=NULL)
      if ((char *)GET(PREV_FREE(n)) != t) {
	printf("Next element doesn't point back !!! - error\n");
      }
    /* check if this element is a free block */
    /* this does not guarantee that all free blocks are in the free list though */
    if (GET_ALLOC(HDRP(t))) {
      printf("Allocated block in free list !!! - error\n");
    }
    t=n;
  }
  return numFree;
}

/* Print each block in the free list. */
void print_free_list() {
  char *t=free_list;
  pp_enter("Free list");
  while (t!=NULL) {
    char *n, *p;
    n=(char *)GET(NEXT_FREE(t));
    p=(char *)GET(PREV_FREE(t));
    pp_tab();
    printf("curr:%d ", HDRP(t)-heap_listp);
    if (p!=NULL)
      printf("prev:%d ", HDRP((char *)GET(PREV_FREE(t)))-heap_listp);
    else
      printf("prev:NULL ");
    if (n!=NULL)
      printf("next:%d\n", HDRP(n)-heap_listp);
    else
      printf("next:NULL\n");
    t=n;
  }
  pp_exit("Free list");
}
#endif


/* Add a block to the begining of the free list. */
void add_free_list(void *bp) {
  PUT(PREV_FREE(bp), (int)NULL);
  /* get new element to point to the former first element */
  PUT(NEXT_FREE(bp), (int)free_list);
  /* if free_list isn't NULL, then we must update the former first (current second) element
     to point to the new first element */
  if (free_list!=NULL)
    PUT(PREV_FREE(free_list), (int)bp);
  /* make first list point to the new element */
  free_list=(char *)bp;
}

void remove_free_list(void *bp) {
  char *t;
  /* special case if first element */  
  t = (char *)GET(PREV_FREE(bp));
  if (t!=NULL) {
    PUT(NEXT_FREE(t), GET(NEXT_FREE(bp)));
  }
  else
    free_list=(char *)GET(NEXT_FREE(bp));
  /* special case if last element */
  t = (char *)GET(NEXT_FREE(bp));
  if (t!=NULL)
    PUT(PREV_FREE(t), GET(PREV_FREE(bp)));
}

/* MAIN ROUTINES */

/* Called to initialize the heap */
int mm_init(void) 
{
#ifdef DEBUGMODE
  pp_enter("\n\n\nInit");
#endif
  /* initialize the counter */
  request_id = 0;
  /* set global var free_list to NULL */
  free_list = NULL;

  /* create the initial empty heap */
  if ((heap_listp = mem_sbrk(6*WSIZE)) == NULL)
    return -1;
  PUT(heap_listp, 0);                        /* alignment padding */
  PUT(heap_listp+WSIZE, 0);                  /* alignment padding */
  PUT(heap_listp+DSIZE, 0);                  /* alignment padding */
  /* set the heap_listp to point right after the padding, so I don't need
     to take in account the padding anymore. */
  heap_listp += 3*WSIZE;

  PUT(heap_listp, PACK(DSIZE, 1));         /* prologue header */
  PUT(heap_listp+WSIZE, PACK(DSIZE, 1));   /* prologue footer */
  PUT(heap_listp+DSIZE, PACK(0, 1));       /* epilogue header */

#ifdef DEBUGMODE
  pp_msg("before extend");
  mm_heapcheck();
#endif
  /* Extend the empty heap with a free block of CHUNKSIZE bytes */
  if (extend_heap(CHUNKSIZE/WSIZE) == NULL)
    return -1;
#ifdef DEBUGMODE
  pp_exit("Init");
  pp_msg("after init");
  mm_heapcheck();
#endif
  return 0;
}

/* Allocate a block with at least size bytes of payload */
void *mm_malloc(size_t size) 
{
    size_t asize;      /* adjusted block size */
    size_t extendsize; /* amount to extend heap if no fit */
    char *bp;      
#ifdef DEBUGMODE
    pp_enter("Malloc");
#endif
    /* Ignore spurious requests */
    if (size <= 0)
	return NULL;

    /* set asize to size+OVERHEAD rounded to upper multiple of DSIZE */
    /* don't know why mm-helper was using an if then else block here... */
    asize = DSIZE * ((size + (OVERHEAD) + (DSIZE-1)) / DSIZE);
#ifdef DEBUGMODE
    pp_tab();
    printf("Size=%d, asize=%d\n", size, asize);
#endif
    /* Search the free list for a fit */
    if ((bp = find_fit(asize)) != NULL) {
      place(bp, asize);
      PUT(REQUEST_ID(bp), request_id++);
      PUT(PAYLOAD_SIZE(bp), size);
#ifdef DEBUGMODE
      pp_exit("Malloc");
      pp_msg("after malloc");
      mm_heapcheck();
#endif
      return PTR_TO_USER_BLOCK(bp);
    }

    /* No fit found. Get more memory and place the block */
    extendsize = MAX(asize,CHUNKSIZE);
    if ((bp = extend_heap(extendsize/WSIZE)) == NULL)
	return NULL;
    place(bp, asize);
    PUT(REQUEST_ID(bp), request_id++);
    PUT(PAYLOAD_SIZE(bp), size);
#ifdef DEBUGMODE
    pp_exit("Malloc");
    pp_msg("after malloc");
    mm_heapcheck();
#endif
    return PTR_TO_USER_BLOCK(bp);
} 

/* Free a block */
void mm_free(void *bp)
{
  char* nbp = USER_BLOCK_TO_PTR(bp);
  size_t size = GET_SIZE(HDRP(nbp));
#ifdef DEBUGMODE
  pp_enter("Free");
#endif
  /* Simple modify the header and add to free list */
  PUT(HDRP(nbp), PACK(size, 0));
  PUT(FTRP(nbp), PACK(size, 0));
  add_free_list(nbp);
  /* Try to coalesce with previous and next block */
  coalesce(nbp);
#ifdef DEBUGMODE
  pp_exit("Free");
  pp_msg("after free");
  mm_heapcheck();
#endif
}


/* The remaining routines are internal helper routines */

static void *extend_heap(size_t words) 
{
    char *bp;
    size_t size;
    /* Allocate an even number of words to maintain alignment */
    size = (words % 2) ? (words+1) * WSIZE : words * WSIZE;

    if ((int)(bp = mem_sbrk(size)) < 0)
       return NULL;

    /* Initialize free block header/footer and the epilogue header */
    PUT(HDRP(bp), PACK(size, 0));         /* free block header */
    PUT(FTRP(bp), PACK(size, 0));         /* free block footer */
    add_free_list(bp); /* add block to free list */

    /* Isn't this block outside of allocated heap ??? */
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); /* new epilogue header */
    /* Coalesce if the previous block was free */
    return coalesce(bp);
}


/* place a block of asize at start of free block bp, and split remainder if enough space. */
/* Doesn't put the request_id and payload_size which is done in mm_alloc */
static void place(void *bp, size_t asize)
{
  size_t csize = GET_SIZE(HDRP(bp));   
    remove_free_list(bp);
    /* I have definied the minimal remainder space to be at least 4 words + OVERHEAD.
       Don't know if this is the optimal choice. */
    if ((csize - asize) >= (4*WSIZE + OVERHEAD)) { 
	PUT(HDRP(bp), PACK(asize, 1));
	PUT(FTRP(bp), PACK(asize, 1));
	bp = NEXT_BLKP(bp);
	add_free_list(bp);
	PUT(HDRP(bp), PACK(csize-asize, 0));
	PUT(FTRP(bp), PACK(csize-asize, 0));
    }
    else { 
	PUT(HDRP(bp), PACK(csize, 1));
	PUT(FTRP(bp), PACK(csize, 1));
    }
}

/* Find a fit for a block with asize bytes */
/* Combinasion of first fit and best fit (best fit on first N fits) */

static void *find_fit(size_t asize)
{
    /* first fit search */
    void *bp;
    int counter=0;
    int bestFitSize=0x7FFFFFFF;
    void *bestFitPtr=NULL;
#ifdef DEBUGMODE
    pp_enter("Find fit");
    check_free_list();
#endif
    bp = free_list;
    while (bp != NULL) {
      int s = GET_SIZE(HDRP(bp));
      if (asize <= s) {
	/* is it better that previous bestFit ? */
	if (s < bestFitSize) {
	  /* save ptr and size if it's better */
	  bestFitSize=s;
	  bestFitPtr=bp;
	}
	/* if we just found a perfect block, no need to continue searching */
	if (s==asize)
	  break;
      }
      /* if we found a fit and have gone through more than 10 free blocks, then
	 it's time to exit */
      if (((counter++)>10) && (bestFitPtr!=NULL))
	break;
      bp=(void*)GET(NEXT_FREE(bp));
    }
#ifdef DEBUGMODE
    pp_msg("no fit");
    pp_exit("Find fit");
#endif
    return bestFitPtr;
}

/* boundary tag coalescing. Return ptr to coalesced block */
/* I'm using a little hack to free minimum number of blocks.
   When coalescing happens, I only free the right most block(s). The left most
   is already in the free_list and thus doesn't need to be freed and readed, since
   my free list is unordered.
*/
static void *coalesce(void *bp) 
{
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));

    if (prev_alloc && next_alloc) {            /* Case 1 */
	return bp;
    }

    else if (prev_alloc && !next_alloc) {      /* Case 2 */
      remove_free_list((void *)NEXT_BLKP(bp));  /* cool hack... just remove next one. */
      size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
      PUT(HDRP(bp), PACK(size, 0));
      PUT(FTRP(bp), PACK(size,0));
    }

    else if (!prev_alloc && next_alloc) {      /* Case 3 */
      remove_free_list((void *)bp);            /* same hack again */
      size += GET_SIZE(HDRP(PREV_BLKP(bp)));
      PUT(FTRP(bp), PACK(size, 0));
      PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
      bp = PREV_BLKP(bp);
    }

    else {                                     /* Case 4 */
      remove_free_list((void *)bp);            /* and again */
      remove_free_list((void *)NEXT_BLKP(bp)); /* applied twice */
	size += GET_SIZE(HDRP(PREV_BLKP(bp))) + 
	    GET_SIZE(FTRP(NEXT_BLKP(bp)));
	PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
	PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
	bp = PREV_BLKP(bp);
    }
    return bp;
}

/* Check to see if heap is consistent. */
/* the output is something like: blocktype[beginaddress-lastaddress] followed by info contained in the block. 
   the address are offset to heap_listp (so prologue starts at address 0).
   The lastaddress is the last address part of the block (so it's nextblock - 1)
*/
/* Checks done include:
   - display info about each block
   - verify that header matches footer
   - verify the the free list is correct   
   - check that the blocks are coalesced properly
   - that every free block is in the free list.
   
   Checks not performed (cos the testing suit does it for me):
   - block outside heap zone
   - block correctly alligned
*/
void mm_heapcheck()
{
  char *bp = heap_listp + WSIZE;
#ifdef DEBUGMODE
  int prevFree = 0;                 /* to detect if two consecutive blocks are free */
  int numFree = 0;                  /* to check that every free block is in the free list,
				       I count the number of free blocks in this routine
				       and compare it with the number of free blocks in the free list.
				       Since the free list checks that the block are really free,
				       and a free block can appear only once in the free list (else
				       the list will be circular and check_free_list will loop forever),
				       I can prove that these two numbers must be the same (bijection). */
  pp_enter("Heapcheck");
#endif
  /* go through each block */
  while (1) {
    int size = GET_SIZE(HDRP(bp));
#ifdef DEBUGMODE
    if (size==DSIZE) {
      /* this is a prologue block */
      pp_tab();
      printf("Prologue[%d-%d]\n", (int) (HDRP(bp)-heap_listp), (int) (((char *)FTRP(bp)-heap_listp)+WSIZE-1));
    } else if (size==0) {
      /* this is an epilogue block */
      pp_tab();
      printf("Epilogue[%d-%d]\n", (int) (HDRP(bp)-heap_listp), (int) (((char *)HDRP(bp)-heap_listp)+WSIZE-1));
      break;
    } else {
      /* this is a user block */
      if (*HDRP(bp)!=*FTRP(bp))
	printf("Header (%d) does not match footer (%d) !!! - error\n", *HDRP(bp), *FTRP(bp));
      if GET_ALLOC(HDRP(bp)) {
	/* allocated */
	prevFree=0;
	pp_tab();
	printf("A[%d-%d]:", (int) (HDRP(bp)-heap_listp), (int) (((char *)FTRP(bp)-heap_listp)+WSIZE-1));
	printf("H[%d]=%d ", (int) (HDRP(bp)-heap_listp), GET_SIZE(HDRP(bp)));
	printf("ID[%d]=%d ", (int) (REQUEST_ID(bp)-heap_listp), GET(REQUEST_ID(bp)));
	printf("SIZE[%d]=%d ", (int) (PAYLOAD_SIZE(bp)-heap_listp), GET(PAYLOAD_SIZE(bp)));
	printf("F[%d]=%d\n", (int) (FTRP(bp)-heap_listp), GET_SIZE(FTRP(bp)));
      } else {
	/* free */
        if (prevFree)
	  printf("NOT COALESCED !!! - error\n");
	prevFree=1;
	numFree++;
	pp_tab();
	printf("Free[%d-%d]: ", (int) (HDRP(bp)-heap_listp), (int) (((char *)FTRP(bp)-heap_listp)+WSIZE-1));
	printf("H[%d]=%d ", (int) (HDRP(bp)-heap_listp), GET_SIZE(HDRP(bp)));
	printf("PREV[%d]=%d ", (int) (PREV_FREE(bp)-heap_listp), GET(PREV_FREE(bp)));
	printf("NEXT[%d]=%d ", (int) (NEXT_FREE(bp)-heap_listp), GET(NEXT_FREE(bp)));
	printf("F[%d]=%d\n", (int) (FTRP(bp)-heap_listp), GET_SIZE(FTRP(bp)));
      }
    }
#endif
    /* this is the minimum requirment for the spec. */
    /* exit if epilogue block. */
    if (size==0)
      break;
    /* display request id and payload size if allocated. */
    if (size>DSIZE) {
      if (GET_ALLOC(HDRP(bp))) {
	print_block(GET(REQUEST_ID(bp)), GET(PAYLOAD_SIZE(bp)));
      }
    }
    bp=NEXT_BLKP(bp);
  }
#ifdef DEBUGMODE
  pp_exit("Heapcheck");
  if (check_free_list()!=numFree)
    printf("Free list doesn't have the right number of free block !!! - error\n");
  print_free_list();
#endif
}


/*
 * output a block - for use in heapcheck 
 */
static void print_block(int request_id, int payload)
{
  printf("\n$BLOCK %d %d\n",request_id,payload); 
}

