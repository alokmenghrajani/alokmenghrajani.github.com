#ifndef TEXTURES__H
#define TEXTURES__H

#include <stdlib.h>
#include <stdio.h>
#include <glut.h>

#define NUM_TEXTURES 10
#define TEXTURE_GROUND 0

/* Image type - contains height, width, and data */
typedef struct _Image {
    unsigned long sizeX;
    unsigned long sizeY;
    char *data;
} Image;

typedef struct _textures_t {
	GLint texture[NUM_TEXTURES];
} textures_t;

textures_t *textures_init(void);
void ground2();

#endif /* TEXTURES__H */
