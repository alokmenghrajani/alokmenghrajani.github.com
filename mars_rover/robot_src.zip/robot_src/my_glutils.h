#ifndef MY_GLUTILS__H
#define MY_GLUTILS__H

#include <glut.h>

typedef struct _points3 {
	GLfloat x;
	GLfloat y;
	GLfloat z;
} points3;

typedef struct _revol {
	int nbr_vertices;
	int nbr_sections;
	GLfloat width;
	points3* verts;
	points3* norms;
	points3* gouraud;
} revol;


void extrude(int nbr_vertices, GLfloat profile[], GLfloat vector[], int close);
void box(float x, float y, float z);
// pyramid, base=yz plane
void pyramid(float x, float y, float z);
revol* create_revolution(int nbr_vertices, GLfloat profile[], float angle, int nbr_sections);
void draw_revolution(revol* r, unsigned int textureID);

void drawMeshTriangle(int nbr_triangles, GLfloat mesh_points[], int mesh_triangles[], float (*func)(float, float), void (*gradient)(float, float, points3*), int invn);

#ifndef PI
#define PI 3.1415926
#endif

#endif /* MY_GLUTILS__H */
