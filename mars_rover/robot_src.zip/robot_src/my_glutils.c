#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "my_glutils.h"
#include "flat_shading.h"

/* Note: due to normals calculations, it is important
         to specify the profile in counterclockwise order
			The profile will be considered the top
			The profile will lie in the xz plane.
*/
void extrude(int nbr_vertices, GLfloat profile[], GLfloat vector[], int close) {
	int i, j;
	points3 p1, p2, p3, p4, n;

	for(i=0; i<nbr_vertices; i++) {
		if (i==nbr_vertices-1) {
			j = 0;
		} else {
			j = i*2+2;
		}
		p1.x = profile[i*2];
		p1.y = 0;
		p1.z = profile[i*2+1];

		p2.x = profile[j];
		p2.y = 0;
		p2.z = profile[j+1];

		p3.x = profile[j]+vector[0];
		p3.y = vector[1];
		p3.z = profile[j+1]+vector[2];

		p4.x = profile[i*2]+vector[0];
		p4.y = vector[1];
		p4.z = profile[i*2+1]+vector[2];
		calcNormal(&p1, &p3, &p2, &n);

		glBegin(GL_POLYGON);
		glNormal3fv((GLfloat*) &n);
		glVertex3fv((GLfloat*)&p1);
		glNormal3fv((GLfloat*)&n);
		glVertex3fv((GLfloat*)&p4);
		glNormal3fv((GLfloat*)&n);
		glVertex3fv((GLfloat*)&p3);
		glNormal3fv((GLfloat*)&n);
		glVertex3fv((GLfloat*)&p2);
		glEnd();
	}
	if (close) {
		/* add top */
		glBegin(GL_POLYGON);
		for(i=0; i<nbr_vertices; i++) {
			glNormal3f(0.0, 1.0, 0.0);
			glVertex3f(profile[i*2], 0, profile[i*2+1]);
		}
		glEnd();

		/* add bottom */
		glBegin(GL_POLYGON);
		for(i=nbr_vertices-1; i>=0; i--) {
			glNormal3f(0.0, -1.0, 0.0);
			glVertex3f(profile[i*2]+vector[0], vector[1], profile[i*2+1]+vector[2]);
		}
		glEnd();
	}
}
void drawMeshQuad(int nbr_polygons, GLfloat mesh_vertices[], int mesh_polygons[]) {
  int p, v;
  points3 n;
  points3 *a, *b, *c;
	for (p = 0; p<nbr_polygons; p++) { // pour chaque polygone
		a = (points3*)&mesh_vertices[mesh_polygons[p*4]*3];
		b = (points3*)&mesh_vertices[mesh_polygons[p*4+1]*3];
		c = (points3*)&mesh_vertices[mesh_polygons[p*4+2]*3];
    calcNormal(a, b, c, &n);
	 glBegin(GL_POLYGON);
    for(v = 0; v < 4; v++) {
		glNormal3fv((GLfloat*) &n);
      glVertex3f(mesh_vertices[mesh_polygons[p*4+v]*3],
                 mesh_vertices[mesh_polygons[p*4+v]*3+1],
                 mesh_vertices[mesh_polygons[p*4+v]*3+2]);
      }
    glEnd();
  }
}

void box(float x, float y, float z) {
	GLfloat cube_vertices[] = {1,0,0, // vertex 0
                           1,1,0, // vertex 1
                           1,1,1, // vertex 2
                           1,0,1, // vertex 3
                           0,1,0, // vertex 4
                           0,1,1, // vertex 5
                           0,0,1, // vertex 6
                           0,0,0};// vertex 7

	int cube_polygons[] = {0,1,2,3, // right = vertices (0,1,2,3)
                       1,4,5,2,    // top = vertices (1,4,5,2)
                       4,7,6,5,  //   left = vertices (4,7,6,5)
                       7,0,3,6,  // bottom = vertices (7,0,3,6)
                       3,2,5,6,  // front = vertices (3,2,5,6)
                       4,1,0,7}; // back = vertices (4,1,0,7)
	glPushMatrix();
	glScalef(x, y, z);
	drawMeshQuad(6, cube_vertices, cube_polygons);
	glPopMatrix();
}

void pyramid(float x, float y, float z) {
	points3 a, b, c, d, s, n;
	a.x = 0; a.y = y / 2.0; a.z = z / 2.0;
	b.x = 0; b.y = y / 2.0; b.z = -z / 2.0;
	c.x = 0; c.y = -y / 2.0; c.z = -z / 2.0;
	d.x = 0; d.y = -y / 2.0; d.z = z / 2.0;
	s.x = x; s.y = 0.0; s.z = 0.0;

	glPushMatrix();
	calcNormal(&s, &b, &a, &n);
	glBegin(GL_TRIANGLES);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &s);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &b);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &a);
	glVertex3f(x, 0, 0);
	glEnd();

	calcNormal(&s, &c, &b, &n);
	glBegin(GL_TRIANGLES);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &s);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &c);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &b);
	glVertex3f(x, 0, 0);
	glEnd();

	calcNormal(&s, &d, &c, &n);
	glBegin(GL_TRIANGLES);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &s);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &d);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &c);
	glVertex3f(x, 0, 0);
	glEnd();

	calcNormal(&s, &a, &d, &n);
	glBegin(GL_TRIANGLES);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &s);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &a);
	glNormal3fv((GLfloat*) &n); glVertex3fv((GLfloat*) &d);
	glVertex3f(x, 0, 0);
	glEnd();

	glPopMatrix();
}

//nbr_vertices: nombre de vertex du profile
//profile[]: tableau 2d contenant les vertex du profile relativement � l'axe de r�volution
//angle: angle d'extension (360 correspond � un tour complet)
//nbr_sections: nombre de sections pour le mesh

/*
	The profile should be representing the points from
	bottom up (so the normals are facing outside the object).
*/

revol* create_revolution(int nbr_vertices, GLfloat profile[], float angle, int nbr_sections) {
	revol* rev;
	int i, j, t;
	float theta1;

	rev = (revol*) malloc(sizeof(revol));
	rev->nbr_sections = nbr_sections;
	rev->nbr_vertices = nbr_vertices;

	/* for gouraud shading, we know that every vertex belongs
	   to 4 faces. So we can simply calculate the 4 normals
		and average them out.

		This code is very unoptimal. The normals
		for the faces can be calculated for one theta instead
		of each theta.
	*/
	/* calculate vertex and normals */
	rev->verts = (points3*) malloc(sizeof(points3) * nbr_vertices * nbr_sections);
	rev->norms = (points3*) malloc(sizeof(points3) * (nbr_vertices-1) * nbr_sections);
	rev->gouraud = (points3*) malloc(sizeof(points3) * nbr_vertices * nbr_sections);
	
	/* calculate width */
	rev->width = -1.0;
	for (i=0; i<nbr_vertices; i++) {
		if (profile[i*2] > rev->width) {
			rev->width = 2 * profile[i*2];
		}
	}

	/* calculate vertices */
	for (i=0; i<nbr_sections; i++) {
		theta1 = ((float)i) * angle / nbr_sections * PI / 180.0;
		for (j=0; j<nbr_vertices; j++) {
			rev->verts[i*nbr_vertices+j].x = profile[j*2]*cos(theta1);
			rev->verts[i*nbr_vertices+j].y = profile[j*2+1];
			rev->verts[i*nbr_vertices+j].z = profile[j*2]*sin(theta1);
		}
	}
	/* calculate normals */
	for (i=0; i<nbr_sections; i++) {
		if (i==nbr_sections-1) {
			t = 0;
		} else {
			t = i+1;
		}
		for (j=0; j < (nbr_vertices-1); j++) {
			calcNormal(&rev->verts[i*nbr_vertices+j],
				&rev->verts[i*nbr_vertices+j+1],
				&rev->verts[t*nbr_vertices+j+1],
				&rev->norms[i*(nbr_vertices-1)+j]);
			normalize(&rev->norms[i*(nbr_vertices-1)+j]);
		}
	}

	/* calculate gouraud shading */
	for (i=0; i<nbr_sections; i++) {
		if (i==0) {
			t = nbr_sections-1;
		} else {
			t = i-1;
		}
		for (j=0; j < nbr_vertices; j++) {
			points3 *n1, *n2, *n3, *n4, *n;
			n = &rev->gouraud[i*nbr_vertices + j];
			if (j==nbr_vertices-1) {
				n3 = &rev->norms[i*(nbr_vertices-1)+j-1];
				n2 = &rev->norms[t*(nbr_vertices-1)+j-1];
			} else {
				n3 = &rev->norms[i*(nbr_vertices-1)+j];
				n2 = &rev->norms[t*(nbr_vertices-1)+j];
			}
			if (j==0) {
				n4 = &rev->norms[i*(nbr_vertices-1)];
				n1 = &rev->norms[t*(nbr_vertices-1)];
			} else {
				n4 = &rev->norms[i*(nbr_vertices-1)+j-1];
				n1 = &rev->norms[t*(nbr_vertices-1)+j-1];
			}
			n->x = n1->x + n2->x + n3->x + n4->x;
			n->y = n1->y + n2->y + n3->y + n4->y;
			n->z = n1->z + n2->z + n3->z + n4->z;
		}
	}
	return rev;
}

void draw_revolution(revol* r, unsigned int textureID) {
	GLint shademodel;
	int i, j, t;
	glGetIntegerv(GL_SHADE_MODEL, &shademodel);
	assert(r!=NULL);



	/* plot vertices */
	for (i=0; i<r->nbr_sections; i++) {
		if (i==r->nbr_sections-1) {
			t = 0;
		} else {
			t = i+1;
		}
		for (j=0; j < (r->nbr_vertices-1); j++) {
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, textureID); 

			glBegin(GL_POLYGON);
			if (shademodel == GL_SMOOTH) {
				glTexCoord2f(r->verts[i*r->nbr_vertices+j].x / r->width + 0.5, r->verts[i*r->nbr_vertices+j].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->gouraud[i*r->nbr_vertices+j]);
				glVertex3fv((GLfloat*) &r->verts[i*r->nbr_vertices+j]);

				glTexCoord2f(r->verts[i*r->nbr_vertices+j+1].x / r->width + 0.5,r->verts[i*r->nbr_vertices+j+1].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->gouraud[i*r->nbr_vertices+j+1]);
				glVertex3fv((GLfloat*) &r->verts[i*r->nbr_vertices+j+1]);

				glTexCoord2f(r->verts[t*r->nbr_vertices+j+1].x / r->width + 0.5,r->verts[t*r->nbr_vertices+j+1].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->gouraud[t*r->nbr_vertices+j+1]);
				glVertex3fv((GLfloat*) &r->verts[t*r->nbr_vertices+j+1]);

				glTexCoord2f(r->verts[t*r->nbr_vertices+j].x / r->width + 0.5,r->verts[t*r->nbr_vertices+j].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->gouraud[t*r->nbr_vertices+j]);
				glVertex3fv((GLfloat*) &r->verts[t*r->nbr_vertices+j]);
			} else {
				glTexCoord2f(r->verts[i*r->nbr_vertices+j].x / r->width + 0.5, r->verts[i*r->nbr_vertices+j].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->norms[i*(r->nbr_vertices-1)+j]);
				glVertex3fv((GLfloat*) &r->verts[i*r->nbr_vertices+j]);

				glTexCoord2f(r->verts[i*r->nbr_vertices+j+1].x / r->width + 0.5,r->verts[i*r->nbr_vertices+j+1].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->norms[i*(r->nbr_vertices-1)+j]);
				glVertex3fv((GLfloat*) &r->verts[i*r->nbr_vertices+j+1]);

				glTexCoord2f(r->verts[t*r->nbr_vertices+j+1].x / r->width + 0.5,r->verts[t*r->nbr_vertices+j+1].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->norms[i*(r->nbr_vertices-1)+j]);
				glVertex3fv((GLfloat*) &r->verts[t*r->nbr_vertices+j+1]);

				glTexCoord2f(r->verts[t*r->nbr_vertices+j].x / r->width + 0.5,r->verts[t*r->nbr_vertices+j].z / r->width + 0.5);
				glNormal3fv((GLfloat*) &r->norms[i*(r->nbr_vertices-1)+j]);
				glVertex3fv((GLfloat*) &r->verts[t*r->nbr_vertices+j]);
			}
			glEnd();
			glDisable(GL_TEXTURE_2D);
		}
	}
}

void drawMeshTriangle(int nbr_triangles, GLfloat mesh_points[], int mesh_triangles[], float (*func)(float, float), void (*gradient)(float, float, points3*), int invn) {
  int i, j;
  GLint shademodel;
  points3 p[3], n;
	glGetIntegerv(GL_SHADE_MODEL, &shademodel);
  for (i=0; i<nbr_triangles; i++) { // pour chaque polygone
    for (j=0; j<3; j++) {
		 p[j].x = mesh_points[mesh_triangles[i*3+j]*2];
		 p[j].y = mesh_points[mesh_triangles[i*3+j]*2+1];
		 p[j].z = func(p[j].x, p[j].y);
	 }
	 if (shademodel != GL_SMOOTH) {
		calcNormal(&p[0], &p[1], &p[2], &n);
		 if (invn) {
			n.x = -n.x; n.y=-n.y; n.z=-n.z;
		}
	 }
	 glBegin(GL_TRIANGLES);
	 for (j=0; j<3; j++) {
		 if (shademodel == GL_SMOOTH) {
			gradient(p[j].x, p[j].y, &n);
			 if (invn) {
				n.x = -n.x; n.y=-n.y; n.z=-n.z;
			 }
		 }
		glNormal3fv((GLfloat*) &n);
		glVertex3fv((GLfloat*) &p[j]);
	 }
	 glEnd();
  }
}
