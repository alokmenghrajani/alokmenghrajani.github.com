#ifndef TRACER__H
#define TRACER__H

#include "my_glutils.h"

typedef struct _tracer_t {
	int current_size;
	int wrapped;
	int next_value;
	points3* buf;
} tracer_t;

tracer_t *tracer_init(int size);
void tracer_add(tracer_t *t, points3* p);
void tracer_draw(tracer_t *t);

#endif /* TRACER__H */
