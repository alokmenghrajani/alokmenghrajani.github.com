#include <stdlib.h>
#include "camera.h"


int	isInMouseDrag = FALSE;
int	viewPortCenterX = -1;
int	viewPortCenterY = -1;
int	oldCursorID = 0;
int	oldCursorX = 0;
int	oldCursorY = 0;
int	mouseIsInverted = TRUE;
GLfloat	camX = 0.0;
GLfloat	camY = 0.0;
GLfloat	camZ = 0.0;
GLfloat	camYaw = 0.0;
GLfloat	camPitch = 0.0;

// This makes sure we hide the cursor so that it does 
// not go out of the screen
void enterMouseDrag(int x,int y)
{
	if(isInMouseDrag)
		return;
	isInMouseDrag = TRUE;

	if( viewPortCenterX < 0 )
	{
		viewPortCenterX = glutGet( GLUT_WINDOW_WIDTH ) / 2;
		viewPortCenterY = glutGet( GLUT_WINDOW_HEIGHT ) / 2;
	}

	// Store settings for later.
	oldCursorID = glutGet( GLUT_WINDOW_CURSOR );
	oldCursorX = x;
	oldCursorY = y;

	glutSetCursor( GLUT_CURSOR_NONE );
	glutWarpPointer( viewPortCenterX, viewPortCenterY );
}


void exitMouseDrag(int x,int y)
{
	if( !isInMouseDrag )
		return;
	isInMouseDrag = FALSE;

	// Restore old settings.
	glutSetCursor( oldCursorID );
	glutWarpPointer( oldCursorX, oldCursorY );
}


// Makes sure the camera does not get out of hand
void clampCamera()
{
	// Clamp the camera's pitch.
	if( camPitch > 90.0 )
		camPitch = 90.0;
	else if( camPitch < -90.0 )
		camPitch = -90.0;

	// Modulus the yaw (0.0 to 360.0, exclusive).
	while( camYaw < 0.0 )
		camYaw += 360.0;
	while( camYaw >= 360.0 )
		camYaw -= 360.0;
}


// This moves the camera in the x and y direction of the local camera
// system.

void dollyCamera( GLfloat dollyBy, GLfloat dollyAngle )
{
  GLfloat actualAngleInRadians;
	// Use basic trig to get the relative components.
  actualAngleInRadians=( ( camYaw + dollyAngle ) * M_PI / 180.0 );
	camX -= sin( actualAngleInRadians ) * dollyBy * DEF_dollyStepSize;
	camZ -= cos( actualAngleInRadians ) * dollyBy * DEF_dollyStepSize;
}


// This callback allows us to toggle 'drag' mode (on a LMB click).
void mouseFunc( int button, int state, int x, int y )
{
	if( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
	{
		if( !isInMouseDrag )
			enterMouseDrag( x, y );
		else
			exitMouseDrag( x, y );
	}
}


// We trap 'special' keystrokes here.
void specialFunc(int key,int x,int y)
{
	switch( key )
	{
		// Turn left.
		case GLUT_KEY_LEFT:
			camYaw += 1.0;
			clampCamera();
			break;

		// Turn right.
		case GLUT_KEY_RIGHT:
			camYaw -= 1.0;
			clampCamera();
			break;

		// Look up.
		case GLUT_KEY_UP:
			camPitch += 1.0;
			clampCamera();
			break;

		// Look down.
		case GLUT_KEY_DOWN:
			camPitch -= 1.0;
			clampCamera();
			break;

	}
}

// Here, we trap mouse movements, warp the cursor back to the center of the screen,
// and update the camera (only in drag mode, of course).
void allMotionFunc( int x, int y )
{
  int deltaX;
  int deltaY;
	if( !isInMouseDrag )
		return;

	deltaX=( x - viewPortCenterX );
	deltaY=( y - viewPortCenterY );
	if( deltaX == 0 && deltaY == 0 )
		return;

	glutWarpPointer( viewPortCenterX, viewPortCenterY );

	camYaw -= DEF_angleSensitivity * deltaX;
	camPitch -= DEF_angleSensitivity * deltaY * ( mouseIsInverted ? -1.0 : 1.0 );
	clampCamera();

	glutPostRedisplay();
//	displayFunc();
}


void idleFunc()
{
	glutPostRedisplay();
}
