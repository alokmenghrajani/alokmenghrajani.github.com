#include <stdlib.h>
#include "mars.h"
#include <glut.h>
#include <assert.h>
#include <math.h>
#include "textures.h"
#include "camera.h"
#include "my_glutils.h"
#include "robot.h"

/*
	EPFL Computer Graphics Project, Avril 2004
	Alok Menghrajani <alok.menghrajani@epfl.ch>
	Matthieu Broillet <matthieu.broillet@epfl.ch>

	This is the main C file. It will initialize
	the OpenGL library. It will use
	- robot.h, robot.c to create and manipulate the robot
	- mars.h, mars.c to create the landscape, rocks, etc...
	- my_glutils.h, my_glutils.c for helper functions
	  (to create extrusions, revolutions,
	   2d triangle mesh based objects, etc...)

	The scene contains multiple cameras and can be viewed
	in multiple modes.
*/

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

void menu_main(int);
void menu_display(int);
void menu_camera(int);
void menu_control(int);
void menu_goodies(int);
void create_menu(void);
void init(void);

// Callback routines
void display(void);
void key(unsigned char, int, int);
void reshape(int,int);

// Global variables
float rot_val=39.0;
float rot_val2=54.0;
float zoom=5;

int display_mode=1;
int camera_mode = 1;
int control_mode = 1;
int show_axes = 0;
int show_trace = 0;
int above_stone=0;
int took=0;

int menuID_main;
int menuID_display;
int menuID_camera;
int menuID_control;
int menuID_goodies;

int toggle = 1;

// Pour la cam�ra avec la souris
GLfloat lightPos[] = { -3.0, 3.0, 2.0, 1.0 };
extern int	isInMouseDrag;
extern int	viewPortCenterX;
extern int	viewPortCenterY;
extern int	oldCursorID;
extern int	oldCursorX;
extern int	oldCursorY;
extern int	mouseIsInverted;
extern GLfloat	camX;
extern GLfloat	camY;
extern GLfloat	camZ;
extern GLfloat	camYaw;
extern GLfloat	camPitch ;

robot_t *robot = NULL;
mars_t *mars = NULL;
textures_t *textures = NULL;

int main(int argc, char *argv[]) {
	glutInit(&argc, argv);
	/* We want rgb display functionality */
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
	/* Set the window dimensiosn and starting point */
	glutInitWindowSize(640,480);
	glutInitWindowPosition(0,0); 
	/* Set the caption and launch the window */
	glutCreateWindow("Robot - Alok & Matthieu"); 
	/* Create a popup-menu so we can change scene settings */
	create_menu();


	textures = textures_init();
	mars = mars_init(textures);
	robot = robot_init(textures, mars);


	init();

	// Setup callback functions
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(key);
	glutMouseFunc( mouseFunc );

	glutSpecialFunc(specialFunc);
	glutMotionFunc(allMotionFunc);
	glutPassiveMotionFunc(allMotionFunc);
	//MODIFIE glutIdleFunc( idleFunc );

	glutMainLoop();

	return 0;
}

void create_menu(void) {
	menuID_display = glutCreateMenu(menu_display);
	glutAddMenuEntry("wireframe", 1);
	glutAddMenuEntry("flat shading", 2);
	glutAddMenuEntry("gouraud shading", 3);
	menuID_camera = glutCreateMenu(menu_camera);
	glutAddMenuEntry("follow robot", 1);
	glutAddMenuEntry("robot view", 2);
	glutAddMenuEntry("free cam", 3);
	glutAddMenuEntry("mouse", 4);
	menuID_control = glutCreateMenu(menu_control);
	glutAddMenuEntry("vehicule", 1);
	glutAddMenuEntry("arm", 2);
	menuID_goodies = glutCreateMenu(menu_goodies);
	glutAddMenuEntry("show axes", 1);
	glutAddMenuEntry("show trace", 2);
	menuID_main = glutCreateMenu(menu_main);
	glutAddSubMenu("display", menuID_display);
	glutAddSubMenu("camera", menuID_camera);
	glutAddSubMenu("control", menuID_control);
	glutAddSubMenu("goodies", menuID_goodies);
	glutAddMenuEntry("quit", 5);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void menu_main(int i) {
	switch(i) {
		// cases 1-4 are submenus (display, camera, control and goodies)
		case 5:		// quit
			exit(0);
			break;
		default:
			assert(0);
			break;
	}
}
void menu_display(int i) {
	switch(i) {
		case 1:		// wireframe
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glDisable(GL_LIGHTING);
			break;
		case 2:		// flat shading
			glShadeModel(GL_FLAT);
			// we don't have textures yet so:
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			glEnable(GL_LIGHTING);
			break;
		case 3:		// smooth shading (gouraud shading)
			glShadeModel(GL_SMOOTH);
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			glEnable(GL_LIGHTING);
			break;
	}
}

void menu_camera(int i) {
	// modes = follow robot, robot view and free cam
	camera_mode = i;
}

void menu_control(int i) {
	switch(i) {
		case 1:		// vehicule
			robot_armin(robot);
			control_mode = 1;
			break;
		case 2:		// arm
			robot_armout(robot);
			control_mode = 2;
			break;
		default:
			assert(0);
			break;
	}
}

void menu_goodies(int i) {
	switch(i) {
		case 1:		// axes
			show_axes = !show_axes;
			break;
		case 2:		// tyre traces
			show_trace = !show_trace;
			break;
		default:
			assert(0);
			break;
	}
}

void display(void) {
	points3 arm;
	float n, m;
	// Clear the color and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity(); // Clear matrix stack

  switch (camera_mode) {
	  float x, y, z;
	  // modes = follow robot, robot view and free cam
	case 1:
		x = 500.0 / zoom * sin(rot_val2 * PI / 180) * cos(rot_val * PI / 180);
		z = 500.0 / zoom * sin(rot_val2 * PI / 180) * sin(rot_val * PI / 180);
		y = 500.0 / zoom * cos(rot_val2 * PI / 180) + ground_height(mars, robot->x, robot->y);
		gluLookAt(x+robot->x, y, z+robot->y, robot->x, ground_height(mars, robot->x, robot->y), robot->y, 0, 1, 0);
		break;
	case 2:
		gluLookAt(0, 0, 0, 1, 0, 0, 0, 1, 0);
		glTranslatef(-1.0, 0.25, 0);
		glRotatef(-robot->camera_rotx, 0, 0, 1);
		glRotatef(robot->camera_roty, 0, 1, 0);
		glTranslatef(-4, robot->camera_height+0.5, 0);

		glRotatef(robot->dir, 0, 1, 0);
		glTranslatef(0, -4, 0);
		{
			float alpha, beta;
			
			alpha = atan2(robot->current_norm.z, robot->current_norm.x);
			beta = atan2(robot->current_norm.y, sqrt(pow(robot->current_norm.x, 2) + pow(robot->current_norm.z, 2)));

			glRotatef(-alpha * 180.0 / PI, 0, 1.0, 0);
			glRotatef(90.0 - beta * 180.0 / PI, 0, 0, 1.0);
			glRotatef(alpha * 180.0 / PI, 0, 1.0, 0);
			glTranslatef(-robot->x, -ground_height(mars, robot->x, robot->y), -robot->y);
		}

		break;
	case 3:
		gluLookAt(50, 50, 100, 0, 0, 0, 0, 1, 0);
		glRotatef(rot_val2-90.0, 1, 0, 0);
		glRotatef(rot_val, 0, 1, 0);
		break;
	case 4:
		// Start 8 units (meters?) back from the origin and off the floor a bit.
		camZ = 8.0;
		camY = 1.8;

		// Reset the model/view matrix to default.
		glMatrixMode( GL_MODELVIEW_MATRIX );
		glLoadIdentity();
		// Apply the camera now.  Note that we use the 'inverse' of the usual order, and
		// we use the negative values for the actual movements/rotations!  [We are not
		// moving the camera, after all.  We're moving EVERYTHING ELSE the other way....]
		glRotatef( -camPitch, 1.0, 0.0, 0.0 );
		glRotatef( -camYaw, 0.0, 1.0, 0.0 );
		glTranslatef( -camX, -camY, -camZ );
		// Make sure the light is stationary (must be done each frame, after the camera).
		glLightfv( GL_LIGHT0, GL_POSITION, lightPos );
		glColor3f(1,0,0);
		glPushMatrix();
	    glTranslatef(0,5,0);
	    //glutSolidTorus(1,1.5,12,20);
		glPopMatrix();
		//MODIFIE glScalef(100,100,100);
		//MODIFIE drawPlane();
		//MODIFIE glutSwapBuffers();
	break;
  }

  /* draw the robot */
  robot_draw(robot, mars);

  n = cos(robot->dir * PI / 180.0) * robot->arm_x + sin(robot->dir * PI / 180.0) * robot->arm_y;
  m = sin(robot->dir * PI / 180.0) * robot->arm_x - cos(robot->dir * PI / 180.0) * robot->arm_y;
  arm.x = robot->x+n; arm.y = 0; arm.z = robot->y+m;
  if(fabs(arm.x-10.0)<1 && fabs(arm.z-30.0)<1 ){
	above_stone=1;	
  }
  if (above_stone==1 && robot->arm_height==1 && robot->arm_angle==30){
    took=1;
  }

  if (show_trace) {
		points3 t;
		float n, m;
		n = cos(robot->dir * PI / 180.0) + sin(robot->dir * PI / 180.0) * 5.5;
		m = sin(robot->dir * PI / 180.0) - cos(robot->dir * PI / 180.0) * 5.5;
		t.x = robot->x+n; t.y = ground_height(mars, robot->x+n, robot->y+m); t.z = robot->y+m;
		tracer_add(robot->tracer_fl, &t);

		n = cos(robot->dir * PI / 180.0) - sin(robot->dir * PI / 180.0) * 5.5;
		m = sin(robot->dir * PI / 180.0) + cos(robot->dir * PI / 180.0) * 5.5;
		t.x = robot->x+n; t.y = ground_height(mars, robot->x+n, robot->y+m); t.z = robot->y+m;
		tracer_add(robot->tracer_fr, &t);

		n = -4.0 * cos(robot->dir * PI / 180.0) - sin(robot->dir * PI / 180.0) * 5.5;
		m = -4.0 * sin(robot->dir * PI / 180.0) + cos(robot->dir * PI / 180.0) * 5.5;
		t.x = robot->x+n; t.y = ground_height(mars, robot->x+n, robot->y+m); t.z = robot->y+m;
		tracer_add(robot->tracer_br, &t);

		n = -4.0 * cos(robot->dir * PI / 180.0) + sin(robot->dir * PI / 180.0) * 5.5;
		m = -4.0 * sin(robot->dir * PI / 180.0) - cos(robot->dir * PI / 180.0) * 5.5;
		t.x = robot->x+n; t.y = ground_height(mars, robot->x+n, robot->y+m); t.z = robot->y+m;
		tracer_add(robot->tracer_bl, &t);

		tracer_draw(robot->tracer_fr);
		tracer_draw(robot->tracer_fl);
		tracer_draw(robot->tracer_br);
		tracer_draw(robot->tracer_bl);
  }

  mars_draw(mars, robot);

  if (show_axes) {
	glColor3f(1,0,0);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(1000,0,0);
	glEnd();
  
	glColor3f(0,1,0);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(0,1000,0);
	glEnd();

	glColor3f(0,0,1);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(0,0,1000);
	glEnd();
  }

  glFlush(); // Makes sure that we output the model to the graphics card
  glutSwapBuffers();
  glutPostRedisplay();
}

// Called when a key is pressed
void key(unsigned char k, int x, int y) {
  if (k=='t') {
    toggle = !toggle;
    if (toggle) {
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glDisable(GL_LIGHTING);
    } else {
	glShadeModel(GL_FLAT);
	// we don't have textures yet so:
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_LIGHTING);
    }
  }

	// THERE ARE MULTIPLE MODES:
	//  w  control the camera
	// asd 
	//  x y zoom
	// r f tilt (robot view)
	// 
	// vehicule mode:
	//  i  control the robot
	// jkl

	// arm mode:
	//  i  control the arm
	// jkl
	// space = grab/release the stone

	/* Robot controls */
	if (k=='j')
	  robot_left(robot);
	if (k=='l')
	  robot_right(robot);
	if (k=='k')
		robot_down(robot);
	if (k=='i')
		robot_up(robot);
	if (k==' ')
		robot_grab(robot, mars);
	/* if (k==',')
		robot_dec(robot);
	if (k=='.')
		robot_inc(robot);
		*/
	/* if (k=='o')
		arm_up(robot);
	if (k=='u')
		arm_down(robot);
	*/

	/* Camera controls */
	if(k=='y')
		zoom-=1;
	if(k=='x')
		zoom+=1;
	if (zoom < 1)
		zoom = 1;
	if (zoom > 20)
		zoom = 20;

	if ((camera_mode == 1) || (camera_mode == 3)) {
		if(k=='a')
			rot_val-=3;
		if(k=='d')
			rot_val+=3;
		if (k=='s')
			rot_val2+=3;
		if (k=='w')
			rot_val2-=3;
		if (rot_val2 > 179.9)
			rot_val2 = 179.9;
		if (rot_val2 < 0.1)
			rot_val2 = 0.1;
	} else if (camera_mode == 2) {
		if (k=='a')
			robot->camera_roty-=5;
		if (k=='d')
			robot->camera_roty+=5;
		if (k=='w')
			robot->camera_height=MAX(0.5, robot->camera_height-0.1);
		if (k=='s')
			robot->camera_height=MIN(2.0, robot->camera_height+0.1);
		if (k=='r')
			robot->camera_rotx=MIN(10.0, robot->camera_rotx+1);
		if (k=='f')
			robot->camera_rotx=MAX(-50.0, robot->camera_rotx-1);
	} else if (camera_mode == 4) {
		enterMouseDrag( 0, 0 );
		// Move forwards.
		if (k=='w')
			dollyCamera( DEF_dollyStepSize, 0.0 );
		// Move backwards.
		if (k=='s')
			dollyCamera( DEF_dollyStepSize, 180.0 );
		// Strafe left.
		if (k=='a')
			dollyCamera( DEF_dollyStepSize, 90.0 );
		// Strafe right.
		if (k=='d')
			dollyCamera( DEF_dollyStepSize, 270.0 );
		// Toggle 'inverted' mouse.
		if (k=='z')
			mouseIsInverted = !mouseIsInverted;
		if (k=='q')// ESC key.
			exitMouseDrag(0, 0);
			//exit( 0 );
	}
}

// If the window is resized, we need to recompute our viewport and aspect ratio.
void reshape(int width,int height) {
	glViewport(0,0,width,height); // Reset The Current Viewport
 
	glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
	glLoadIdentity(); // Reset The Projection Matrix

	// 50.0 degree FOV, aspect correction, near clip at 1.0, far clip at 1000.0.
	if( height < 1 )
		height = 1;
	gluPerspective( 50.0, (double)width /(double)height, 1.0, 2000.0 );

	glMatrixMode( GL_MODELVIEW );
	//MODIFIE 	glLoadIdentity(); // Reset The Modelview Matrix
	viewPortCenterX = width / 2;
	viewPortCenterY = height / 2;
}


void init(void) {
	
	GLfloat diffuseLight[] = { 0.7, 0.7, 0.7, 1.0 };	// RGBA, les 3 premiers param�tres permettent de changer la couleur et l'intensit� de la lumi�re
	GLfloat ambientLight[] = { 0.5, 0.5, 0.5, 1.0 };	// Definit l'intensit� et la couleur pour la composante ambiante
	GLfloat specularLight[] = { 0.7, 0.7, 0.7, 1.0 };	// Pour la composante sp�culaire
	GLfloat spectre[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat lightPos[] = { 0.0, 10.0, 0.0, 1.0 };	// Pour la position de la source de la lumi�re

	glClearColor(0,0,0,0);
	/* z buffer stuff */
	glClearDepth(1.0);			// Enables Clearing Of The Depth Buffer
	glDepthFunc(GL_LESS);		// The Type Of Depth Test To Do
	glEnable(GL_DEPTH_TEST);	// Enables Depth Testing
  
	/* The default mode will be wireframe */
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glFrontFace(GL_CCW);			// Counterclockwise polygons face out
	glEnable(GL_NORMALIZE);
	glCullFace( GL_BACK ); //AJOUTE
	glEnable(GL_CULL_FACE);

	/* For wireframe we don't want any lighting (so we don't call
	   glEnable(GL_LIGHTING) here), but we will still
		place the lights for afterwards */
	glEnable(GL_LIGHT0);
	
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
	//glLightfv(GL_LIGHT0, GL_SPECULAR, specularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT, GL_SPECULAR, spectre);
	glMateriali(GL_FRONT, GL_SHININESS, 128);
}

