#include "flat_shading.h"
#include <math.h>

void normalize(points3 *vector) {
	GLfloat length = sqrt(vector->x * vector->x  + vector->y * vector->y + vector->z * vector->z);
	if (length == 0.0)
	   length = 1.0;
	vector->x /= length;
   vector->y /= length;
   vector->z /= length;
}

void calcNormal(points3 *p1, points3 *p2, points3 *p3, points3 *n ) {
	points3 v1;
	points3 v2;

	// Create two vectors from the three points
	v1.x = p2->x - p1->x;
	v1.y = p2->y - p1->y;
	v1.z = p2->z - p1->z;
	
	v2.x = p3->x - p2->x;
	v2.y = p3->y - p2->y;
	v2.z = p3->z - p2->z;
  
	n->x = v1.y * v2.z - v1.z * v2.y;
	n->y = v1.z * v2.x - v1.x * v2.z;
	n->z = v1.x * v2.y - v1.y * v2.x;

// normalize(n); // glnormalize is enabled...
}
