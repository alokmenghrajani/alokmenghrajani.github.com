#ifndef CAMERA__H
#define CAMERA__H

#include <glut.h>
#include <GL/gl.h>
#include <math.h>

#define M_PI       3.14159265358979323846
#define DEF_dollyStepSize			0.5
#define DEF_angleSensitivity		0.2

#define TRUE 1
#define FALSE 0


void enterMouseDrag(int x,int y);
void exitMouseDrag(int x,int y);
void clampCamera();
void dollyCamera( GLfloat dollyBy, GLfloat dollyAngle );
void specialFunc(int key,int x,int y);
void allMotionFunc( int x, int y );
void idleFunc();
void mouseFunc( int button, int state, int x, int y );

#endif /* CAMERA__H */
