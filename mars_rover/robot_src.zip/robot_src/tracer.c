#include <stdlib.h>
#include "tracer.h"

tracer_t *tracer_init(int size) {
	tracer_t *t = (tracer_t*) malloc(sizeof(tracer_t));
	t->current_size = size;
	t->wrapped = 0;
	t->next_value = 0;
	t->buf = (points3*) malloc(sizeof(points3) * size);
	return t;
}
void tracer_add(tracer_t *t, points3* p) {
	int j;
	float d;
	if (t->wrapped || t->next_value>0) {
		if (t->next_value == 0) {
			j = t->current_size - 1;
		} else {
			j = t->next_value - 1;
		}
		d = (p->x - t->buf[j].x)*(p->x - t->buf[j].x)+
			(p->y - t->buf[j].y)*(p->y - t->buf[j].y)+
			(p->z - t->buf[j].z)*(p->z - t->buf[j].z);
		if (d<10.0)
			return;
	}
	t->buf[t->next_value].x = p->x;
	t->buf[t->next_value].y = p->y;
	t->buf[t->next_value].z = p->z;
	t->next_value++;
	if (t->next_value == t->current_size) {
		t->next_value = 0;
		t->wrapped = 1;
	}
}

void tracer_draw(tracer_t *t) {
	int i, j, k;
	if ((t->next_value < 2) && (!t->wrapped)) {
		return;
	}
	if (t->wrapped) {
		i = t->next_value;
	} else {
		i = 0;
	}
	if (t->next_value == 0) {
		j = t->current_size - 1;
	} else {
		j = t->next_value - 1;
	}
	if (i==t->current_size-1) {
		k = 0;
	} else {
		k = i + 1;
	}

	glColor3f(4.0/255, 184.0/255, 178.0/255);
	while (i!=j) {
		points3 *a, *b;
		a = &t->buf[i];
		b = &t->buf[k];
		glBegin(GL_LINES);
		glVertex3fv((GLfloat*)&t->buf[i]);
		glVertex3fv((GLfloat*)&t->buf[k]);
		glEnd();
		i=k;
		k++;
		if (k==t->current_size) {
			k=0;
		}
	}
}