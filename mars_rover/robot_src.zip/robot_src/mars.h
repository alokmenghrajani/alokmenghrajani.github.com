#ifndef MARS__H
#define MARS__H

#include <glut.h>
#include <time.h>
#include "my_glutils.h"
#include "textures.h"

typedef struct _stone_t {
	float posx;
	float posz;
	float size;
	int layers;
	int points;
	int taken;
	int takeable;
	points3* verts;
	points3* norms1;
	points3* norms2;
} stone_t;

typedef struct _mars_t {
	revol* volcano;
	stone_t *stone;
	stone_t *stone2;
	textures_t *texture;
	int	ground_size;
	float	*ground;
	points3* ground_norms;
	points3* ground_gouraud;
} mars_t;

struct _robot_t;

mars_t *mars_init(textures_t *t);
void mars_draw(mars_t *mars, struct _robot_t *robot);
stone_t *stone_init(mars_t *mars, int layers, int points, float d, float posx, float posz, float size);
void stone_draw(mars_t *mars, struct _robot_t *robot, stone_t *st);
void ground(mars_t*);
void drawAntena(mars_t*);
float ground_height(mars_t *mars, float x, float z);
void ground_normal(mars_t* mars, float x, float z, points3* n);


#endif /* MARS__H */
