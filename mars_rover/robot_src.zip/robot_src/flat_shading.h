#ifndef FLAT_SHADING__H
#define FLAT_SHADING__H

#include <glut.h>
#include "my_glutils.h"

void normalize(points3 *vector);
void calcNormal(points3 *p1, points3 *p2, points3 *p3, points3 *n );

#endif /* FLAT_SHADING__H */
