#ifndef ROBOT__H
#define ROBOT__H

#include "tracer.h"
#include <time.h>
#include "textures.h"
#include "mars.h"

float arm_height2;
float arm_x2;
float arm_z2;

typedef struct _robot_t {
	float x;    /* pos du centre du robot */
	float y;
	float dir;    /* direction du robot */
	float tilt_z;
	float tilt_x;
	float wheel_angle;
	float speed;

	points3 current_norm;

	/* arm stuff */
	int   arm_inside;
	stone_t* arm_free;
	int arm_taking;
	float arm_x;
	float arm_y;
	float arm_angle;
	float arm_height;

	/* camera stuff */
	float camera_roty;
	float camera_rotx;
	float camera_height;

	/* Following variables are used for physics/geometry
	   calculations */
	float wheel_fr;
	float wheel_fl;
	float wheel_br;
	float wheel_bl;

	/* floor level for each wheel + arm */
	float ground_fl;
	float ground_fr;
	float ground_bl;
	float ground_br;
	float ground_arm;

	tracer_t *tracer_fr;
	tracer_t *tracer_fl;
	tracer_t *tracer_br;
	tracer_t *tracer_bl;

	clock_t previous_time;
	textures_t *texture;
} robot_t;

robot_t* robot_init(textures_t *t, mars_t *mars);
/* routine to draw the robot, centered at origin */
void robot_draw(robot_t *r, mars_t *mars);
/* routine to control the robot */
void robot_right(robot_t*);
void robot_left(robot_t*);
void robot_up(robot_t*);
void robot_down(robot_t*);
void robot_dec(robot_t *r);
void robot_inc(robot_t *r);
void arm_up(robot_t*);
void arm_down(robot_t*);
void robot_armin(robot_t*);
void robot_armout(robot_t*);
void robot_grab(robot_t*, mars_t*);

#endif /* ROBOT__H */
