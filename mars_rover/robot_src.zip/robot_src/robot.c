#include <stdlib.h>
#include "my_glutils.h"
#include <assert.h>
#include <math.h>
#include "robot.h"

/* robot parameters for physics/geometry */
/* ROBOT_LENGTH = length between the front wheels and
   back wheels axis
   ROBOT_WIDTH = distance between left and right wheels
   ROBOT_WHEEL = wheel size
*/


/* arm_taking states:
   0 -> do nothing (hand is open)
   1 -> goto exact stone position
	2 -> lower arm
	3 -> close hand
	  if grab=SUCCESS (always case now, but imagine robot is also moving ;)
	      goto state 4, else goto state 0
	4 -> higher arm
*/

#define ROBOT_LENGTH 7.0
#define ROBOT_WIDTH 5.0
#define ROBOT_WHEEL 2.0
#define ROBOT_SUSPENSION 2.0

/* profile for body */
GLfloat body_2d[] = {
	-7, 2.5,
	 2.0, 2.5,
	 5.0, 1.5,
	 5.0,-1.5,
	 2.0,-2.5,
    -7,-2.5
};

GLfloat yvect[] = {0,-1.0,0};

robot_t* robot_init(textures_t *t, mars_t* mars) {
	robot_t *r = (robot_t*) malloc(sizeof(robot_t));
	r->texture = t;
	r->x = 70.0;
	r->y = 40.0;
	r->dir = 0.0;
	r->speed = 0.0;
	r->wheel_angle = 0.0;

	ground_normal(mars, r->x, r->y, &(r->current_norm));

	r->wheel_fr = 0.0;
	r->wheel_fl = 0.0;
	r->wheel_br = 0.0;
	r->wheel_bl = 0.0;
	
	r->ground_arm = 3.0;

	r->arm_inside = 1;
	r->arm_free = NULL;
	r->arm_taking = 0;

	r->arm_angle = 75.0;
	r->arm_x = -1.0;
	r->arm_y = 0.0;
	r->arm_height = 0.0;

	r->camera_height = 0.5;
	r->camera_roty = 0.0;
	r->camera_rotx = 0.0;

	r->tracer_fr = tracer_init(100);
	r->tracer_fl = tracer_init(100);
	r->tracer_br = tracer_init(100);
	r->tracer_bl = tracer_init(100);

	r->previous_time = clock();
	return r;
}

void robot_cleanup(robot_t *r) {
	assert(r!=NULL);
	free(r);
}

/* Draws one wheel.
     Angle: positive = wheel will be rotated right
     Suspension: 0.0 (compressed) to 1.0 (uncompressed)
*/
void draw_wheel(float dir, float rot, float suspension) {
	GLUquadricObj *q;
	glColor3f(4.0/255, 184.0/255, 178.0/255);
	q = gluNewQuadric();
	glPushMatrix();
	/* main axe */
	gluCylinder(q, 0.25, 0.25, 2.0, 10, 1);
	glTranslatef(0, 0, 2.0+0.25);
	/* connection 1 */
	gluSphere(q, 0.25, 7, 7);
	glRotatef(90.0, 1, 0, 0);
	glTranslatef(0, 0, 0.25);
	/* suspension */
	gluCylinder(q, 0.25, 0.25, ROBOT_SUSPENSION * suspension, 10, 1);
	glTranslatef(0, 0, ROBOT_SUSPENSION * suspension+0.25);
	/* connection 2 */
	gluSphere(q, 0.25, 7, 7);
	glRotatef(-90.0, 1, 0, 0);
	glTranslatef(0, 0, 0.25);
	glRotatef(-dir, 0, 1, 0);
	/* small axe */
	gluCylinder(q, 0.25, 0.25, 0.5, 10, 1);
	glTranslatef(0, 0, 0.5);
	glRotatef(-rot, 0, 0, 1);
	/* wheel */
	glColor3f(10.0/255, 52.0/255, 14.0/255);
	//gluQuadricDrawStyle(q, GLU_FILL);
	//gluQuadricNormals(q, GLU_FLAT);
	gluCylinder(q, ROBOT_WHEEL, ROBOT_WHEEL, 0.5, 20, 1);
	gluCylinder(q, 0, ROBOT_WHEEL, 0.01, 20, 1);
	glRotatef(180, 0, 1, 0);
	glTranslatef(0, 0, -0.5);
	gluCylinder(q, 0, ROBOT_WHEEL, 0.01, 20, 1);
	//gluDisk(q, ROBOT_WHEEL, ROBOT_WHEEL, 10, 1);
	glPopMatrix();
	gluDeleteQuadric(q);
}

void draw_finger(float ang) {
	GLUquadricObj *q;
	glPushMatrix();
	q = gluNewQuadric();
	glRotatef(ang, 1, 0, 0);
	glTranslatef(0, 0, 0.25);
	gluCylinder(q, 0.25, 0.25, 1.0, 10, 1);
	glTranslatef(0, 0, 1.0 + 0.25);
	gluSphere(q, 0.25, 7, 7);
	glRotatef(-90.0+ang, 1, 0, 0);
	glTranslatef(0, 0, 0.25);
	gluCylinder(q, 0.25, 0.1, 1.0, 10, 1);
	gluDeleteQuadric(q);
	glPopMatrix();
}

void robot_draw(robot_t *r, mars_t *mars) {
	float angle_l, angle_r;
	float t;
	points3 norm;
	clock_t now = clock();
	float elapsed;
	assert(r!=NULL);
	glPushMatrix();

	/* calculate elapsed time */
	elapsed = now - r->previous_time;
#ifndef _WIN32
	elapsed /= 1000.0; // correction for solaris/windows difference
							 // in how the time is returned by clock().
#endif
	r->previous_time = now;
	/* calculate arm position */
	if (r->arm_taking == 1) {
		if (r->arm_height < 2.0) {
			r->arm_height += 0.2;
		} else {
			r->arm_taking = 2;
		}
	} else if (r->arm_taking == 2) {
		if (r->arm_free->takeable) {
			r->arm_free->taken = 1;
			r->arm_taking = 3;
		} else {
			r->arm_height = 0.0;
			r->arm_free = NULL;
			r->arm_taking = 0;
		}
	} else if (r->arm_taking == 3) {
		if (r->arm_angle > 30.0) {
			r->arm_angle -= 5;
		} else {
			r->arm_taking = 4;
		}
	} else if (r->arm_taking == 4) {
		if (r->arm_height > 0.0) {
			r->arm_height -= 0.2;
		} else {
			r->arm_taking = 5;
		}
	}

	/* calculate wheel angles */
	if (r->wheel_angle == 0.0) {
		/* calculate distance covered by each wheel,
		   and then deduct angle to add */
		float d = r->speed * elapsed / 1000.0;
		float dr = d / (2.0 * PI * ROBOT_WHEEL) * 360.0;
		r->wheel_bl += dr;
		r->wheel_br += dr;
		r->wheel_fl += dr;
		r->wheel_fr += dr;
		angle_r = 0.0;
		angle_l = 0.0;
		r->x += cos(r->dir * PI / 180.0) * d;
		r->y += sin(r->dir * PI / 180.0) * d;
	} else {
		float arc;
		float dr1, dr2, d1, d2;
		float x, y, nx, ny;
		t = ROBOT_LENGTH / tan(r->wheel_angle * PI / 180.0);
		angle_r = atan(ROBOT_LENGTH / (t-ROBOT_WIDTH / 2.0)) * 180.0 / PI;
		angle_l = atan(ROBOT_LENGTH / (t+ROBOT_WIDTH / 2.0)) * 180.0 / PI;
		arc =  r->speed * (elapsed / 1000.0) / (2.0 * PI * t);
		d1 = (t-ROBOT_WIDTH / 2.0) / cos(r->wheel_angle * PI / 180.0) * 2.0 * PI * arc;
		dr1 = d1 / (2.0 * PI * ROBOT_WHEEL) * 360.0;
		d2 = (t+ROBOT_WIDTH / 2.0) / cos(r->wheel_angle * PI / 180.0) * 2.0 * PI * arc;
		dr2 = d2 / (2.0 * PI * ROBOT_WHEEL) * 360.0;
		r->wheel_br += dr1;
		r->wheel_fr += dr1;
		r->wheel_bl += dr2;
		r->wheel_fl += dr2;
		r->dir += arc*360;

		y = t-cos(arc * 2.0 * PI) * t;
		x = sin(arc * 2.0 * PI) * t;
		nx = cos(r->dir * PI / 180.0) * x - sin(r->dir * PI / 180.0) * y;
		ny = sin(r->dir * PI / 180.0) * x + cos(r->dir * PI / 180.0) * y;
		r->x += nx;
		r->y += ny;
	}
		
	glTranslatef(r->x, ground_height(mars, r->x, r->y), r->y);
	 
	ground_normal(mars, r->x, r->y, &norm);
	r->current_norm.x = r->current_norm.x + (norm.x - r->current_norm.x) / 4.0;
	r->current_norm.y = r->current_norm.y + (norm.y - r->current_norm.y) / 4.0;
	r->current_norm.z = r->current_norm.z + (norm.z - r->current_norm.z) / 4.0;

	{
		// transform robot so it is // to plane
		float alpha, beta;
		alpha = atan2(r->current_norm.z, r->current_norm.x);
		beta = atan2(r->current_norm.y, sqrt(pow(r->current_norm.x, 2) + pow(r->current_norm.z, 2)));
		glRotatef(-alpha * 180.0 / PI, 0, 1.0, 0);
		glRotatef(-90.0 + beta * 180.0 / PI, 0, 0, 1.0);
		glRotatef(alpha * 180.0 / PI, 0, 1.0, 0);
	}
	glTranslatef(0, ROBOT_WHEEL+ROBOT_SUSPENSION, 0);
	glRotatef(-r->dir, 0, 1, 0);

	/* draw body */
	glColor3f(4.0/255, 184.0/255, 178.0/255);
	
	glTranslatef(0.0, 1.0, 0.0);
	extrude(6, body_2d, yvect, 1);
	glTranslatef(0.0, -1.0, 0.0);

	/* draw wheels */
	glTranslatef(1, 0.5, -2.5);
	glRotatef(180, 0, 1, 0);
	/* front left */
	draw_wheel(angle_l, -r->wheel_fl, 1.0);
	glTranslatef(ROBOT_LENGTH, 0, 0);
	/* back left */
	draw_wheel(-angle_l, -r->wheel_bl, 1.0);
	glRotatef(180, 0, 1, 0);
	glTranslatef(0, 0, 5);
	/* back right */
	draw_wheel(-angle_r, r->wheel_br, 1.0);
	glTranslatef(ROBOT_LENGTH, 0, 0);
	/* front right */
	draw_wheel(angle_r, r->wheel_fr, 1.0);
	glTranslatef(-1, -0.5, -2.5);

	/* draw arm */
	if (!r->arm_inside || (r->arm_free != NULL)) {
		GLUquadricObj *q;
		glColor3f(80.0/255, 40.0/255, 254.0/255);
		glPushMatrix();
		glRotatef(90, 1, 0, 0);
		glTranslatef(r->arm_x, r->arm_y, 0);
		q = gluNewQuadric();
		gluCylinder(q, 0.25, 0.25, r->ground_arm - 2.7 + r->arm_height, 10, 1);
		glTranslatef(0, 0, r->ground_arm - 2.7 + 0.25 + r->arm_height);
		gluSphere(q, 0.25, 7, 7);
		/* draw fingers */
		draw_finger(r->arm_angle);
		glRotatef(90, 0, 0, 1);
		draw_finger(r->arm_angle);
		glRotatef(90, 0, 0, 1);
		draw_finger(r->arm_angle);
		glRotatef(90, 0, 0, 1);
		draw_finger(r->arm_angle);
		gluDeleteQuadric(q);
		glPopMatrix();
	}

	/* draw camera */
	{
		GLUquadricObj *q;
		glColor3f(227.0/255, 1.0/255, 224.0/255);
		q = gluNewQuadric();
		glTranslatef(4-0.125, 0, -0.125);
		glRotatef(90, 1, 0, 0);
		box(0.25, 0.25, r->camera_height);
		glTranslatef(0.125, 0.125, r->camera_height+0.125);
		gluSphere(q, 0.25, 7, 7);
		glTranslatef(0, 0, 0.125);
		glRotatef(r->camera_roty, 0, 0, 1);
		glRotatef(r->camera_rotx, 0, 1, 0);
		glTranslatef(-1, -0.5, 0);
		box(2, 1, 1);
		glTranslatef(2, 0.5, 0.5);
		pyramid(0.5, 0.5, 0.5);
		gluDeleteQuadric(q);
	}

	glPopMatrix();

	// testing
/*	{
		GLUquadricObj *q;
		glColor3f(1.0, 0.0, 0.0);
		q = gluNewQuadric();
		glPushMatrix();
		glTranslatef(r->x, ground_height(mars, r->x, r->y), r->y);
		gluSphere(q, 1, 7, 7);
		gluDeleteQuadric(q);
		glPopMatrix();
	}
	*/
}

void robot_right(robot_t *r) {
	if (r->arm_inside) {
		r->wheel_angle+=1;
		if (r->wheel_angle > 30)
			r->wheel_angle = 30;
	} else {
		r->arm_y += .2;
		if (r->arm_y > 2)
			r->arm_y = 2;
	}
	arm_z2 = r->arm_y;
}

void robot_left(robot_t *r) {
	if (r->arm_inside) {
		r->wheel_angle-=1;
		if (r->wheel_angle < -30)
			r->wheel_angle = -30;
	} else {
		r->arm_y -= .2;
		if (r->arm_y < -2)
			r->arm_y = -2;
	}
	arm_z2 = r->arm_y;
}

void robot_up(robot_t* r) {
	if (r->arm_inside) {
		r->speed+=1;
		if (r->speed > 10)
			r->speed = 10;
	} else {
		r->arm_x += .2;
		if (r->arm_x > 1)
			r->arm_x = 1;
	}
	arm_x2 = r->arm_x;
}

void robot_down(robot_t* r) {
	if (r->arm_inside) {
		r->speed-=1;
		if (r->speed < -5)
			r->speed = -5;
	} else {
		r->arm_x -= .2;
		if (r->arm_x < -3)
			r->arm_x = -3;
	}
	arm_x2 = r->arm_x;

}

void robot_inc(robot_t *r) {
	if (!r->arm_inside) {
		r->arm_angle += 5;
		if (r->arm_angle > 75)
			r->arm_angle = 75;
	}
}

void robot_dec(robot_t *r) {
	if (!r->arm_inside) {
		r->arm_angle -= 5;
		if (r->arm_angle < 30)
			r->arm_angle = 30;
	}
}

void arm_up(robot_t *r){
	if(!r->arm_inside) {
		r->arm_height += .2;
		if (r->arm_height > 1)
			r->arm_height = 1;
	}
	arm_height2 = r->arm_height;
}

void arm_down(robot_t *r){
	if(!r->arm_inside) {
		r->arm_height -= .2;
		if (r->arm_height < 0)
			r->arm_height = 0;
	}
	arm_height2 = r->arm_height;
}

void robot_armin(robot_t* r) {
	r->arm_inside = 1;
}

void robot_armout(robot_t* r) {
	r->arm_inside = 0;
}

void robot_grab(robot_t *robot, mars_t *mars) {
	// check to see if a stone is there.
	if (robot->arm_free == NULL) {
		if (mars->stone->takeable) {
			robot->arm_free = mars->stone;
			robot->arm_taking = 1;
		} else if (mars->stone2->takeable) {
			robot->arm_free = mars->stone2;
			robot->arm_taking = 1;
		}
	} else {
		mars->stone->taken = 0;
		mars->stone2->taken = 0;
		robot->arm_free = NULL;
		robot->arm_taking = 0;
		robot->arm_angle = 75.0;
	}
}
