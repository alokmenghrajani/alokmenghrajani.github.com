#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "mars.h"
#include "flat_shading.h"
#include "robot.h"

#define GROUND_SIZE 2000
#define FRACTAL_K 4

void generate_fractal(mars_t*);
/*
GLfloat volcan_2d[] = {
	18,0,
	14,1,
	12,4,
	11,8,
	10,10,
	8,12,
	7,12,
	5,10,
	3,9,
	0,9};
*/

GLfloat antena_points[] = {
		0, 0, // point 0
		4, 0, // point 1
		3, 2, // point 2
		0, 3, // point 3
     -3, 2, // point 4
     -4, 0, // point 5
	  -3,-2, // point 6 
	   0,-3, // point 7
	   3,-2, // point 8
	   7, 2, // point 9
	   3, 6, // point 10
	  -3, 6, // point 11
	  -7, 2, // point 12
	  -7,-2, // point 13
	  -3,-6, // point 14
	   3,-6, // point 15
	   7,-2 // point 16
	};

int antena_triangles[] = {
		0, 1, 2,
		0, 2, 3,
		0, 3, 4,
		0, 4, 5,
		0, 5, 6,
		0, 6, 7,
		0, 7, 8,
		0, 8, 1,
		1, 9, 2,
		2, 9, 10,
		3, 2, 10,
		3, 10, 11,
		4, 3, 11,
		4, 11, 12,
		5, 4, 12,
		5, 12, 13,
		6, 5, 13,
		6, 13, 14,
		6, 14, 7,
		7, 14, 15,
		7, 15, 8,
		8, 15, 16,
		8, 16, 1,
		1, 16, 9
	};

mars_t *mars_init(textures_t *t) {
	mars_t *mars = (mars_t*) malloc(sizeof(mars_t));
//	mars->volcano = create_revolution(10, volcan_2d, 360, 16);
	mars->texture = t;
	generate_fractal(mars);
	mars->stone = stone_init(mars, 3, 6, 1, 80, 60, 1);
	mars->stone2 = stone_init(mars, 5, 4, 3, 70, 70, 1);

	return mars;
}

void mars_draw(mars_t* mars, robot_t *robot) {
	assert(mars!=NULL);

	// Draw a little stone
	glColor3f(300.0/255, 150.0/255, 89.0/255);
	stone_draw(mars, robot, mars->stone);

	// Draw a big stone
	glColor3f(238.0/255, 207.0/255, 100.0/255);
	stone_draw(mars, robot, mars->stone2);

	// Draw ground
	ground(mars);
	
	/* draw a volcano using revolution (lathe) */
/*	glPushMatrix();
	glTranslatef(180,0,120);
	glScalef(5,5,5);
	glColor3f(242.0/255, 68.0/255, 0.0/255);
	draw_revolution(mars->volcano, mars->texture->texture[TEXTURE_VOLCANO]);
	glPopMatrix();
*/

	/* draw an antena using triangle mesh technique */
	drawAntena(mars);
}

float parabola(float x, float y) {
	return ((x*x + y*y)/10.0);
}

void parabola_gradient(float x, float y, points3* r) {
	/* used for gouraud shading */
	r->x = -2.0*x / 10.0;
	r->y = -2.0*y / 10.0;
	r->z = 1.0;
}

void drawAntena(mars_t *mars) {
	GLUquadricObj *q;
	float h;
	glColor3f(200.0/255, 190.0/255, 186.0/255);
	glPushMatrix();
	q = gluNewQuadric();
	h = ground_height(mars, -40, -40);
	glTranslatef(-40,20+h,-40);
	drawMeshTriangle(24, antena_points, antena_triangles, parabola, parabola_gradient, 0);
	glFrontFace(GL_CW);
	drawMeshTriangle(24, antena_points, antena_triangles, parabola, parabola_gradient, 1);
	glFrontFace(GL_CCW);
	glTranslatef(0, 0, -0.5);
	gluSphere(q, 1.0, 7, 7);
	glRotatef(90, 1, 0, 0);
	glTranslatef(0, 0, 1);
	glRotatef(180, 0, 1, 0);
	gluCylinder(q, 1, 0, 0.01, 10, 1);
	glRotatef(180, 0, 1, 0);
	gluCylinder(q, 1, 1, 19, 10, 1);
	glPopMatrix();
}

stone_t *stone_init(mars_t *mars, int layers, int points, float d, float posx, float posz, float size) {
	int i, j, t;
	float x, y, z;
	points3 *p1, *p2, *p3, *p4, *n, top;
	stone_t *st = (stone_t*) malloc(sizeof(stone_t));
	st->layers = layers;
	st->points = points;
	st->posx = posx;
	st->posz = posz;
	st->size = size;
	st->taken = 0;
	st->takeable = 0;

	st->verts = (points3*) malloc(sizeof(points3) * layers * points);
	st->norms1 = (points3*) malloc(sizeof(points3) * (layers-1) * points * 2);
	st->norms2 = (points3*) malloc(sizeof(points3) * points);

	/* calculate points  */
	for (i=0; i<layers; i++) {
		y = (float) i / (float) (layers-1) * size;
		for (j=0; j<points; j++) {
			float r = (float) rand() / (float) RAND_MAX * 0.5 - 0.25;
			float inter;

			x = (0.5+r) * size * cos(2.0 * 3.14159 / points * j);
			z = (0.5+r) * size * sin(2.0 * 3.14159 / points * j);
			st->verts[i*points+j].x = x;
			inter = 1.0 / (float) (layers-1) * size;
			if (i==0) {
				r = 0.0;
			} else {
				r = (float) rand() / (float) RAND_MAX * inter - inter / 2.0;
			}

			st->verts[i*points+j].y = y + r;
			st->verts[i*points+j].z = z;
		}
	}
	/* calculate norms */
	for (i=0; i<(layers-1); i++) {
		for (j=0; j<points; j++) {
			if (j==0) {
				t = points-1;
			} else {
				t = j-1;
			}
			n = &st->norms1[(i*points + j) * 2];
			p1 = &st->verts[i*points + j];
			p2 = &st->verts[(i+1)*points + j];
			p3 = &st->verts[(i+1)*points + t];
			p4 = &st->verts[i*points + t];
			calcNormal(p1, p3, p2, n); 
			n = &st->norms1[(i*points + j) * 2+1];
			calcNormal(p1, p4, p3, n); 
		}
	}
	/* Add the top part of the stone */
	for (i=0; i<points; i++) {
		top.x = 0; top.y = size; top.z = 0;
		if (i==0) {
			t=points-1;
		} else {
			t = i-1;
		}
		p1 = &top;
		p2 = &st->verts[(layers-1)*points + i];
		p3 = &st->verts[(layers-1)*points + t];
		n = &st->norms2[i];
		calcNormal(p1, p2, p3, n); 
	}
	
	return st;
}

void stone_draw(mars_t *mars, robot_t *robot, stone_t *st) {
	int i, j, t;
	float f, lowest = 10000.0;
	points3 *n, *p1, *p2, *p3, *p4, top;
	float tn, tm;
	points3 arm;
#ifdef _WIN32
	clock_t now = clock();
#else
	struct timeval now;
	gettimeofday(&now, NULL);
#endif

	assert(st!=NULL);

	glPushMatrix();	
	// calculate where to place the stone (lowest ground point)
	for (j=0; j<st->points; j++) {
		n = &(st->verts[j]);
		f = ground_height(mars, n->x + st->posx, n->z + st->posz);
		if (f < lowest) {
			lowest = f;
		}
	}

	/* If robot is above stone, and the robot arm is out
	   and the robot arm is free, then we want to indicate that
		this stone is takable */
	tn = cos(robot->dir * PI / 180.0) * robot->arm_x - sin(robot->dir * PI / 180.0) * robot->arm_y;
   tm = sin(robot->dir * PI / 180.0) * robot->arm_x + cos(robot->dir * PI / 180.0) * robot->arm_y;
   arm.x = robot->x+tn; arm.y = 0; arm.z = robot->y+tm;
	f = pow(arm.x - st->posx, 2) + pow(arm.z - st->posz, 2);   
	if ((f < 1.0) && !robot->arm_inside) {
		st->takeable = 1;
	} else {
		st->takeable = 0;
	}

	if (st->taken) {
		points3 norm;
		float alpha, beta;
		st->posx = arm.x;
		st->posz = arm.z;
		ground_normal(mars, st->posx, st->posz, &norm);
		alpha = atan2(norm.z, norm.x);
		beta = atan2(norm.y, sqrt(pow(norm.x, 2) + pow(norm.z, 2)));
		glTranslatef(st->posx, ground_height(mars, st->posx, st->posz) + 0.2, st->posz);	
		glRotatef(-alpha * 180.0 / PI, 0, 1.0, 0);
		glRotatef(-90.0 + beta * 180.0 / PI, 0, 0, 1.0);
		glRotatef(alpha * 180.0 / PI, 0, 1.0, 0);
		glTranslatef(0, 1.9 - robot->arm_height, 0);
	} else {
		glTranslatef(st->posx, lowest, st->posz);
	}
	
	for (i=0; i<(st->layers-1); i++) {
		for (j=0; j<st->points; j++) {
			if (j==0) {
				t = st->points-1;
			} else {
				t = j-1;
			}
			n = &st->norms1[(i*st->points + j) * 2];
			p1 = &st->verts[i*st->points + j];
			p2 = &st->verts[(i+1)*st->points + j];
			p3 = &st->verts[(i+1)*st->points + t];
			p4 = &st->verts[i*st->points + t];

			glBegin(GL_TRIANGLES);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p1);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p3);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p2);
			glEnd();
			
			n = &st->norms1[(i*st->points + j) * 2 + 1];
			glBegin(GL_TRIANGLES);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p1);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p4);
			glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p3);
			glEnd();
		}
	}
	
	for (i=0; i<st->points; i++) {
		top.x = 0; top.y = st->size; top.z = 0;
		if (i==0) {
			t=st->points-1;
		} else {
			t = i-1;
		}
		p1 = &top;
		p2 = &st->verts[(st->layers-1)*st->points + i];
		p3 = &st->verts[(st->layers-1)*st->points + t];
		n = &st->norms2[i];
		glBegin(GL_TRIANGLES);
		glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p1);
		glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p2);
		glNormal3fv((GLfloat*)n); glVertex3fv((GLfloat*)p3);
		glEnd();
	}
	glPopMatrix();

	if (st->takeable && (robot->arm_free==NULL)) {
		points3 norm;
		GLUquadricObj *q = gluNewQuadric();
		float alpha, beta, s;
		glPushMatrix();
		ground_normal(mars, st->posx, st->posz, &norm);
		alpha = atan2(norm.z, norm.x);
		beta = atan2(norm.y, sqrt(pow(norm.x, 2) + pow(norm.z, 2)));
		glTranslatef(st->posx, ground_height(mars, st->posx, st->posz), st->posz);	
		glRotatef(-alpha * 180.0 / PI, 0, 1.0, 0);
		glRotatef(-90.0 + beta * 180.0 / PI, 0, 0, 1.0);
		glRotatef(alpha * 180.0 / PI, 0, 1.0, 0);
		glRotatef(90, 1, 0, 0);
		glTranslatef(0, 0.2, 0);
#ifdef _WIN32
		s = (now / 10.0 - floor(now / 10.0) * st->size + st->size;
#else
		s = floor(now.tv_usec / 1E5) / 10.0 * st->size + st->size;
#endif
		gluCylinder(q, s, s, 0.2, 20, 1);
		glFrontFace(GL_CW);
		gluCylinder(q, s, s, 0.2, 20, 1);
		glFrontFace(GL_CCW);
		gluDeleteQuadric(q);
		glPopMatrix();
	}
}

void fractalize(mars_t* mars, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int it) {
	float v1, v2, v3, v4, nv, r, t;
	v1 = mars->ground[(x1+mars->ground_size) % mars->ground_size + ((y1+mars->ground_size) % mars->ground_size) * mars->ground_size];
	v2 = mars->ground[(x2+mars->ground_size) % mars->ground_size + ((y2+mars->ground_size) % mars->ground_size) * mars->ground_size];
	v3 = mars->ground[(x3+mars->ground_size) % mars->ground_size + ((y3+mars->ground_size) % mars->ground_size) * mars->ground_size];
	v4 = mars->ground[(x4+mars->ground_size) % mars->ground_size + ((y4+mars->ground_size) % mars->ground_size) * mars->ground_size];
	t = pow(it, 3) / pow(FRACTAL_K, 3);
	r = ((float) rand() / (float) RAND_MAX) * 1000.0 * t - 500.0 * t;
	nv = (v1 + v2 + v3 + v4) / 4.0 + r;

	assert((x1+x2+x3+x4) % 4 == 0);
	assert((x1+x2+x3+x4) % 4 < mars->ground_size);
	assert((y1+y2+y3+y4) % 4 == 0);
	assert((y1+y2+y3+y4) % 4 < mars->ground_size);
	mars->ground[((x1+x2+x3+x4) / 4) + ((y1 + y2 + y3 + y4) / 4)*mars->ground_size] = nv;
}

float conv_grid_world(mars_t *mars, int x) {
	float r;
	r = (float) x / (float) (mars->ground_size - 1.0) * GROUND_SIZE - GROUND_SIZE / 2.0;
	return r;
}

void generate_fractal(mars_t* mars) {
	int i, j, k, t, size;
	float av;
	k = FRACTAL_K;
	size = pow(2, k) + 1;  // should be 2^k + 1

	mars->ground_size = size;
	mars->ground = malloc(sizeof(float) * size * size);
	assert(mars->ground != NULL);

	// clear ground
	for (i=0; i<size; i++) {
		for (j=0; j<size; j++) {
			mars->ground[i+j*size] = 0.0;
		}
	}
	
	// now iterate k times
	for (t=k; t>0; t--) {
		int w = pow(2, t);
		int a, b;
		// DIAMOND GENERATION STEP
		for (a=0; (a+w) < size; a+=w) {
			for (b=0; (b+w) < size; b+=w) {
				fractalize(mars, a, b, a+w, b, a+w, b+w, a, b+w, t);
			}
		}

		// SQUARE GENERATION STEP
		for (a=w/2; a<size; a+=w) {
			for (b = w/2; b<size; b+=w) {
				fractalize(mars, a-w/2, b-w/2, a, b-w, a+w/2, b-w/2, a, b, t);
				fractalize(mars, a+w/2, b-w/2, a+w, b, a+w/2, b+w/2, a, b, t);
				fractalize(mars, a-w/2, b+w/2, a, b+w, a+w/2, b+w/2, a, b, t);
				fractalize(mars, a-w/2, b-w/2, a-w, b, a-w/2, b+w/2, a, b, t);
			}
		}
	}
	// I want to ground to be on average at level 0
	av = 0.0;
	for (i=0; i<size; i++) {
		for (j=0; j<size; j++) {
			av += mars->ground[i+j*size];
		}
	}
	av = av / (size*size);
	for (i=0; i<size; i++) {
		for (j=0; j<size; j++) {
			mars->ground[i+j*size]+=av;
		}
	}

	// Calculate normals (for flat shading)
	mars->ground_norms = malloc(2 * sizeof(points3) * (mars->ground_size - 1) * (mars->ground_size - 1));
	assert(mars->ground_norms != NULL);

	for (i=0; (i+1) < mars->ground_size; i++) {
		for (j=0; (j+1) < mars->ground_size; j++) {
			float px, py;
			points3 quad[4];
			px = (float) i / (float) (mars->ground_size - 1.0) * GROUND_SIZE - GROUND_SIZE / 2.0;
			py = (float) j / (float) (mars->ground_size - 1.0) * GROUND_SIZE - GROUND_SIZE / 2.0;
			quad[0].x = px; quad[0].y = mars->ground[i+j*mars->ground_size]; quad[0].z = py;
			quad[1].x = px+GROUND_SIZE/(mars->ground_size - 1.0); quad[1].y = mars->ground[i+1+j*mars->ground_size]; quad[1].z = py;
			quad[2].x = px+GROUND_SIZE/(mars->ground_size - 1.0); quad[2].y = mars->ground[i+1+(j+1)*mars->ground_size]; quad[2].z = py+GROUND_SIZE/(mars->ground_size - 1.0);
			quad[3].x = px; quad[3].y = mars->ground[i+(j+1)*mars->ground_size]; quad[3].z = py+GROUND_SIZE/(mars->ground_size - 1.0);
			calcNormal(&quad[0], &quad[3], &quad[1],&(mars->ground_norms[(i+j*(mars->ground_size-1)) * 2]));
			calcNormal(&quad[1], &quad[3], &quad[2],&(mars->ground_norms[(i+j*(mars->ground_size-1)) * 2+1]));
		}
	}
	// Calculate normals for gouroud shading
	mars->ground_gouraud = malloc(sizeof(points3) * mars->ground_size * mars->ground_size);
	assert(mars->ground_gouraud != NULL);

	for (i=0; i<mars->ground_size; i++) {
		for (j=0; j<mars->ground_size; j++) {
			points3 *n1, *n2, *n3, *n4, *n5, *n6;
			int im1, jm1;
			im1 = (i == 0) ? mars->ground_size -1 : i-1;
			jm1 = (j == 0) ? mars->ground_size -1 : j-1;
			
			n1 = &(mars->ground_norms[(im1+jm1*(mars->ground_size-1)) * 2 + 1]);
			n2 = &(mars->ground_norms[(im1+j*(mars->ground_size-1)) * 2 + 1]);
			n3 = &(mars->ground_norms[(im1+j*(mars->ground_size-1)) * 2]);
			n4 = &(mars->ground_norms[(i+jm1*(mars->ground_size-1)) * 2 + 1]);
			n5 = &(mars->ground_norms[(i+jm1*(mars->ground_size-1)) * 2]);
			n6 = &(mars->ground_norms[(i+j*(mars->ground_size-1)) * 2]);
			mars->ground_gouraud[i+j*mars->ground_size].x = n1->x + n2->x + n3->x + n4->x + n5->x + n6->x;
			mars->ground_gouraud[i+j*mars->ground_size].y = n1->y + n2->y + n3->y + n4->y + n5->y + n6->y;
			mars->ground_gouraud[i+j*mars->ground_size].z = n1->z + n2->z + n3->z + n4->z + n5->z + n6->z;
		}
	}
}

void ground_normal(mars_t* mars, float x, float z, points3* n) {
	float a, b, c, d;
	int i, j;
	a = (x + GROUND_SIZE / 2.0) / GROUND_SIZE * (mars->ground_size-1.0);
	b = (z + GROUND_SIZE / 2.0) / GROUND_SIZE * (mars->ground_size-1.0);
	assert(a < mars->ground_size);
	assert(b < mars->ground_size);
	i = floor(a); j = floor(b);
	c = a - floor(a);
	d = b - floor(b);
	if ((1-d) >= c) {
		// first triangle
		n->x = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2].x;
		n->y = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2].y;
		n->z = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2].z;
	} else {
		// second triangle
		n->x = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2 + 1].x;
		n->y = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2 + 1].y;
		n->z = mars->ground_norms[(i+j*(mars->ground_size-1)) * 2 + 1].z;
	}
	normalize(n);
}

float ground_height(mars_t *mars, float x, float z) {
	// convert x, z into grid coordinates
	float a, b, c, d;
	a = (x + GROUND_SIZE / 2.0) / GROUND_SIZE * (mars->ground_size-1.0);
	b = (z + GROUND_SIZE / 2.0) / GROUND_SIZE * (mars->ground_size-1.0);
	assert(a < mars->ground_size);
	assert(b < mars->ground_size);
	c = a - floor(a);
	d = b - floor(b);
	if ((1-d) >= c) {
		// first triangle: floor(a),floor(b):floor(a),floor(b)+1
		float dc, dd;
		int i, j;
		i = floor(a); j = floor(b);
		dc = (mars->ground[i+j*mars->ground_size] - mars->ground[i+1+j*mars->ground_size]) * c;
		dd = (mars->ground[i+j*mars->ground_size] - mars->ground[i+(j+1)*mars->ground_size]) * d;
		return (mars->ground[i+j*mars->ground_size] - dc - dd);
	} else {
		// second triangle
		float dc, dd;
		int i, j;
		i = floor(a); j = floor(b);
		dc = (mars->ground[i+1+(j+1)*mars->ground_size] - mars->ground[i+(j+1)*mars->ground_size]) * c;
		dc += mars->ground[i+(j+1)*mars->ground_size];
		dd = (mars->ground[i+1+(j+1)*mars->ground_size] - mars->ground[i+1+j*mars->ground_size]) * d;
		dd += mars->ground[i+1+j*mars->ground_size];
		return (-mars->ground[i+1+(j+1)*mars->ground_size] + dc + dd);
	}
}

void ground(mars_t *mars) {
	int i, j;
	float px, py;
	points3 quad[4];
	GLint shademodel;
	glGetIntegerv(GL_SHADE_MODEL, &shademodel);

	glPushMatrix();
	glColor3f(180.0/255, 106.0/255, 80.0/255);
	glTranslatef(0, -0.1, 0); // avoid z-fighting

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, mars->texture->texture[TEXTURE_GROUND]);

	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); 
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  
	for (i=0; (i+1) < mars->ground_size; i++) {
		for (j=0; (j+1) < mars->ground_size; j++) {
			px = (float) i / (float) (mars->ground_size - 1.0) * GROUND_SIZE - GROUND_SIZE / 2.0;
			py = (float) j / (float) (mars->ground_size - 1.0) * GROUND_SIZE - GROUND_SIZE / 2.0;
			quad[0].x = px; quad[0].y = mars->ground[i+j*mars->ground_size]; quad[0].z = py;
			quad[1].x = px+GROUND_SIZE/(mars->ground_size - 1.0); quad[1].y = mars->ground[i+1+j*mars->ground_size]; quad[1].z = py;
			quad[2].x = px+GROUND_SIZE/(mars->ground_size - 1.0); quad[2].y = mars->ground[i+1+(j+1)*mars->ground_size]; quad[2].z = py+GROUND_SIZE/(mars->ground_size - 1.0);
			quad[3].x = px; quad[3].y = mars->ground[i+(j+1)*mars->ground_size]; quad[3].z = py+GROUND_SIZE/(mars->ground_size - 1.0);

			if (shademodel == GL_SMOOTH) {
				glBegin(GL_TRIANGLES);
				glTexCoord2f(quad[0].x / 200.0, quad[0].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+j*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[0]);
				glTexCoord2f(quad[3].x / 200.0, quad[3].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+(j+1)*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[3]);
				glTexCoord2f(quad[1].x / 200.0, quad[1].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+1+j*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[1]);
				glEnd();

				glBegin(GL_TRIANGLES);
				glTexCoord2f(quad[1].x / 200.0, quad[1].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+1+j*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[1]);
				glTexCoord2f(quad[3].x / 200.0, quad[3].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+(j+1)*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[3]);
				glTexCoord2f(quad[2].x / 200.0, quad[2].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_gouraud[i+1+(j+1)*mars->ground_size]));
				glVertex3fv((GLfloat*)&quad[2]);
				glEnd();
			} else {
				glBegin(GL_TRIANGLES);
				glTexCoord2f(quad[0].x / 200.0, quad[0].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2]));
				glVertex3fv((GLfloat*)&quad[0]);
				glTexCoord2f(quad[3].x / 200.0, quad[3].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2]));
				glVertex3fv((GLfloat*)&quad[3]);
				glTexCoord2f(quad[1].x / 200.0, quad[1].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2]));
				glVertex3fv((GLfloat*)&quad[1]);
				glEnd();

				glBegin(GL_TRIANGLES);
				glTexCoord2f(quad[1].x / 200.0, quad[1].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2+1]));
				glVertex3fv((GLfloat*)&quad[1]);
				glTexCoord2f(quad[3].x / 200.0, quad[3].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2+1]));
				glVertex3fv((GLfloat*)&quad[3]);
				glTexCoord2f(quad[2].x / 200.0, quad[2].z / 200.0);
				glNormal3fv((GLfloat*) &(mars->ground_norms[(i+j*(mars->ground_size-1))*2+1]));
				glVertex3fv((GLfloat*)&quad[2]);
				glEnd();
			}
		}
	}
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
}
