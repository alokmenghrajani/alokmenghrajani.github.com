(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file contains the definition of our abstract assembly        *)
(*              language. At this point, every instruction is an OPER instruction *)
(*              which has an assembly language string, a list of source           *)
(*              temporaries and a list of destination temporaries. The function   *)
(*              format tkaes that string and replaces every destination           *)
(*              placeholder ('dn, where n is a number) with the assembly language *)
(*              address for the temporary variable.                               *)
(*                                                                                *)
(*              Example:                                                          *)
(*              OPER {A.assem = "add 's0, 's1, 'd0\n";                            *)
(*                    A.src = [munchExp e1, munchExp e2];                         *)
(*                    A.dst = [munchExp e3]}                                      *)
(*                                                                                *)
(*              could be formatted to the string "add [%fp-24], [%fp-28],         *)
(*              [%fp-32]", depending on the temporaries that munchExp returned.   *)
(*              (Note: this is not the proper syntax of the add instruction.      *)
(*                                                                                *)
(* X-reference:  munch.ml, temp.ml                                                 *)


type reg = string
type temp = Temp.temp

type oper_r = {assem: string; dst: temp list; src: temp list}

type instr = OPER of oper_r | LABEL of int

let format (m:temp->string) (p) : string = 
  match p with
    OPER r -> 
(* for each in src *)
(*   search for token string, replace with correct temp variable *)
(* ditto for dst *)
(* return that *)
  let a = ref r.assem in
  let rec f tok l count =
    match l with
      first::rest ->
        let str = tok ^ string_of_int count in
        let r = Str.regexp (str) in
        a := (Str.global_replace r (m first) !a);
        f tok rest (count + 1)
    | [] -> () in
  f "'s" r.src 0;
  f "'d" r.dst 0;
  "\t" ^ !a
  | LABEL a -> "L" ^ (string_of_int a) ^ ":\n"
;;

let format_all (m:temp->string) ol : string = 
  let strlist = List.map (format m) ol in
  String.concat "" strlist
;;









