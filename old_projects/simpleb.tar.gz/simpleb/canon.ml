(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)


module T = Tree

let linearize stmt0 =
  let merge(a, b) =
     match (a, b) with
       (T.NIL, b) -> b
     | (a, T.NIL) -> a
     | (a, b) -> T.SEQ(a, b)
  in 
  let commute (a, b) =
     false
  in
  let rec reorder p =
     match p with
       head::tail -> let (ante_e, e, post_e)=(do_exp head) in
                     let (ante_e2, e2, post_e2) = (reorder tail) in
                     let t=Temp.newtemp() in
                     if commute(ante_e2, e) then 
                        (merge(ante_e, ante_e2), e::e2, merge(post_e, post_e2))
                     else
                        (merge(ante_e, merge(T.MOVE(T.TEMP t, e), ante_e2)), (T.TEMP t)::e2, merge(post_e, post_e2))
      | _ -> (T.NIL, [], T.NIL)
  and reorder_exp(e, build) =
      let (ante_e2, e2, post_e2) = reorder e in
      (ante_e2, build e2, post_e2)
  and reorder_stmt(e, build) =
      let (ante_e2, e2, post_e2) = reorder e in
      merge(ante_e2, merge(build(e2), post_e2))
  and do_stmt(p) =
      (match p with
         T.SEQ(a, b) -> merge(do_stmt a, do_stmt b)
       | T.CJUMP(c, e1, e2, t, f) -> let f(l)=(match l with [a;b]->T.CJUMP(c, a, b, t, f)) in
                                   reorder_stmt([e1;e2], f)
       | T.MOVE(T.TEMP t,b) -> let f(l)=(match l with [b]->T.MOVE(T.TEMP t, b)) in
                               reorder_stmt([b], f)
       | T.MOVE(T.ESEQ(s, e, w), b) -> do_stmt(T.SEQ(s, T.MOVE(e, b)))
       | T.EXP e -> let f(l)=(match l with [e]->T.EXP e) in
                    reorder_stmt([e], f)
       | T.WRITEINT(e) -> let f(l)=(match l with [e]->T.WRITEINT(e)) in
                          reorder_stmt([e], f)
       | _ as s ->  s)

  and do_exp(p) =
      (match p with
       | T.BINOP(op, e1, e2) -> let f(l)=(match l with [a;b]->T.BINOP(op, a, b)) in
                                reorder_exp([e1;e2], f)
       | T.ESEQ(s, e, T.PRE) -> let a=do_stmt s in
                                let (ante_e1, e1, post_e1)=do_exp e in
                                (merge(ante_e1, a), e1, post_e1)
       | T.ESEQ(s, e, T.POST) -> let a=do_stmt s in
                                let (ante_e1, e1, post_e1)=do_exp e in
                                (ante_e1, e1, merge(post_e1, a))
      | _ as e -> (T.NIL, e, T.NIL))

  in
 
  (* linear gets rid of the top-level SEQ's, producing a list *)
  let rec linear (s, l) =
     (match s with
        T.SEQ(a, b) -> linear(a, linear(b, l))
      | _ -> s::l) 
  in (* body of linearize *)
    linear(do_stmt stmt0, [])
;;

let basicBlocks =
()
;;

let traceSchedule =
()
;;
