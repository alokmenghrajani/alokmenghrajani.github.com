(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: every time we encounter an ID string in the lexer, we make a      *)
(*              a Symbol.symbol of it and store that as its identification. A     *)
(*              symbol consists of a string and a hash value, these values will   *)
(*              be used in later projects to efficiently match variables to types *)
(*                                                                                *)
(*              Note: I'm using an imperative table instead of a functional table *)
(*                                                                                *)
(* X-reference: lexel.mll, grammar.mly, translate.ml                              *)


module S =
  struct
    type t = string * int
    let compare (s1, i1) (s2, i2) =
      if (i1 < i2) then
	-1
      else if (i1 = i2) then
	0
      else
	1
  end

module H = Hashtbl

type symbol = S.t

let nextsym = ref 0
let hashtable:(string, int) H.t = H.create 109

let symbol name =
  if (H.mem hashtable name) then
    let i = H.find hashtable name in
    (name, i)
  else
    let i = !nextsym in
    nextsym := i+1;
    H.add hashtable name i;
    (name, i)

let isymbol () =
  let i = !nextsym in
  let _ = nextsym := i+1 in
  let name = "SIML"^(string_of_int !nextsym) in
  H.add hashtable name i;
  (name, i)

let name (s, i) = s

let print_symbol_table t=
   let p(k, v) =
     let f(a) = () in
     print_string "KEY: "; print_string k; print_string " VALUE: "; print_int v; print_string "\n"; f
   in
   print_string "\nSYMBOL TABLE:\n";
   print_string "----------------\n";
   H.iter p t;
   print_string "----------------\n";
;;

(************************)
(*  imperative version  *)
type 'a table = (S.t, 'a) H.t
let empty () = H.create 109
let enter t s a = H.add t s a (* bind s to a in t *)
let look t s =
  try
    Some(H.find t s)
  with Not_found ->
    None
(************************)


(************************)
(*  functional version  *)
(* module SymbolMap = Map.Make(S)
   type 'a table = 'a SymbolMap.t
   let empty = SymbolMap.empty
   let enter t s a = SymbolMap.add s a t 
   let look t s =
   try
   Some(SymbolMap.find s t)
   with Not_found ->
   None *)
(************************)
