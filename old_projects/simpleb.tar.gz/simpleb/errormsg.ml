(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file contains functions that maintain a context in which     *)
(*              errors are processed. The context maintains the number of lines   *)
(*              in the file, and the character positions at which those lines     *)
(*              begin. The function call "error (startpos, endpos) msg" takes the *)
(*              starting and ending positions of the error (in number of          *)
(*              characters from the beginning of the file) and a message          *)
(*              describing the error. It then prints out the line and message.    *)
(*              In order to maintain the error contaxt, the lexer must call       *)
(*              startNewline every time it encounters the end of a line.          *)
(*                                                                                *)
(*              Note: I found it difficult to implement proper and intelligent    *)
(*                    error messages...                                           *)
(*                                                                                *)
(* X-reference: lexer.mll, grammar.mly, translate.ml                              *)


module P = Printf

let lineNum = ref 1
let linePos = ref [1]

let debugFlag  = ref false
let fullDebug  = ref false

type info =
    { mutable  linenum: int      ;
      mutable  linepos: int list ;
      mutable  fileName: string  ;
      mutable  errors: bool      ; }

let current : info = 
    { linenum  = 1   ;
      linepos  = [1] ;
      fileName = ""  ;
      errors = false ; }
    
let startFile fname =
  begin
    current.linenum  <- 1     ;
    current.linepos  <- [0]   ;
    current.fileName <- fname ;
    current.errors   <- false
  end

let startNewline n =
  begin
    current.linenum <- current.linenum + 1;
    current.linepos <- n :: current.linepos;
  end

let getCurrentPos () =
(*  List.nth (current.linepos) (List.length(current.linepos) - 1) *)
  List.hd (current.linepos)


let getLocation (i : info) pos pos2 = 
  let rec look n = function
      a::_ when (a<=pos) -> (n, pos -a -1, pos2 -a -1)
    | _::rest -> look (n - 1) rest
    | _ -> (0, 0, 0)
  in
  let (lin,col,col2) = look i.linenum i.linepos in
    let loc =
      if col=col2 then P.sprintf "%d.%d" lin (col)
      else P.sprintf "%d.%d-%d.%d" lin (col) lin (col2)
    in
      P.sprintf "%s:%s" i.fileName loc

let currentContext () = current

let setContext ec =
  begin
    current.linenum <- ec.linenum;
    current.linepos <- ec.linepos;
    current.fileName <- ec.fileName;
    current.errors <- ec.errors
  end

let error (startpos, endpos) msg =
  if (!fullDebug) then
    Printf.printf "start %d, end %d\n" startpos endpos;
  current.errors <- true;
  Printf.eprintf "%s:error: %s near this location\n" (getLocation current startpos endpos) msg

let errors() = current.errors
