(* This program is free software; you can redistribute it and/or modify it under  *)
(* the terms of the GNU General Public License as published by the Free Software  *)
(* Foundation; either version 2 of the License, or (at your option) any later     *)
(* version.                                                                       *)
(*                                                                                *)  
(* This program is distributed in the hope that it will be useful, but WITHOUT    *)
(* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS  *)
(* FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. *)
(*                                                                                *)
(* Programmed by Alok Menghrajani.                                                *)
(* http://www.alokonline.com/projets/compiler/simpleb.html                        *)
(*                                                                                *)
(* Description: this file defines the abstract syntax tree for the language.      *)
(*              unlike in Appel, our absyn.ml has a program type that holds the   *)
(*              abstract syntax tree (of type exp) of our program and the context *)
(*              for our error messages (errormsg.info)                            *)
(*                                                                                *)
(* Dependency:  grammar.mly, errormsg.ml, simpleb.ml (the main program)           *)


type pos = (int * int)
type symbol = Symbol.symbol

type program = Program of dec * stmt * Errormsg.info

and var = SimpleVar of symbol * pos

and exp = 
    VarExp of var
 |  IntExp of int32
 |  OpExp of (exp * oper * exp * pos)
 |  PreIncExp of (var * pos)
 |  PreDecExp of (var * pos)
 |  PostIncExp of (var * pos)
 |  PostDecExp of (var * pos)

and stmt =
     SeqStmt of (stmt * pos) list
   | AssignStmt of (var * exp * pos)
   | IfStmt of (boolexp * stmt * stmt * pos)
   | WhileStmt of (boolexp * stmt * pos)
   | ForStmt of (var * exp * boolexp * stmt * stmt * pos)
   | BreakStmt of (pos)
   | ContinueStmt of (pos)
   | WriteintStmt of (exp * pos)

and boolexp =
     True of pos
   | False of pos
   | Unopb of (boolexp * unoperb * pos)
   | Binopb of (boolexp * binoperb * boolexp * pos)
   | Cmpop of (exp * cmpoper * exp * pos)

and binoperb = AndOp | OrOp | XorOp

and cmpoper =  EqOp | NeOp | LtOp | LeOp | GtOp | GeOp

and unoperb = NotOp

and oper = PlusOp | MinusOp | TimesOp | DivideOp | ModOp

and dec = VarDecSeq of (symbol * exp * pos) list


let rec print_exp (e) =
   let print_op op = 
     match op with
       PlusOp -> print_string " + "
     | MinusOp -> print_string " - "
     | TimesOp -> print_string " * "
     | DivideOp -> print_string " / "
     | ModOp -> print_string " % " in
   match e with
     IntExp c -> print_string (Int32.to_string c)
   | VarExp (SimpleVar(v, _)) -> print_string (Symbol.name v)
   | OpExp(left, op, right, _) ->  print_string "("; print_exp left; print_op op; print_exp right; print_string ")";
   | PreIncExp (SimpleVar(v, _), _) -> print_string ("++" ^ (Symbol.name v))
   | PostIncExp (SimpleVar(v, _), _) -> print_string ((Symbol.name v) ^ "++")
   | PreDecExp (SimpleVar(v, _), _) -> print_string ("--" ^ (Symbol.name v))  
   | PostDecExp (SimpleVar(v, _), _) -> print_string ((Symbol.name v) ^ "--")
;;

let rec print_boolexp (b) =
     let print_bop op =
       match op with
         AndOp -> print_string " && "
       | OrOp -> print_string " || "
       | XorOp -> print_string " ^ " in
     let print_uop op =
       match op with
         NotOp -> print_string " ! " in
     let print_cop op =
       match op with
         EqOp -> print_string " == "
       | NeOp -> print_string " != "
       | LtOp -> print_string " < "
       | LeOp -> print_string " <= "
       | GtOp -> print_string " > "
       | GeOp -> print_string " >= " in
     match b with
       True _ -> print_string "True "
     | False _ -> print_string "False "
     | Binopb (left, op, right, _) -> print_boolexp left; print_bop op; print_boolexp right
     | Unopb (left, op, _) -> print_uop op; print_boolexp left
     | Cmpop (left, op, right, _) -> print_exp left; print_cop op; print_exp right 
;;

let rec print_stmt (s) =
   let rec print_seq l =
     match l with
       (first, _)::rest -> print_stmt first; print_newline(); print_seq rest
     | [] -> () in
   match s with
     SeqStmt s -> print_string "{"; print_seq s; print_string "}"
   | AssignStmt (SimpleVar(v, _), right, _) -> print_string ((Symbol.name v) ^ " = "); print_exp right 
   | IfStmt (cond, t, f, _) -> print_string "If "; print_boolexp  cond; print_string "then "; print_stmt t;
                               print_string " else "; print_stmt f
   | WhileStmt (cond, b, _) -> print_string "While ("; print_boolexp cond; print_string ") "; print_stmt b
   | ForStmt (SimpleVar(v, _), e, cond, inc, b, _) -> print_string ("For( " ^ (Symbol.name v) ^ " = ");
                                                      print_exp e; print_string "; "; print_boolexp cond;
                                                      print_string "; "; print_stmt inc;
                                                      print_string ") "; print_stmt b  
   | BreakStmt (_) -> print_string "Break "
   | ContinueStmt (_) -> print_string "Continue "
   | WriteintStmt (e, _) -> print_string "Writeint( "; print_exp e; print_string ") "   
;;

let rec print_decl d =
   match d with
     (s, e, _)::list -> print_string "Symbol: "; print_string (Symbol.name s); print_string " <- "; print_exp e;
                        print_string "\n"; print_decl list
   | [] -> ()
;;

let print_program (Program (VarDecSeq d, s, i)) =
     print_string "\nABSYN TREE:\n";
     print_string "----------------------\n";
     print_decl (d);
     print_string "----------------------\n";
     print_stmt (s);
     print_string "----------------------\n";;




