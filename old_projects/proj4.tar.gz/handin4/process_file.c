#include "kernel.h"
#include "process_file.h"
#include "inc/x86_regs.h"
#include "inc/interrupts.h"

void set_process_current_inode(int t) {
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb -> cur_inode = t; 
}
int get_process_current_inode() {
  pcb_struct *pcb = GET_PCB(get_esp());
  return pcb -> cur_inode; 
}

int get_process_fds(){
  pcb_struct *pcb = GET_PCB(get_esp());
  return pcb -> fds;
}

void set_process_fds(int t){
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb -> fds = t;
}


void reset_currents(){
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb_struct * temp = pcb;
  disable_interrupts();
  do{
    temp -> cur_inode = 0;
    temp = temp -> next;
  }while (temp != pcb);
  enable_interrupts();
}
