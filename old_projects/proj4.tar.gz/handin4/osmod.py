# 15-412 Simics mods v0.4
# Yuen-Lin Tan (tyl@cmu.edu)

from random import Random
from time import time

logFile = "kernel.log"
om_rand = Random()

print "15-412mods v0.4 initialized."

# Utility functions
eval_sym = SIM_get_class_interface("symtable", "symtable").eval_sym
def eval_expr(cpu, expr):
    return eval_sym(cpu, expr, [], '')

def readString(mem_addr):
    ret = ""
    for i in range(256):
        phy_addr = SIM_logical_to_physical(conf.cpu0, Sim_DI_Data, mem_addr+i)
        char = SIM_read_byte(conf.phys_mem0, phy_addr)
        ret = ret + ('%c' % char)
        if (char == 0):
            break
    return ret

def getRandom():
    return om_rand.randint(0, 2147483646)

# Writes random int returned by getRandom() to %eax
def random_handler():
    cpu = conf.cpu0
    cpu.eax = getRandom()

# Writes system time in seconds to %eax
def time_handler():
    cpu = conf.cpu0
    cpu.eax = int(time())

# print_log_handler()
# Prints user-supplied string to Simics console and file.
def print_log_handler():
    cpu = conf.cpu0
    outFile = file(os.environ["OS_PROJ_PATH"] + "/" + logFile, "a")
    
    str_addr = SIM_read_register(cpu, SIM_get_register_number("eax"))
    str = readString(str_addr)
    #str = str.replace("\\n", '\n')
    #str = str.replace('\n', '')
    #print str
    sys.stdout.write(str)
    outFile.write(str)
    outFile.close()

def magic_inst_dispatcher(dummy, cpu, param):
    str_flag = SIM_read_register(cpu, SIM_get_register_number("ebx"))
    cmdType = "%x" % str_flag

    if cmdType == "9badd00d":
        random_handler()
        return
    elif cmdType == "8badd00d":
        time_handler()
        return
    elif cmdType == "2badd00d":
        print "User-defined magic breakpoint reached."
        SIM_processor_break(cpu, 2)
        return
    elif cmdType == "1badd00d":
        print_log_handler()
        return
    else:
        return
    
SIM_hap_register_callback("Core_Magic_Instruction", magic_inst_dispatcher, 0)
