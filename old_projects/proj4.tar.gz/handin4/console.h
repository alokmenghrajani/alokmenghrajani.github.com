#ifndef CONSOLE_H
#define CONSOLE_H

#include "inc/video_defines.h"
#include "util.h"


/* Console Device Driver API */
void console_test();
void putbytes(const char* s, int len);
void set_term_color(int color);
void get_term_color(int* color);
void set_cursor(int row, int col);
void get_cursor(int* row, int* col);
void hide_cursor();
void show_cursor();
void clear_console();
int  cursor_isHidden();
char* console_get_line();

#endif /* CONSOLE_H */
