/*
  Name: x86_regs.h
  Date: February 25th, 2003
  Author: Steve Muckle

  Assembly macros to easily manipulate important registers from C.

*/

#define get_esp() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%esp, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_esp(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%esp" : : "r" (_temp__)); \
     })

#define get_ebp() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%ebp, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_ebp(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%ebp" : : "r" (_temp__)); \
     })

#define get_cr0() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%cr0, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_cr0(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%cr0" : : "r" (_temp__)); \
     })


#define get_cr2() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%cr2, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_cr2(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%cr2" : : "r" (_temp__)); \
     })


#define get_cr3() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%cr3, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_cr3(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%cr3" : : "r" (_temp__)); \
     })


#define get_cr4() \
    ({ \
        register unsigned int _temp__; \
        asm("movl %%cr4, %0" : "=r" (_temp__)); \
        _temp__; \
    })

#define set_cr4(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%cr4" : : "r" (_temp__)); \
     })


#define set_ds(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%ds" : : "r" (_temp__)); \
     })

#define set_es(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%es" : : "r" (_temp__)); \
     })

#define set_fs(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%fs" : : "r" (_temp__)); \
     })

#define set_gs(value) \
    ({ \
        register unsigned int _temp__ = (value); \
        asm volatile("movl %0, %%gs" : : "r" (_temp__)); \
     })
