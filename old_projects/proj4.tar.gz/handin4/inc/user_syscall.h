// USED FOR LINKING USER CODE ONLY

/*
  15-412 Project Two Kernel System Calls

  If a system call takes nothing, then you can pass it
  anything as a handle. Syscalls that take integers (rather
  than pointers) are just passed the integer, not a pointer
  to the integer.

  All syscalls return 0 normally, -1 for an error, unless
  otherwise noted.

*/

/* Takes an integer, followed by a pointer to a string which may
   be no longer than 256 bytes. */

#define SYSCALL_PRINT 3
typedef struct hippo_string_t_ {
  int len;
  char* st;
} pstring_t;

/* Takes the return value of the process. */
#define SYSCALL_EXIT 5

/* Takes the name of the executable. This name must be less than
   20 characters. Returns the new pid, or -1 if there was an error. */
#define SYSCALL_TASK_START 7

/* Takes a pointer to a buffer which must contain at least
   80 characters. SYSCALL_READLINE will insert characters until it
   encounters a newline or fills the buffer. */
#define SYSCALL_READLINE 8

/* Takes the new console color, an int. */
#define SYSCALL_SET_TERM_COLOR 10
/* Cursor color values. */
#define FGND_BLACK 0x0
#define FGND_BLUE  0x1
#define FGND_GREEN 0x2
#define FGND_CYAN  0x3
#define FGND_RED   0x4
#define FGND_MAG   0x5
#define FGND_BRWN  0x6
#define FGND_LGRAY 0x7 /* Light gray. */
#define FGND_DGRAY 0x8 /* Dark gray. */
#define FGND_BBLUE 0x9 /* Bright blue. */
#define FGND_BGRN  0xA /* Bright green. */
#define FGND_BCYAN 0xB /* Bright cyan. */
#define FGND_PINK  0xC
#define FGND_BMAG  0xD /* Bright magenta. */
#define FGND_YLLW  0xE
#define FGND_WHITE 0xF

#define BGND_BLACK 0x00
#define BGND_BLUE  0x10
#define BGND_GREEN 0x20
#define BGND_CYAN  0x30
#define BGND_RED   0x40
#define BGND_MAG   0x50
#define BGND_BRWN  0x60
#define BGND_LGRAY 0x70 /* Light gray. */

/* Takes a pointer to a cpos struct. */
#define SYSCALL_SET_CURSOR_POS 11
typedef struct _cursor_pos {
  int row;
  int col;
} cpos;

/* Takes either zero (then returns the current sbrk), or the new
   desired sbrk address (returns -1 or the new heap value). */
#define SYSCALL_SBRK 12

/* Doesn't take anything, returns 0 to the child, the new PID to
   the parent. */
#define SYSCALL_MINCLONE 13

/* Doesn't take anything, returns a random number between
   0 and 2^32-1. */
#define SYSCALL_RAND 20

/* Takes the number of milliseconds to sleep. Deschedules
   the calling process for that amount of time. */
#define SYSCALL_SLEEP 19

/* Yield takes the pid to yield to, or -1 for anything. */
#define SYSCALL_YIELD 14

/* Takes nothing, returns the PID of the calling process. */
#define SYSCALL_GETPID 22

/* Takes an int*. If the int* points to a nonzero value SYSCALL_DESCHEDULE
   returns immediately, otherwise the calling process is descheduled until
   it is made runnable by SYSCALL_MAKE_RUNNABLE. */
#define SYSCALL_DESCHEDULE 18

/* Takes a pointer to a sprite struct in user space, paints that
   sprite on the screen. Hides the cursor automatically (the cursor
   is unhidden on a subsequent call to SYSCALL_PRINT). */
#define SYSCALL_PAINT_SPRITE 15
typedef struct _sprite {
  /* Console color of sprite. */
  int color;
  /* Width and height of the sprite in chars. */
  int width;
  int height;
  /* Sprite data stored in row major order. */
  char data[64];
} sprite;

/* Struct for exec goodness. */
typedef struct _hippo_execs{
  char* execname;
  char** argvec;
} exec_t;

/* Exec's interrupt number. */
#define SYSCALL_EXEC 2


/* Takes nothing, returns a single keypress. Note that this is
   a blocking call. */
#define SYSCALL_GET_SINGLE_CHAR 16

/* Takes the PID of a process to be made runnable. This process is
   then eligible to be scheduled (reschedules processes descheduled
   by SYSCALL_DESCHEDULE). */
#define SYSCALL_MAKE_RUNNABLE 17

#define SYSCALL_FORK 1

#define SYSCALL_WAIT 23


/* filesystem */


typedef struct io___struct{
  int fd;
  void* buf;
  int size;
} io_t;


typedef struct seek_shit{
  int fd;
  int offset;
} seeker_t;


typedef struct name_crap{
  char* old;
  char* new;
} filename_t;

typedef struct direntry_crap{
  char* pathname;
  int entrypos;
  char* entryname;
} direntry_t;
