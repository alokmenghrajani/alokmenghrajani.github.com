///////////////////////////////////////////////////////////////////////////
//
// Name: seg.h
// Date: February 21st 2003
// Author: Steve Muckle <smuckle@andrew.cmu.edu>
//
// Description:
// 
// Interface to x86 segment manipulation functions.
//
///////////////////////////////////////////////////////////////////////////
#ifndef SEG_H
#define SEG_H

#define KERNEL_CS       0x10    /* Kernel's PL0 code segment */
#define KERNEL_DS       0x18    /* Kernel's PL0 data segment */

#define USER_CS 0x40 /* User's PL3 code segment */
#define USER_DS 0x48 /* Kernel's PL3 code segment */

#define USER_MEM_START 0x1000000
#define USER_MEM_SIZE 0xf000000

/* Sets the stack pointer to be used when an exception or interrupt
   occurs. */
void set_esp0(void* new_esp0);

/* Installs user segments that take the whole address space. */
void install_user_segs(int usercs, int userds);

#endif
