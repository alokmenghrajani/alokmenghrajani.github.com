#ifndef COMMON_H
#define COMMON_H

#define ERROR -1
#define SUCCESS 0

#ifndef NULL
#define NULL 0
#endif


#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define ROUND(a,b) (((a) + (b) - ((a)%(b)))/(b))

#ifndef DEBUG
#define DEBUG
#endif 

#ifdef DEBUG
#define ASSERT(ex) {\
if (!(ex)) {{\
printf("Assert failed %s, %d !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", __FILE__, __LINE__); \
for(;;); \
}}}
#else
#define ASSERT(ex) {(ex) ? 1 : 0;}
#endif /* DEBUG */


#endif
