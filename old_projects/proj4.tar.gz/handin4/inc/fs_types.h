/*
  File system types for 15-412 project set.
*/

#ifndef FS_TYPES_H
#define FS_TYPES_H

/* File system argument structure definitions. */

typedef struct {
  int fd;
  int size;
  char *buf;
} fs_io_t;

typedef struct {
  int fd;
  int pos;
} fs_seek_t;

typedef struct {
  char *oldname;
  char *newname;
} fs_link_t;

typedef struct {
  char *name;
  int entrypos;
  char *entryname;
} fs_dirent_t;

#endif
