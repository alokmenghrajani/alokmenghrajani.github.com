///////////////////////////////////////////////////////////////////////////
//
// Name: interrupts.h
// Date: January 15th 2003
// Author: Steve Muckle <smuckle@andrew.cmu.edu>
//
// Description:
// 
// Some handy functions for managing interrupts.
//
///////////////////////////////////////////////////////////////////////////
#ifndef INTR_MANAGE_H
#define INTR_MANAGE_H

#define INT_CTL_REG 0x20
#define INT_CTL_DONE 0x20

///////////////////////////////////////////////////////////////////////////
//
// sidt()
// 
// Parameters:
// None
//
// Return Value:
// void*: A pointer to the beginning of the installed IDT.
//
// Description:
// Returns a pointer to the beginning of the installed IDT. Obtains this
// information via an embedded assembly instruction.
//
///////////////////////////////////////////////////////////////////////////
void *sidt(void);

void disable_interrupts();
void enable_interrupts();


///////////////////////////////////////////////////////////////////////////
//
// remap_intr()
//
// Parameters: 
// None
//
// Return Value:
// Void
//
// Description:
// Remaps the hardware interrupts to use IDT entries 0x20->0x2F. Initially
// the hardware interrupts are assigned to conflicting entries in the IDT.
//
///////////////////////////////////////////////////////////////////////////
void remap_intr();

#endif
