///////////////////////////////////////////////////////////////////////////
//
// Name: io_map.h
// Date: January 15th 2003
// Author: Steve Muckle <smuckle@andrew.cmu.edu>
//
// Description:
//
// Functions to access memory-mapped io space through the use of assembly
// instructions.
//
///////////////////////////////////////////////////////////////////////////
#ifndef IO_MAP_H
#define IO_MAP_H

///////////////////////////////////////////////////////////////////////////
//
// inb()
//
// Parameters:
// unsigned short int port: The io port to read.
//
// Return Value:
// unsigned char: The value of the port.
//
// Description: Reads the specified port and returns its value.
//
///////////////////////////////////////////////////////////////////////////
__inline unsigned char
inb (unsigned short int port);

///////////////////////////////////////////////////////////////////////////
//
// inw()
//
// Parameters:
// unsigned short int port: The io port to read.
//
// Return Value:
// unsigned short int: The value of the port.
//
// Description: Reads the specified port and returns its value.
//
///////////////////////////////////////////////////////////////////////////
__inline unsigned short int
inw (unsigned short int port);

///////////////////////////////////////////////////////////////////////////
//
// inl()
//
// Parameters:
// unsigned short int port: The io port to read.
//
// Return Value:
// unsigned int: The value of the port.
//
// Description: Reads the specified port and returns its value.
//
///////////////////////////////////////////////////////////////////////////
__inline unsigned int
inl (unsigned short int port);

///////////////////////////////////////////////////////////////////////////
//
// outb()
//
// Parameters:
// unsigned char value: The value to write to the port.
// unsigned short int port: The io port to write.
//
// Return Value:
// Void
//
// Description: Write the value to the specified port.
//
///////////////////////////////////////////////////////////////////////////
__inline void
outb (unsigned char value, unsigned short int port);

///////////////////////////////////////////////////////////////////////////
//
// outw()
//
// Parameters:
// unsigned short int value: The value to write to the port.
// unsigned short int port: The io port to write.
//
// Return Value:
// Void
//
// Description: Write the value to the specified port.
//
///////////////////////////////////////////////////////////////////////////
__inline void
outw (unsigned short int value, unsigned short int port);

///////////////////////////////////////////////////////////////////////////
//
// outl()
//
// Parameters:
// unsigned int value: The value to write to the port.
// unsigned short int port: The io port to write.
//
// Return Value:
// Void
//
// Description: Write the value to the specified port.
//
///////////////////////////////////////////////////////////////////////////
__inline void
outl (unsigned int value, unsigned short int port);

#endif
