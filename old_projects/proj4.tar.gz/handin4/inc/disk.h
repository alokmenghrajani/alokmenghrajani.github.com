/*
 * disk.h
 * Steve Muckle
 * 15-412 Project Set
 */

#define SECTOR_SIZE 512

/*
 * int disk_init()
 * Installs the disk interrupt handler via disk_install(),
 * waits until the disks are ready, and finds out how big
 * they are (filling in the ide0 and ide1 data structures).
 * Returns SUCCESS if the disks were initialized, and ERROR
 * otherwise.
 */
int disk_init(void);

/*
 * void ide_write_sector(int lba_addr, char* source, int num)
 * Initiates an IDE operation to write the specified sectors
 * to the disk. The sectors will be taken sequentially from the
 * address source.
 */
void ide_write_sector(int lba_addr, char* source, int num);

/*
 * void ide_read_sector(int lba_addr, char* source, int num)
 * Initiates an IDE operation to read the specified sectors
 * from the disk. The sectors will be stored sequentially starting
 * at the address source.
 */
void ide_read_sector(int lba_addr, char* dest, int num);

/*
 * int get_num_sectors()
 * Returns the number of sectors on the drive.
 * You must call disk_init(), and have it return SUCCESS, before
 * this function will function properly.
 */
int get_num_sectors(void);
