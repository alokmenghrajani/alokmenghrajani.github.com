///////////////////////////////////////////////////////////////////////////
//
// Name: keyhelp.h
// Date: January 15th 2003
// Author: Steve Muckle <smuckle@andrew.cmu.edu>
//
// Description:
// 
// Scancode processing for the keyboard.
//
///////////////////////////////////////////////////////////////////////////
#ifndef KEYHELP_H
#define KEYHELP_H

#define KEY_IDT_ENTRY 0x21
#define KEYBOARD_PORT 0x60

///////////////////////////////////////////////////////////////////////////
//
// caps_lock()
// 
// Parameters:
// None
// 
// Return Value:
// int: 1 if caps lock is on, 0 otherwise.
//
// Description: 
// Returns 1 if caps lock is on, 0 otherwise.
//
///////////////////////////////////////////////////////////////////////////
__inline int caps_lock();

///////////////////////////////////////////////////////////////////////////
//
// shift()
// 
// Parameters:
// None
// 
// Return Value:
// int: 1 if the shift key is currently depressed, 0 otherwise.
//
// Description: 
// Returns 1 if the shift key is currently depressed, 0 otherwise.
//
///////////////////////////////////////////////////////////////////////////
__inline int shift();

///////////////////////////////////////////////////////////////////////////
//
// process_scancode()
//
// Parameters:
// int keypress: The raw keyboard scan code.
// 
// Return Value:
// int: The ascii value of the scan code, or -1 if the code was a modifier
//      key or was not understood.
//
// Description: 
// Converts keyboard scan codes into ascii character values. Keeps track
// of modifier key state as well as the extended scan code (0xE0).
//
///////////////////////////////////////////////////////////////////////////
int process_scancode(int keypress);

#endif
