
/*

  console.c: the C code for the console driver for our 
  extra special operating system that beats Windows (tm) any day!

  Authors: Alok Menghrajani & Vikram Manjunath

 */
#include "console.h"
#include "util.h"
#include <oskit/c/stdio.h>
#include "inc/video_defines.h"
#include "inc/io_map.h"

/* The console has two cursors: the physical and the logical.
   The reason for which I have two, is that the physical must be moved outside the screen area to be hidden, while
   the logical must remain at the same position (since characters can be printed without the cursor visible).
*/

static int console_color;

// Logical cursor
static int cursor_x;
static int cursor_y;
static int cursor_hidden;


void console_test() {
  /* Simple test method, writes a M on the 3rd character of the 2nd line. */
  *((char*)(CONSOLE_MEM_BASE + 2*(CONSOLE_WIDTH + 2))) = 'M';
  // Set the color, somehow blink doesn't work.
  *((char*)(CONSOLE_MEM_BASE + 2*(CONSOLE_WIDTH + 2)+1)) = FGND_BLUE | BGND_RED | BLINK;   
  return;
}

void scroll() {
  /* Scroll the console one line up, leaving the first line as is (that's were the clock is displayed)
     The logical / physical cursors are untouched.
   */

  char* pos = (char*)(CONSOLE_MEM_BASE);
  char* dest = (char*)(CONSOLE_MEM_BASE + 2*CONSOLE_WIDTH*(CONSOLE_HEIGHT-1));

  while (pos<dest) {
    *pos=*(pos+2*CONSOLE_WIDTH);
    pos++;
  }
  // Clear the last line with current console color
  dest = dest + 2*CONSOLE_WIDTH;
  while (pos<dest) {
    *(pos++)=0x00;
    *(pos++)=console_color;
  }
  return;
}

void update_physical_cursor() {
  /* Update the physical cursor by placing it where the logical one is */
  if (!cursor_hidden) {
    unsigned short int pos = cursor_x + cursor_y * CONSOLE_WIDTH;
    outb(CRTC_CURSOR_LSB_IDX, CRTC_IDX_REG);
    outb((unsigned char) pos, CRTC_DATA_REG);
    outb(CRTC_CURSOR_MSB_IDX, CRTC_IDX_REG);
    outb((unsigned char) (pos>>8), CRTC_DATA_REG);
  }
}

void cursor_move_left() {
  /* Used for backspace 
     If the cursor reaches the begining of the line, then nothing happens.
     (At first I had implemented it in such a way that it went up to the previous line)
   */
  
  cursor_x--;
  if (cursor_x<0) {
    cursor_x=0;

    // Begining of line case
    // cursor_x=CONSOLE_WIDTH-1;
    // cursor_y--;
    //if (cursor_y<0) {
      // Home case
      //cursor_x=0;
      //cursor_y=0;
    //}
  }
  update_physical_cursor();
  return;
}

void cursor_move_right() {
  /* Moves the cursor one character to the right. If it reaches the end of line,
     then it goes to the next line. It will also call scroll() if need be.
  */
  cursor_x++;
  if (cursor_x>=CONSOLE_WIDTH) {
    cursor_x=0;
    cursor_y++;
    if (cursor_y>=CONSOLE_HEIGHT) {
      cursor_y--;
      scroll();
    }
  }
  // Update physical cursor
  update_physical_cursor();
  return;
}

void putbytes(const char* s, int len) {
  /* Prints a string s. If the string is longer than the current line it will wrap
     to the next line.
     When the console reaches the bottom, it scrolls one line up.
     The \n character causes the cursor to go one line down.
     The \r character causes the cursor to go to the beginning of the current line.
     The backspace character deletes the previous character (handling special cases like
       @home, or @beg_of_line) -> changed to only delete until first character of line !!! */
  int i;
  char* pos;
  if (s!=NULL)
    for (i=0; i<len; i++) {
      char c = s[i];
      switch(c) {
      case '\n':
	// Newline
	cursor_y++;
	if (cursor_y>=CONSOLE_HEIGHT) {
	  cursor_y--;
	  scroll();
	}
	// Update physical cursor
	update_physical_cursor();
	//break; FALL THROUGH
      case '\r':
	// Carrage return
	cursor_x=0;
	update_physical_cursor();
	break;
      case '\b':
	// Backspace
	cursor_move_left();
	pos = (char*) (CONSOLE_MEM_BASE + 2*cursor_y*CONSOLE_WIDTH + 2*cursor_x);
	*pos = 0x00;
	*(pos+1) = console_color;
	break;
      default:
	// Display the character
        pos = (char*) (CONSOLE_MEM_BASE + 2*cursor_y*CONSOLE_WIDTH + 2*cursor_x);
	*pos = c;
	*(pos+1) = console_color;
	cursor_move_right();
      }
    }
  return;
}

void set_term_color(int color) {
  /* Changes the foreground/background color of future characters.
     If the color code is invalid (valid range=[0..0xFF]) the function has no effect */
  if ((color>0) && (color<0xFF))
    console_color = color;
  return;
}

void get_term_color(int* color) {
  /* Writes the current foreground/background color into the argument.
     Doesn't do anything if color is NULL */
  if (color!=NULL)
    *color = console_color;
}

void set_cursor(int row, int col) {
  /* Sets the position of the cursor to the position(row, col).
     If the cursor is hidden, it will remain hidden.
     
     If row or col are invalid then nothing happens.
  */
  if ((col<0) || (col>=CONSOLE_WIDTH))
    return;
  if ((row<0) || (row>=CONSOLE_HEIGHT))
    return;
  
  // Set logical cursor
  cursor_x = col;
  cursor_y = row;

  // Set physical cursor if not hidden
  update_physical_cursor();
}

void get_cursor(int* row, int* col) {
  /* Writes the current position of the cursor into the arguments.
     Doesn't do anything if row or col are NULL */
  if ((row!=NULL) && (col!=NULL)) {
    *col = cursor_x;
    *row = cursor_y;
  }
}

void hide_cursor() {
  // Hide logical cursor
  cursor_hidden = TRUE;
  
  // Hide physical cursor
  outb(CRTC_CURSOR_LSB_IDX, CRTC_IDX_REG);
  outb(0xFF, CRTC_DATA_REG);
  outb(CRTC_CURSOR_MSB_IDX, CRTC_IDX_REG);
  outb(0xFF, CRTC_DATA_REG);
}

void show_cursor() {
  // Show logical cursor
  cursor_hidden = FALSE;

  // Show physical cursor
  update_physical_cursor();
}

void clear_console() {
  /* Clears the console setting the color to console_color */
  char* pos = (char*) CONSOLE_MEM_BASE;
  char* dest = pos + 2*CONSOLE_HEIGHT*CONSOLE_WIDTH;
  while (pos<dest) {
    *(pos++)=0x00;
    *(pos++)=console_color;
  }
}

int cursor_isHidden() {
  /* Returns the state of the cursor (hidden or showing) */
  return cursor_hidden;
}

char* console_get_line() {
  /* Return a pointer to the starting of the current line (where the cursor is) */
  return (char*) CONSOLE_MEM_BASE+(2*cursor_y*CONSOLE_WIDTH);
}
