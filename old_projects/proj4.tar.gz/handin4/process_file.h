#ifndef __PROCESS_FILE_H
#define __PROCESS_FILE_H


// TO BE MOVED INSIDE THE KERNEL:
void set_process_current_inode(int t);
int get_process_current_inode();
int get_process_fds();
void set_process_fds(int t);

void reset_currents();

#endif
