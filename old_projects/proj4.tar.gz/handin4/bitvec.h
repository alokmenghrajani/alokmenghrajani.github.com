typedef char* bitmap;
#define bitmap_new(x) \
({ \
 char* bm = malloc(((x)+ 8 - (x)%8)/8)\
int i;\
for(i=0;i<(x)/8 +1; i++)\
  bm[i] = 0;\
  bm;\
})

#define bitmap_set(arr,i,val) \
({ int char_num = (i)/8; \
int bit_num = (i) % 8;\
 ((char*)(arr))[char_num] |= (!!(val)) << bit_num;})


#define bitmap_test(arr,i)\
({  int char_num = (i)/8; \
int bit_num = (i) % 8;\
!!((((char*)(arr))[char_num]&(1<<bit_num));})

