#ifndef PROCESS__H
#define PROCESS__H

#include "kernel.h"
#include "page.h"



pcb_struct* process_create(ptd_struct* ptd, pid_t pid, char** argv); /* create a new process */
void process_launch(pcb_struct* pcb);
mem_t process_create_user_stack(ptd_struct* ptd, char** argv, mem_t exit_def);


#endif /* PROCESS__H */
