#ifndef SYSCALLS__H
#define SYSCALLS__H

#include "../kernel.h"

/* install the handler */
void syscalls_init();

/* the function number is in %edi, the argument value in %esi */
extern int syscalls_handler_wrapper();
void syscalls_handler(int function, int argument);
void kill_process(pcb_struct * pcb);

void our_exit(int);
int exec(char* execname, char** argvec);
// return 1 if tid is unique, 0 otherwise
int check_tid(pcb_struct *pcb);

#endif /* SYSCALLS__H */
