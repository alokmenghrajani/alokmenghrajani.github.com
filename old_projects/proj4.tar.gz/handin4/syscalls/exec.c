

/*
  
  exec.c: the C function that is executed when a software interrupt is 
  caused with the argument SYS_EXEC.
  Authors: Alok Menghrajani & Vikram Manjunath
  
*/

#include "syscalls.h"
#include "../kernel.h"
#include "../util.h"
#include <oskit/c/stdio.h>
#include "../context.h"
#include "../page.h"
#include "../process.h"
#include "../inc/seg.h"
#include "../inc/x86_regs.h"
#include "../loader.h"
#include "../inc/interrupts.h"
#include <oskit/c/malloc.h>

/*
  This kills off anyone sharing memory with the current process.
  Then it purges the virtual memory and replaces it with a new one.
  Finally, it loads the code and sets up a user stack in order to
  launch the program aksed for.
 */
int exec(char* execname, char** argvec) {
  pcb_struct * pcb = GET_PCB(get_esp()), * temp;
  ptd_struct * ptd, *oldptd;
  mem_t exit_default;
  mem_t ks, esp, us;
  mem_t code_start;



  /* a new ptd for the new virtual adress space */
  ptd = page_new_ptd();
  oldptd = pcb->ptd;
  pcb -> ptd = ptd;

  /* remember where the entry is for the code that you load */
  code_start = loader_loadcode(execname, ptd,&exit_default,0);

  /* Check if loading was successful */
  if (code_start == 0) {
    pcb->ptd = oldptd;
    sfree(ptd, PAGE_SIZE);
    SET_EAX(pcb, -1);
    return -1;
  }

  /* mark ourselves as stopped since we are now going to be in an inconsistent state */
  pcb->state = STOPPED; 

  /* the process should be stopped so that it doesn't get run. A context switch would
     mess things up since we are in an inconsistent state now. 
     We also reset all the values of the pcb.
  */
  pcb->flags = NORMAL;
  pcb->sleep_time = 0;
  pcb -> num_children = 0;   // you have no more reapable children
  pcb -> mem_limit = exit_default + SYS_EXIT_SIZE;
  // The caller of this function must set pcb->next and pcb->prev !
  // As well as the state

  ASSERT(argvec!=NULL);

  /* Set up the new user stack for the process */
  us = process_create_user_stack(ptd, argvec, exit_default);

  /* make sure that the set up was successful*/
  if(us == NULL){
    SET_EAX(pcb,-1);
    return -1;
  }    

  /* Kill all the processes that are sharing your memory.
     An exec after minclone is legal and will destroy the thread.
  */
  for(temp = pcb -> next; temp != pcb; temp = temp ->next){
    if(temp-> tid == pcb -> tid) {
      pcb_struct *p=find_pcb(temp->parent);
      if (p!=NULL)
	p->num_children--;
      kill_process(temp);
    }
  }

  /* set the kernel stack to the top */
  ks= (mem_t) pcb;

  /* clean up the original process's memory*/
  disable_interrupts();
  set_cr3((int) pcb->ptd);
  page_ptd_purge(oldptd);
  enable_interrupts();

  /* setup the "new" kernel stack */
  PUSH(ks, USER_DS | 3);
  PUSH(ks, us);
  PUSH(ks, 0x202);     /*XXXXXXX Alok, is this what we are using? */
  PUSH(ks, USER_CS | 3);
  PUSH(ks, code_start);

  PUSH(ks, 0); // No error code
  //Setting the stack to have the regs on it.
  esp = get_esp();
  set_esp(ks);
  asm("pusha");
  ks = get_esp();
  set_esp(esp);

  // pushing the data segment registers
  PUSH(ks, USER_DS | 3); // ds
  PUSH(ks, USER_DS | 3); //es
  PUSH(ks, USER_DS | 3);// fs
  PUSH(ks, USER_DS | 3);// gs
  pcb -> kesp = ks;

 
  pcb -> flags = NEWBORN;
  pcb -> state = RUNNABLE;

  process_launch(pcb);

  ASSERT(0);
  return 0;
}
