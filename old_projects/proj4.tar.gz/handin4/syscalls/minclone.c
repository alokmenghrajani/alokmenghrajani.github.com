
/*

  minclone.c: the C function that is executed when a software interrupt is 
  caused with the argument SYS_MINCLONE.
  Authors: Alok Menghrajani & Vikram Manjunath

 */

#include "../kernel.h"
#include "../inc/x86_regs.h"
#include <oskit/c/stdio.h>
#include <oskit/c/malloc.h>
#include "../process.h"
#include "syscalls.h"
#include "../inc/interrupts.h"
#include "../filesystem/filesystem.h"

/*

  our_exit is the exact funtion that is called in syscalls.c in the case
  of a SYS_MINCLONE.


  In this function, we make a new pcb and kernel stack. All other memory
  remains the same.
 */

void minclone() {
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb_struct *newpcb;
  int i;
  mem_t newks, ks;

  // We don't want the shell calling minclone...
  if (pcb->pid==0) {
    SET_EAX(pcb, -1);
    return;
  }
  /* find our kernel stack*/
  ks =(mem_t) pcb + sizeof(pcb_struct) - KERNEL_STACK_SIZE;
  /* allocate a new kernel stack/pcb for the new process*/
  newks =  (mem_t) smemalign(KERNEL_STACK_SIZE, KERNEL_STACK_SIZE);
  
  /* Make sure that the allocation was alright */
  if(newks == NULL){
    SET_EAX(pcb, -1); 
    return;
  }
    
  /* copy the kernel stack */
  for (i=0; i < KERNEL_STACK_SIZE ; i++){
    ((char *)newks)[i] = ((char*) ks)[i];
  }

  newpcb = GET_PCB(newks);
  /* set the new pid */
  newpcb -> pid = next_pid ++;

  /* set the return values of the parent and child */
  SET_EAX(newpcb, 0);
  SET_EAX(pcb, newpcb -> pid);
  

  /* set all the appropriate values in the child's pcb */
  newpcb -> flags = NEWBORN;
  newpcb -> state = STOPPED;
  newpcb-> num_children = 0; // no children as yet
  (pcb -> num_children)++; // parent has a new child
  newpcb->deadkids = NULL; // no dead kids
  newpcb -> sleep_time = 0; // not sleeping yet
  
  disable_interrupts();
  // Adding the new pcb to the list.
  newpcb -> next = pcb -> next;
  newpcb ->next-> prev =  newpcb;
  newpcb -> prev = pcb;
  pcb ->next = newpcb;
  enable_interrupts();


  /*  fild desc. */
  fd_update();

  newpcb->parent = pcb->pid; // mark the parent of the child
  newpcb -> flags = NEWBORN; // so taht it gets "launched"
  newpcb -> state = RUNNABLE; 
  pcb-> state = RUNNABLE;
  pcb -> flags = NORMAL;
  newpcb -> kesp = (int)newpcb -19; 
  return;

}
