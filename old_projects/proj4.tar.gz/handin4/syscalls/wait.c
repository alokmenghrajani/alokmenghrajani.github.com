
/*

  wiat.c: the C function that is executed when a software interrupt is 
  caused with the argument SYS_WAIT.
  Authors: Alok Menghrajani & Vikram Manjunath

 */

#include "../kernel.h"
#include "../util.h"
#include "../inc/interrupts.h"
#include "../inc/x86_regs.h"
#include <oskit/c/stdio.h>
#include <oskit/c/malloc.h>
#include "../process.h"
#include "syscalls.h"
#include "../context.h"

/* 
   This is the function that is called from syscalls_handler when the
   input is SYS_WAIT 
*/
void wait(int* status_ptr) {
  pcb_struct *dead, *pcb = GET_PCB(get_esp());
  char *freeks;

  if(pcb->num_children <= 0){  // you have no children
    SET_EAX(pcb, -1);          // set the parent's eax to -1
    context_switch(-1);        
  }
  else if(pcb->deadkids != NULL){ // your kids are already dead!
    dead = pcb->deadkids;

    pcb->deadkids = dead -> next;   // dequeue the dead child

    if (status_ptr!=NULL)
      *status_ptr = dead  -> exit_code; // set the exit code

    SET_EAX(pcb, dead->pid);           // set the eax of the parent to deadkid's pid

    freeks = ((char*)dead) + sizeof(pcb_struct) - KERNEL_STACK_SIZE;  // free the dead kid's pcb
    disable_interrupts();
    sfree(freeks, KERNEL_STACK_SIZE);                        

    enable_interrupts();

    (pcb-> num_children)--;
    context_switch(-1);
  }
  else{   // Your kids are not dead yet
    pcb -> state = STOPPED;            // stop yourself and wait for a child to die
    pcb -> flags = WAITING;
    pcb-> exit_code_ptr = status_ptr;
    context_switch(-1);
  }
}
