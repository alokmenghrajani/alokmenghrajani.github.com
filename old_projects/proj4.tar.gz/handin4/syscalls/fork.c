
/*

  fork.c: the C function that is executed when a software interrupt is 
  caused with the argument SYS_FORK.
  Authors: Alok Menghrajani & Vikram Manjunath

 */

#include "syscalls.h"
#include "../kernel.h"
#include "../inc/x86_regs.h"
#include <oskit/c/stdio.h>
#include "../context.h"
#include "../page.h"
#include <oskit/c/malloc.h>
#include "../process.h"
#include "../inc/seg.h"
#include "../inc/interrupts.h"
#include "../filesystem/filesystem.h"

/*

  our_exit is the exact funtion that is called in syscalls.c in the case
  of a SYS_FORK.


  In this function, we make a new pcb, kernel stack and user stack. 
  Everything is an identical copy to what the parent has. Except that 
  the pid and a few other essential things are different.

 */

void fork() {
  pcb_struct *pcb = GET_PCB(get_esp());
  ptd_struct *newptd, *ptd;
  pcb_struct *newpcb;
  int i,j,k;
  mem_t newks, ks;
  pt_struct *newpt;
    

  /* Check if I have shared memory */
  if (!check_tid(pcb)) {
    SET_EAX(pcb, -1);
    return;
  }

  /* find our kernel stack*/
  ks =(mem_t) pcb + sizeof(pcb_struct) - KERNEL_STACK_SIZE;

  disable_interrupts();
  /* allocate a new kernel stack/pcb for the new process that we are creating*/
  newks =  (mem_t) smemalign(KERNEL_STACK_SIZE, KERNEL_STACK_SIZE);

  enable_interrupts();

  /* Make sure that the allocation worked*/
  if(newks == NULL){
    SET_EAX(pcb, -1); 
    return;
  }
     


  for (i=0; i < KERNEL_STACK_SIZE; i++){
    // copy the pcb along with the kernel stack
    ((char *)newks)[i] = ((char*) ks)[i];
  }

  /* set all the values in the pcb appropriately */
  newpcb = GET_PCB(newks);
  disable_interrupts();
  newpcb -> pid = next_pid ++;
  enable_interrupts();
  newpcb -> tid = newpcb->pid;
  newpcb-> num_children = 0;
  newpcb->deadkids = NULL;
  newpcb -> sleep_time = 0;
//  newpcb -> exit_code_ptr = NULL;  //XXXXXXXX Don't we need this!?!?!?
  (pcb -> num_children)++;
  
  /* Set the return values for both the child and the parent */
  SET_EAX(newpcb, 0);
  SET_EAX(pcb, newpcb -> pid);
  
  newpcb -> flags = NEWBORN;
  newpcb -> state = STOPPED;

  // Adding the new pcb to the list.
  disable_interrupts();
  newpcb -> next = pcb -> next;
  newpcb ->next-> prev =  newpcb;
  newpcb -> prev = pcb;
  pcb ->next = newpcb;
  enable_interrupts();
  
  // Start copying the memory for the new process
  newptd = page_new_ptd();
  newpcb -> ptd = newptd;
  ptd = pcb -> ptd;
  // Disable paging: go to real mode
  CLEAR_PG;
  for(i = 4; i < PAGE_TABLE_SIZE; i++){
    if(ptd[i].p != 0){
      // get a new page table. copy the contents of that page table, recursively.
      for( j = 0; j < PAGE_TABLE_SIZE; j++){
	pt_struct* pt = (pt_struct*)(ptd[i].base <<12);
	if(pt[j].p != 0){
	  if(page_get_new(newptd, (mem_t) ((i << 22) + (j <<12)))== -1){
	    SET_EAX(pcb, -1); 
	    return;
	  }
	  
	  newpt = (pt_struct*)(newptd[i].base <<12);
	  for(k = 0; k < PAGE_SIZE; k ++){
	    ((char *) (newpt[j].base<<12))[k] = ((char *) (pt[j].base<<12))[k]; 
	  }
	  
	}
      }
    }
  }
  
  //reenable paging : back to virtual mode
  SET_PG;

  /* update the counter */
  fd_update();


  /* now that the new process is all set to go, we can get straight to the user process at pcb-19*/
  newpcb -> kesp = (int) newpcb - 19;

  /* everybody be runnable!*/

  newpcb->parent = pcb->pid;
  newpcb -> flags = NEWBORN;
  newpcb -> state = RUNNABLE;

  return;


}
