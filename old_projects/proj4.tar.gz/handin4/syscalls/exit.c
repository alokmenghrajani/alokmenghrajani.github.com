
/*

  exit.c: the C function that is executed when a software interrupt is 
  caused with the argument SYS_EXIT.
  Authors: Alok Menghrajani & Vikram Manjunath

 */

#include "../kernel.h"
#include "../inc/x86_regs.h"
#include <oskit/c/stdio.h>
#include <oskit/c/malloc.h>
#include "../process.h"
#include "syscalls.h"
#include "../context.h"
#include "../page.h"
#include "../util.h"
#include "../inc/seg.h"
#include "../inc/interrupts.h"
#include "../timer.h"


//proj 4
#include "../filesystem/filesystem.h"


int check_tid(pcb_struct* pcb);

/*

  our_exit is the exact funtion that is called in syscalls.c in the case
  of a SYS_EXIT. 
  In this function, the current process checks if its parent is alive,
  if so, if he/she is waiting on a child. 
  The appropriate action is taken in either case.

 */
void our_exit(int status) {
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb_struct *t, *parent, *deadkid;
  int flag;
  int parent_state;
    
  char *ks;
  char* z = 0;

      /* we don't want this process to be considered a running process any more since its 
	 pcb and kernel stack is now invalid. A context switch better not happen here.*/
  pcb->state = STOPPED;

  /* If the main thread exits, we respawn the shell*/
  if (pcb->pid == 0) {
    int t = exec("shell", &z);
    if (t==-1) {
      printf("NO MORE MEMORY LEFT TO LAUNCH A NEW SHELL :(");
      return;
    }
    return;
  }

  // close any file descriptors that we're the last ones to have
  close_fds();


  /* We don't want the parent to die or become waiting while we are exiting */
  disable_interrupts();
  parent = find_pcb(pcb ->parent);
  if (parent) {
    parent_state = parent->state;
    parent->state= STOPPED;
  }
  enable_interrupts();
  if(parent){ // Parent alive
    //set_cr3((int) parent->ptd);
    
   
    if(parent -> flags == WAITING){ // parent is waiting 
      disable_interrupts();
      /* now we are going to switch to the parent's virtual address space so that
	 we can set the value of the exit status.*/

      set_cr3((int) parent->ptd);
      /* Actually set the exit code */
      if (parent->exit_code_ptr!=NULL) {
	ASSERT(valid_user_mem(parent->ptd, (mem_t) parent->exit_code_ptr));
	*(parent -> exit_code_ptr) = status;

      }
      /* Now the parent has one less child */
      (parent->num_children)--;
      /* return value for the parent, and make him runnable */
      SET_EAX(parent, pcb->pid);
      parent->state = RUNNABLE;
      parent->flags = NORMAL;
      enable_interrupts();
    }
    //fall through
    else {    // parentis alive and not waiting
      /* we just remember the exit status for use if and when the parent calls wait */
      pcb->exit_code = status;
      disable_interrupts();

      /* Now we add ourselves to the list of dead children of our mighty father */
      if(!parent-> deadkids) {
	parent->deadkids = pcb;
      }
      else{
	for(t = parent-> deadkids; t->next; t = t-> next);
	t-> next = pcb;
      }

      /* restore the parents state*/
      parent->state = parent_state;
      
      /* when exit is done, we need to know who we want to run next*/
      t=pcb->next;
      flag = check_tid(pcb); /* Do we have to purge the ptd?*/


      
      // remove yourself from the list
      pcb -> next -> prev = pcb -> prev;
      pcb -> prev -> next = pcb -> next;
      pcb -> next = NULL;

      /* find the next runnable dude*/
      while ((t->state==STOPPED)||(t->sleep_time > timer_ticks)) {
	t=t->next;
      }

      enable_interrupts();

      /* If appropriate purge the virtual memory structure.
	 i.e. if its not shared. */
      if (flag) {
	disable_interrupts();
	set_cr3((int) t->ptd);
	page_ptd_purge(pcb->ptd);
	pcb->ptd = t->ptd;
	enable_interrupts();
      }

      /* Do the usual in terms of what we do when we context switch */
      if(t -> flags == NEWBORN)
	process_launch(t);
      else{
	//go back to where the next guy came from.      
	set_cr3((int) t->ptd);
	set_esp0((void*) t);
	set_esp(t->kesp);
	set_ebp(t->kebp);
	return;
      }
    }
  }
  /* If we come here, then there is nobody who will ever wait on us. So, we can go ahead and 
     kill ourselves */
  /* or parent was waiting */

  // purge everything, including pcb
  if (check_tid(pcb)) {
    disable_interrupts();
    set_cr3((int) pcb->next->ptd);    /* alok's fix */
    page_ptd_purge(pcb -> ptd);
    pcb->ptd = pcb->next->ptd;
    enable_interrupts();
  }
  /* we next use this guy to find  run.*/
  t = pcb->next;
    
  while ((t->state==STOPPED)||(t->sleep_time > timer_ticks)) {
    t=t->next;
 
    if (t==pcb)
      t=t->next;
  }
  // remove yourself from the list
  disable_interrupts();
  pcb -> next -> prev = pcb -> prev;
  pcb -> prev -> next = pcb -> next;

  /* Free our deadkids */
  deadkid = pcb->deadkids;
  while (deadkid) {
    pcb_struct *temp = deadkid->next;
    ks = (char*)deadkid + sizeof(pcb_struct) - KERNEL_STACK_SIZE;
    disable_interrupts();
    sfree(ks, KERNEL_STACK_SIZE);
    enable_interrupts();
    deadkid = temp;
  }


  set_esp((int)((char*)pcb->next->kesp - 256)); // borrow the neighbouring stack -256 for an unkown reason

  ks = (char*)pcb + sizeof(pcb_struct) - KERNEL_STACK_SIZE;
  disable_interrupts();
  sfree(ks, KERNEL_STACK_SIZE);

  /* Same routine as above in the previous cases */
  if(t -> flags == NEWBORN){
    enable_interrupts();
    process_launch(t);
  }
  else{
    set_cr3((int) t->ptd);
    set_esp0((void*) t);
    set_esp(t->kesp);
    set_ebp(t->kebp);
    enable_interrupts();

    return;  
  }
}

int check_tid(pcb_struct* pcb) {
  // return 1 if tid is unique, 0 otherwise
  pcb_struct* t = pcb->next;
  for (;(t!=pcb) && (t->tid!=pcb->tid);t=t->next);
  return (t==pcb); 
}



// Note that nobody should call this on themselves
void kill_process(pcb_struct *pcb){
  pcb_struct *pcb1 = GET_PCB(get_esp());
  char* ks;
  
  ASSERT(pcb != pcb1);
  /*
    This is meant only for killing minclones when a fork is made in one of them.
    Since this is going to be called on all but one of the members of the "family",
    There can't really be anyone who is going to be waiting on pcb, since 
    even if there were, that process would be killed as well.
  */
  pcb -> next -> prev = pcb -> prev;
  pcb -> prev -> next = pcb -> next;
  ks = (char*)pcb + sizeof(pcb_struct) - KERNEL_STACK_SIZE;
  disable_interrupts();
  sfree(ks, KERNEL_STACK_SIZE);
//  printf("Sfree (%d) of ks=%x\n", __LINE__, (int) ks);

  enable_interrupts();

  return;
}
