

/*
  
  syscalls.c: The function syscalls_handler is called when  an interrupt happens.
   The functions that are called in certain cases like deschedule and make runnable are
   also defined in this file.
  Authors: Alok Menghrajani & Vikram Manjunath
  
*/
#include <oskit/com/random.h>

#include "syscalls.h"
#include "../kernel.h"
#include "../util.h"
#include "../context.h"
#include "../process.h"

#include "../idt.h"
#include "../console.h"
#include "../keyboard.h"
#include "../inc/user_syscall.h"
#include "../inc/seg.h"
#include "../inc/interrupts.h"
#include "../inc/io_map.h"
#include "../inc/x86_regs.h"
#include "../context.h"
#include "../timer.h"

/* Proj 4 */
#include "../inc/syscall_nums.h"
#include "../filesystem/filesystem.h"

int valid_user_mem_str(pcb_struct *pcb, char *p, int maxlen);
int fork();
int exec(char* execname, char** argvec);
void our_exit(int status);
int wait(int* status_ptr);
void deschedule(int* flag);
void make_runnable(int pid);
void sysgetchar();
void readline(char* buf, int len);
void minclone();
int rand();

oskit_random_t* mr_unpredictable;


/*
  This function must be called before any interrupts can be handled.
  Ut sets yo tge random number generator and the idt_entry for int ox40.
 */
void syscalls_init() {
  struct idt_entry *entry;
  void* idt=sidt();

  entry = (struct idt_entry*) idt;
  entry+=0x40;
  entry->hoffset = ((unsigned short int)(((unsigned int)syscalls_handler_wrapper)>>16));
  entry->P = 1;
  entry->DPL = 3;
  entry->D = 0xF;
  entry->Ze = 0;
  entry->Seg = KERNEL_CS;
  entry->loffset = (unsigned short int) syscalls_handler_wrapper;

  // random number stuff
  oskit_random_create(&mr_unpredictable);
}

/*
  This is the function that is called from an assembly wrapper.
  All the various numbers for the syscalls are defined in user_syscall.h
 */


void syscalls_handler(int function, int argument) {
  pcb_struct *pcb = GET_PCB(get_esp());
  int t;
  switch (function) {

/* proj 4 */
  case SYSCALL_FS_MKFS:
    t=fs_mkfs(argument);
    SET_EAX(pcb, t);
    break;
  case SYSCALL_FS_OPEN:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN)) 
      SET_EAX(pcb, fs_open((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_CREATE:
    if (valid_user_mem_str(pcb, (char*) argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_create((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_CLOSE:
    SET_EAX(pcb, fs_close(argument));
    break;
  case SYSCALL_FS_READ:{
    io_t io = *((io_t*) argument);
    int i, valid;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    if (io.size<=0) {
      SET_EAX(pcb, -1);
      break;
    }
    valid = TRUE;
    i =0;
/*    for (i=0; i<io.size; i++) {
      if (!valid_user_mem(pcb->ptd, (int)(io.buf+i))) {
	valid = FALSE;
	break;
      }
    }*/
    if (valid){
      SET_EAX(pcb, fs_read(io.fd, io.buf, io.size));
    }
    else
      SET_EAX(pcb, -1);
    break;
  }
  case SYSCALL_FS_WRITE: {
    io_t * io = (io_t*) argument;
    int i, valid;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    if (io->size<=0) {
      SET_EAX(pcb, -1);
      break;
    }
    valid = TRUE;
    for (i=0; i<io->size; i++) {
      if (!valid_user_mem(pcb->ptd, (int) (io->buf+i))) {
	valid = FALSE;
	break;
      }
    }

    if (valid)
      SET_EAX(pcb, fs_write(io->fd, io->buf, io->size));
    else
      SET_EAX(pcb, -1);
    break;
  }

  case SYSCALL_FS_SEEK: {
    seeker_t * s = (seeker_t *) argument;
    int t;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    t = fs_seek(s->fd, s->offset);
    SET_EAX(pcb, t);
    break;
  }
  case SYSCALL_FS_LINK: {
    filename_t* f = (filename_t *) argument;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    if (valid_user_mem_str(pcb, f->old, MAXPATHNAMELEN) && valid_user_mem_str(pcb, f->new, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_link(f->old, f->new));
    else
      SET_EAX(pcb, -1);
    break;
  }
  case SYSCALL_FS_SYMLINK: {
    filename_t* f = (filename_t *) argument;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    if (valid_user_mem_str(pcb, f->old, MAXPATHNAMELEN) && valid_user_mem_str(pcb, f->new, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_symlink(f->old, f->new));
    else
      SET_EAX(pcb, -1);
    break;
  }
  case SYSCALL_FS_UNLINK:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_unlink((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_FILESIZE:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_filesize((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_MKDIR:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_mkdir((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_RMDIR:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_rmdir((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_CHDIR:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_chdir((char*) argument)); 
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_DIRSIZE:
    if (valid_user_mem_str(pcb, (char*)argument, MAXPATHNAMELEN))
      SET_EAX(pcb, fs_dirsize((char*) argument));
    else
      SET_EAX(pcb, -1);
    break;
  case SYSCALL_FS_DIRENTRY:{
    direntry_t * d = (direntry_t *) argument;
    int i, valid;
    if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      return;
    }
    if ((d->entrypos<0) || !valid_user_mem_str(pcb, d->pathname, MAXPATHNAMELEN)) {
      SET_EAX(pcb, -1);
      break;
    }
    valid = TRUE;
    for (i=0; i<MAXFILENAMESIZE; i++) {
      if (!valid_user_mem(pcb->ptd, (int) (d->entryname+i))) {
	valid = FALSE;
	break;
      }
    }
    if (valid)
      SET_EAX(pcb, fs_direntry(d->pathname, d->entrypos, d->entryname));
    else
      SET_EAX(pcb, -1);
    break;
  }
  case SYSCALL_FS_SYNC:
    SET_EAX(pcb, fs_sync());
    break;
  case SYSCALL_FS_PWD:
    SET_EAX(pcb, fs_pwd((char*) argument));
    break;
		/* old proj */

  case SYSCALL_EXIT:
    our_exit(argument);
    break;
  case SYSCALL_YIELD:
    SET_EAX(pcb, 0);
    context_switch(argument);    
    break;
  case SYSCALL_DESCHEDULE:
    if(!valid_user_mem(pcb->ptd, argument)){ /* check that the address in argument is a valid address */
      SET_EAX(pcb, -1);
      break;
    }
    deschedule((int*) argument);
    break;
  case SYSCALL_MAKE_RUNNABLE:
    make_runnable(argument);
    break;
  case SYSCALL_GETPID:
    SET_EAX(pcb, pcb->pid);
    break;
  case SYSCALL_SBRK:
    if (argument == NULL) {
      SET_EAX(pcb, pcb->mem_limit);
    } else if ((mem_t) argument < pcb->mem_limit) { /* Make sure that we are not moving the brk down */
      SET_EAX(pcb, -1);
    } else {
      pcb->mem_limit = (mem_t) argument;
      SET_EAX(pcb, 0);
    }
    break;
  case SYSCALL_MINCLONE:
    minclone();
    break;
  case SYSCALL_SLEEP:
    if (argument == 0) {
      SET_EAX(pcb, 0);
      context_switch(pcb->pid);
    } else if (argument < 0) {
      SET_EAX(pcb, -1);
      context_switch(pcb->pid);
    } else {
      SET_EAX(pcb, 0);      
      pcb -> sleep_time = argument + timer_ticks;
      context_switch(-1);
    }
    break;
  case SYSCALL_RAND: {
    int rand_num;
    disable_interrupts();
    oskit_random_random(mr_unpredictable,&rand_num);
    enable_interrupts();
    SET_EAX(pcb, rand_num);
    break;
  }
  case SYSCALL_PRINT: {
    pstring_t *t;
    int i, valid;
   /* make sure that all the memory pointed to by the string 
      which the user wants us to pring is valid memory
   */
    
    t = (pstring_t*) argument;
/*    
      if (!valid_user_mem(pcb->ptd, argument)) {
      SET_EAX(pcb, -1);
      break;
    }
    if (t->len > 128 || t->len < 0) {
      SET_EAX(pcb, -1);
      break;
    }
*/    // check until 0 or len
    valid = TRUE;
    for (i=0; i<t->len; i++) {
/*      if (!valid_user_mem(pcb->ptd, (int) (t->st+i))) {
	  valid = FALSE;
	  break;
        }
*/
      if (t->st[i]==0) {
	break;
      }
    }
    valid = TRUE;
    if (valid) {
      disable_interrupts();
      putbytes(t->st, i);
      enable_interrupts();
      SET_EAX(pcb, 0);  
      break;
    } else {
      SET_EAX(pcb, -1);
      break;
    }  
  }
  case SYSCALL_SET_TERM_COLOR:
    if ((unsigned int)argument>0xff) {
      // invalid color
      SET_EAX(pcb, -1);
    } else {
      SET_EAX(pcb, 0);
      disable_interrupts();
      set_term_color(argument);
      enable_interrupts();
    }
    break;
  case SYSCALL_SET_CURSOR_POS: {
    cpos *t;
    if(!valid_user_mem(pcb->ptd, argument)){
      SET_EAX(pcb, -1);
      break;
    }

    t = (cpos*) argument;
    /* Make sure that the struct pointed to is within the valid memory */
    
    if (t!=NULL) {
      if (((unsigned int)t->row >= CONSOLE_HEIGHT) || ((unsigned int)t->col >= CONSOLE_WIDTH)) {
	SET_EAX(pcb, -1);
      } else {
	SET_EAX(pcb, 0);
	disable_interrupts();
	set_cursor(t->row, t->col);
	enable_interrupts();
      }
    }
    else
      SET_EAX(pcb, -1);
    break;
  }
  case SYSCALL_GET_SINGLE_CHAR:
    sysgetchar();
    break;
  case SYSCALL_FORK:
    fork();
    break;
  case SYSCALL_EXEC:{
    exec_t *t;
    int valid, i, j;

    t = (exec_t*) argument;

    /* USER ARGUMENT CHECK START */
    // check the argument
    if(!valid_user_mem(pcb->ptd, (int) t)){
      SET_EAX(pcb, -1);
      break;
    }
    /* Check that there are max 256 characters in the execname */
    if (!valid_user_mem_str(pcb, t->execname, MAXPATHNAMELEN)) {
      SET_EAX(pcb, -1);
      break;
    }
    /* Check that argvec is a valid array and points to valid data */
    /* we step through all the memory invloved in the argument for the 
       exec. */
    valid = TRUE;
    i = 0;
    while (1) {
      if(!valid_user_mem(pcb->ptd, (int)(t->argvec+i))) {
	valid = FALSE;
	break;
      }
      if (t->argvec[i] ==  NULL)
	break;
      j = -1;
      do {
	j++;
	if(!valid_user_mem(pcb->ptd, (int)((t->argvec[i])+j))) {
	  valid = FALSE;
	  break;
	}
      } while((t ->argvec[i])[j] !=  NULL);
      if (!valid)
	break;
      i++;
    }
    
    if(!valid){
      SET_EAX(pcb,-1);
      break;
    }
    /* USER ARGUMENT CHECK END */

    exec(t->execname, t->argvec);
    break;
  }
  case SYSCALL_WAIT:
    /* USER ARGUMENT CHECK START */
    // If the user supplies an argument, we must check it
    if (argument!=NULL)
      if (!valid_user_mem(pcb->ptd, argument)) {
	SET_EAX(pcb, -1);
	break;
      }
    /* USER ARGUMENT CHECK END */
    wait((int*) argument);
    break;
  case SYSCALL_READLINE: {
    pstring_t *t;
    int i, valid;
    t = (pstring_t*) argument;

    /* USER ARGUMENT CHECK START */
    valid = TRUE;
    // Check that t is valid
    if (!valid_user_mem(pcb->ptd, (int)t)) {
      valid = FALSE;
    } else {
      // Check that st is valid
      for (i=0; i<t->len; i++) {
	if (!valid_user_mem(pcb->ptd, (int)(t->st+i))) {
	  valid = FALSE;
	  break;
	}
      }
    }
    if (!valid) {
      SET_EAX(pcb, -1); // on error, return zero characters read
      break;
    }
    /* USER ARGUMENT CHECK END */

    readline(t->st,t->len);
    break;
  }
  default:
    ASSERT(0);
  }
}

int valid_user_mem_str(pcb_struct* pcb, char *p, int maxlen) {
  // Checks that the str is valid (length and user mem)
  // returns TRUE or FALSE
  int i;
  for (i=0; i<maxlen; i++) {
    if (!valid_user_mem(pcb->ptd, (int) (p+i)))
      return FALSE;
    if (p[i]==0)
      return TRUE;
  }
  return FALSE;
}


void deschedule(int* flag) {
  pcb_struct* pcb = GET_PCB(get_esp());

  disable_interrupts();  

  /* check that the value at flag is not 0. if it is, then return */
  if(* flag != 0){
    SET_EAX(pcb, 0);
    enable_interrupts();
    return;
  }
  /* Once we are marked as stopped, we are not going to be run */
  pcb -> state = STOPPED;
  pcb -> flags = DESCHEDULED;
  SET_EAX(pcb, 1); // write up says a non-zero value
  enable_interrupts();
  context_switch(-1);
}


void make_runnable(int pid) {
  pcb_struct *temp, * pcb = GET_PCB(get_esp());

  // find the guy who is supposedly stopped
  for(temp = pcb->next; temp != pcb && temp-> pid != pid; temp = temp-> next);

  disable_interrupts();
  if(temp !=pcb && temp-> state == STOPPED && temp-> flags == DESCHEDULED){
    // return ok if it was stopped/descheduled
    SET_EAX(pcb, 0);
    temp -> state = RUNNABLE;
    temp -> flags = NORMAL;
  }
  else {
    SET_EAX(pcb, -1); // should return ERROR
  }
  enable_interrupts();
  context_switch(-1);
}

void readline(char* buf, int len){
  pcb_struct* t, *pcb = GET_PCB(get_esp());

  // mark self as "waiting on keypress and stopped
  disable_interrupts();
  pcb -> state = STOPPED;
  pcb -> flags = KEY_WAITING;
  pcb -> key_buf = buf;
  pcb -> key_buf_len = len;
  pcb -> key_buf_index = 0;
  pcb -> next_key_waiting = NULL;
  // enqueue yourself.

  pcb->next_key_waiting = NULL;
  if(key_wait_queue == NULL) {
    /* Put VM memory if disabled, change the cr3 to the key_wait_queue's ptd
       The reason that we have to do this is that we need to fill a buffer which
       is in user memory.
       The reason that we do some reading here is that we may have keypresses
       that  are buffered even before we call a read
    */
    
    int cr0 = get_cr0();
    int cr3 = get_cr3();
    unsigned char c;

    SET_PG;
    set_cr3((int) pcb->ptd);
    while (1) {
      c = readchar();
      if (c==0xff) {
	key_wait_queue = pcb;
	break;
      }

      // readline case
      if (c == '\b') {
	if (pcb->key_buf_index>0) {
	  // a backspace was hit
	  pcb->key_buf_index--;
	  putbytes(&c, 1);
	}
      } else {
	pcb->key_buf[pcb->key_buf_index++] = c;
	putbytes(&c, 1);
      }
      if ((c == '\n') || (pcb->key_buf_index==(pcb->key_buf_len-1))) {
	// we hit the end of line (minus one, because we are going to add a zero termination
	pcb->key_buf[pcb->key_buf_index] = NULL;
	SET_EAX(pcb, pcb->key_buf_index);
	pcb->state = RUNNABLE;
	pcb->flags = NORMAL;
	break;
      }
    }
    // VM stuff restore
    set_cr3(cr3);
    set_cr0(cr0);
  } else {
    /* if this (there is nothing in the buffer) is the case, we need to queue ourselves for keyboard input */
    for(t = key_wait_queue; t -> next_key_waiting != NULL; t = t->next_key_waiting);
    t->next_key_waiting = pcb;
  }

  enable_interrupts();

  context_switch(-1);
}

void sysgetchar() {
  pcb_struct *pcb = GET_PCB(get_esp());
  pcb_struct *t;
  unsigned char c;

  // mark self as "waiting on keypress and stopped
  pcb -> state = STOPPED;
  pcb -> flags = KEY_WAITING;
  pcb -> key_buf = NULL;

  // enqueue yourself.
  disable_interrupts();
  pcb -> next_key_waiting = NULL;
  if(key_wait_queue == NULL) { 
    /* if the queue is empty, then you can just grab anything that is in the buffer */
    c = readchar();
    if(c != 0xff){
      /* if there is something in the buffer, then you can just return that */
      SET_EAX(pcb, c);
      pcb -> state = RUNNABLE;
      pcb -> flags = NORMAL;
      return;
    }
    /* if not then queue */
    key_wait_queue = pcb;
  }
  else {
    /* find the end of the queue to put yourself */
    for(t = key_wait_queue; t->next_key_waiting != NULL; t = t->next_key_waiting);
    t->next_key_waiting = pcb;
  }
  enable_interrupts();

  context_switch(-1);
}

