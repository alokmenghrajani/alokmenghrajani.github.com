#ifndef KEYBOARD_H
#define KEYBOARD_H

#define RING_SIZE 128

void keyboard_init();
unsigned char readchar();
extern void keyboard_handler_wrapper();

#endif /* KEYBOARD_H */
