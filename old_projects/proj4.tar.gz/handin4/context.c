
/*

  console.c: the contex_switch funtion is defined here. It takes care of the
  switching to a new process when it is called.

  Authors: Alok Menghrajani & Vikram Manjunath

 */
#include "context.h"
#include "kernel.h"
#include "inc/x86_regs.h"
#include "process.h"
#include "util.h"
#include "timer.h"
#include "inc/seg.h"

void context_switch(int pid) {
  pcb_struct *pcb = (pcb_struct*) GET_PCB(get_esp()), *temp;

  /* now that we are going to switch, the running process that is 
     being preempted is marked as runnable */
  if(pcb -> state == RUNNING)
    pcb -> state = RUNNABLE;
    
  // save the kesp so that we can resume a process which is in kernel mode
  pcb -> kesp = get_esp();
  pcb -> kebp = get_ebp();

  if (pid!=-1) { 
    // find the pid
    temp = find_pcb(pid);
    // check if it's a valid pid and runnable
    /* find the next runnable pcb, which is awake ( sleep time is before  current time)
       and not stopped */
    if ((!temp) || (temp->state == STOPPED) || (temp -> sleep_time > timer_ticks)) {
      SET_EAX(pcb, -1);            
    } 
    else {
      if (temp->flags == NEWBORN) {
	/* in the case of a newborn, we can jump straight in
	   as though the we just interrupted it in its user mode */
	temp->flags = NORMAL;
	process_launch(temp);
      } else {
	/* in this case, we need to set the cr3 to the appropriate 
	   ptd and set the esp and ebp properly. */
	temp->state = RUNNING;
	// set the page table directory.
	set_cr3((int) temp->ptd);
	set_esp0((void*) temp);
	set_esp(temp->kesp);
	set_ebp(temp->kebp);
	return;
      }
    }
  } 
  else {  
    // Round robin scheduling
    temp = pcb->next;
    /* find the next runnable pcb, which is awake ( sleep time is before  current time)
       and not stopped */
    
    while(temp->state == STOPPED ||(temp -> sleep_time > timer_ticks) ){
      temp = temp -> next;
    }
    if (temp->flags == NEWBORN) {
      /* in the case of a newborn, we can jump straight in
	 as though the we just interrupted it in its user mode */
      temp->flags = NORMAL;
      process_launch(temp);
    } else {
      /* in this case, we need to set the cr3 to the appropriate 
	 ptd and set the esp and ebp properly. */
      temp->state = RUNNING;
      // set the page table directory.
      set_cr3((int) temp->ptd);
      set_esp0((void*) temp);
      set_esp(temp->kesp);
      set_ebp(temp->kebp);
      return;
    }
  }
}

/* obviously this finds a pointer to the pcb with the pid pid */
pcb_struct* find_pcb(pid_t pid) {
  pcb_struct *temp, *pcb = GET_PCB(get_esp());
  temp=pcb->next;
  while((temp->pid!=pid) && (temp!=pcb))
      temp=temp->next;

  return ((temp->pid==pid) ? temp : NULL);
}
