/*

  kernel.c: the main funtion is defined here. It takes care of the
  bootstrapping to spawn a shell.

  Authors: Alok Menghrajani & Vikram Manjunath

 */

/* OSKit libc includes. */
#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>

/* OSKit includes. */
#include <oskit/clientos.h>
#include <oskit/startup.h>

/* 412 includes. */
#include <412/seg.h>
#include "kernel.h"
#include "timer.h"
#include "page.h"
#include "voidint.h"
#include "processkillint.h"
#include "process.h"
#include "inc/interrupts.h"
#include "syscalls/syscalls.h"
#include "console.h"
#include "keyboard.h"

/* proj 4 */
#include "filesystem/filesystem.h"
#include "inc/disk.h"
#include "inc/common.h"
#include "filesystem/buffercache.h"

extern lmm_t malloc_lmm;

char shit[512];

/* Kernel entrypoint. */
int main() {
  ptd_struct *ptd1;
  pcb_struct *pcb1;
  char * argv = NULL;
  getting_started_flag = 1;

  /* Do not remove the following five lines. */ 
  lmm_remove_free(&malloc_lmm, (void *)0, 0x100000);
  lmm_remove_free(&malloc_lmm, (void*)USER_MEM_START, USER_MEM_SIZE);
#ifndef KNIT
  oskit_clientos_init();
#endif
  install_user_segs(USER_CS_SEGSEL >> 3,USER_DS_SEGSEL >> 3);

  next_pid = 0;

  /* Install the interrupt handlers */
  ptd1 = page_init();
  syscalls_init();
  timer_init();
  keyboard_init();
  voidint_init(39);  // We don't want to have the unexpected interrupt 7
  processkillint_init(0); // Division by zero
  processkillint_init(4); // Overflow
  processkillint_init(6); // Invalid opcode
  processkillint_init(13); // General protection

  /*Install before this.*/
  remap_intr();
  if (disk_init()!=SUCCESS) {
    printf("FATAL ERROR WHILE INIT DISK !\n");
    return -1;
  }

  /* file system stuff */
  cache_init();
  fs_init();
  if (fs_readmkfs()!=SUCCESS) {
    printf("WARNING: HD NOT FORMATTED !!!\n");
  }
  /* ----------------- */

  /* Clear the console */
  set_term_color(FGND_BBLUE | BGND_BLACK);
  clear_console();
  show_cursor();

  // create first processe */
  pcb1 = process_create(ptd1, next_pid++, &argv);
  if (!pcb1) {
    printf("FATAL ERROR WHILE TRYING TO BOOTSTRAP FIRST PROCESS !\n");
    return -1;
  }
  pcb1-> next = pcb1;
  pcb1-> prev = pcb1;
  pcb1 -> state = RUNNABLE;
  pcb1 -> flags = NEWBORN;

  getting_started_flag = 0;
  process_launch(pcb1);
  return 0;
}
