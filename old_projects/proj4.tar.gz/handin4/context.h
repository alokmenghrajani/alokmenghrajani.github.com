#ifndef CONTEXT__H
#define CONTEXT__H

#include "kernel.h"

void context_switch(int pid);
pcb_struct* find_pcb(pid_t pid);

#endif /* CONTEXT__H */
