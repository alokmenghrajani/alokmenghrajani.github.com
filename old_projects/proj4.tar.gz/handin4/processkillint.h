#ifndef PROCESSKILLINT__H
#define PROCESSKILLINT__H

#include "kernel.h"

/* install the handler */
void processkillint_init(int nb);

/* must install this !!! */
extern void processkillint_handler_wrapper();

void processkillint_handler();
#endif /* PROCESSKILLINT__H */
