#include "userlib.h"
#define MAX_LENGTH 1024  /* Should be long enough to hold any line */
#define NULL 0

#define MAXFILENAMESIZE 32
#define MAXPATHNAMELEN 100

int strcmp(const char* a, const char* b) {
  while((a && b) && (*a && *b)) {
    if (*a > *b) return 1;
    else if (*a < *b) return -1;
    a++; b++;
  }
  if (*b) return -1;
  if (*a) return 1;
  return 0;
}

int strlen(const char* st) {
  int rv = 0;

  while (*st) {
    st++;
    rv++;
  }

  return rv;
}

void bzero(void* addr, int size) {
  while(size--) {
    *(char*)(addr++) = 0;
  }
}

int atoi(char* buf) {
  int rv = 0;
  int neg = 0;
  if (*buf == '-') {
    neg = 1;
    buf++;
  }
  while(*buf >= '0' && *buf <= '9') {
    rv *= 10;
    rv += ((*buf)-((int)'0'));
    buf++;
  }
  if (neg) rv *= -1;
  return rv;
}

int strtok_isdelim(char c, const char* delim) {
  while(*delim) {
    if (c == *delim) return 1;
    delim++;
  }
  return 0;
}

char* strtok(char* s, const char* delim) {
  static char* st_iter = NULL;
  char* token;
  if (s) st_iter = s;
  if (!s && (!st_iter || !(*st_iter))) return NULL;

  /* Look in s for first delimiting character. */
  token = st_iter;
  while(*st_iter && !strtok_isdelim(*st_iter,delim))
    st_iter++;
  /* We either found a delimiter or the end of the string. */
  *st_iter = 0;
  st_iter++;
  return token;
}



void ls(char *pathname) {
  char lsbuf[MAXPATHNAMELEN];
  int s;
  int i, t;
  if(strcmp(pathname,"/root")==0){
    pathname[0]='/';
    pathname[1]=NULL;
  }
  s = test_error(dirsize(pathname), __LINE__);

  for (i=0; i<s; i++) {
    t=test_error(direntry(pathname, i, lsbuf), __LINE__);
    print_str(lsbuf);
    print(1," ");
  }
  print(1,"\n");
}


int append(char* pathname, char* shit){
  int fd = open(pathname);
  int x;
  if(fd == -1)
    fd = create(pathname);

  if(fd == -1){
    print_str("can't open or create file\n");
    return -1;
  }
  x= write(fd, shit, strlen(shit));
  close(fd);
  if(x == -1) 
    print_str("error writing\n");
  return x;
}

int cat(char* pathname){
  int fd = open(pathname),n;
  char* buffer[100];
  if(fd ==-1){
    print_str("can't open :");
    print_str(pathname);
    print(1,"\n");
    return -1;
  }
  while(n = read(fd, buffer,100)){
    print(n,buffer);
  }
  close(fd);
  return 0;    
}


main(int argc, char *argv[])
{
  char buf[MAX_LENGTH];
  char msgbuf[128];
  char * cmd_argv[MAX_LENGTH];  /* An overkill for expediency */
  char * prompt = "shell> ";
  char * startmsg = "Starting shell...\n";
  char * exitmsg = "Exiting shell...\n";
  char separators[4];
  int termno;
  int err;
  char buf2[256];
  int bg =0;
  separators[0] = ' ';
  separators[1] = '\t';
  separators[2] = '\n';
  separators[3] = '\0';


  print_str(startmsg);

  while(1)
    {
      int n, i, pid;
      int res;
      int j = 0;
      int numofargs=0;
      bzero(buf, MAX_LENGTH);
      print_str(prompt);
      n = readline(MAX_LENGTH, buf);

      if(n == 0 || n >= MAX_LENGTH)		/* line too big */
	continue;
      buf[n] = '\0';
      if(!(cmd_argv[j++] = strtok(buf, separators)))
	continue;



      if(strcmp(cmd_argv[0], "exit") == 0) {
	print_str(exitmsg);
	sync();
	exit(0);
      }
      /* tree */
      if(strcmp(cmd_argv[0], "pwd") == 0) {
	pwd(buf2);
	print_str(buf2);
	print(1,"\n");
	continue;
      }
      if(strcmp(cmd_argv[0], "ls") == 0) {
	ls(".");
	continue;
      }

      while(cmd_argv[j++] = strtok(NULL, separators));
      if(strcmp(cmd_argv[0],"cd") == 0){
	if(!cmd_argv[1]) continue;
	if(chdir(cmd_argv[1]) != 0){
	  print(13,"can't cd to ");
	  print(strlen(cmd_argv[1]),cmd_argv[1]);
	  print(1,"\n");
	}
	continue;
      }
      if(strcmp(cmd_argv[0],"mkdir") == 0){
	if(!cmd_argv[1]) continue;
	if(mkdir(cmd_argv[1]) == -1)
	  print_str(" can't make dir\n");
	continue;
      }

      if(strcmp(cmd_argv[0],"touch") == 0){
	int fd;
	if(!cmd_argv[1]) continue;
	fd =create(cmd_argv[1]);
	if(fd != -1) close(fd);
	continue;
      }

      if(strcmp(cmd_argv[0], "append") == 0){
	if(!cmd_argv[1] || !cmd_argv[2]) continue;
	if(append(cmd_argv[1],cmd_argv[2]) == -1){
	  print(17,"error appending\n");
	}
	continue;
      }
      if(strcmp(cmd_argv[0],"cat") == 0){
	if(!cmd_argv[1]) continue;
	cat(cmd_argv[1]);
	print(1,"\n");
	continue;
      }
      if(strcmp(cmd_argv[0],"size") == 0){
	int size;
	if(!cmd_argv[1]) continue;
	size =filesize(cmd_argv[1]);
	if(size == -1){
	  print("can't determine size\n");
	  continue;
	}


	print_str("size of ");
	print_str(cmd_argv[1]);
	print_str(": ");
	print_int(size);
	print_str("\n");
	continue;
      }
      if(strcmp(cmd_argv[0],"ln") == 0){
	if(!cmd_argv[1]) continue;
	if(strcmp(cmd_argv[1],"-s") == 0){
	  if(cmd_argv[2] && cmd_argv[3])
	    if(symlink(cmd_argv[3],cmd_argv[2]) == -1)
	      print_str("Error in symlinking\n");
	}
	else{
	  if(cmd_argv[2])
	    if(link(cmd_argv[2],cmd_argv[1]) == -1)
	      print_str("Error in linking\n");
	}
	continue;
      }
      if(strcmp(cmd_argv[0],"rm") == 0){
	if(!cmd_argv[1]) continue;
	if(unlink(cmd_argv[1])==-1) {
	  print_str("Error in unlinking\n");
	}
	continue;
      }
      if(strcmp(cmd_argv[0],"rmdir") == 0){
	if(!cmd_argv[1]) continue;
	if(rmdir(cmd_argv[1])==-1) 
	  print_str("Error in deleting dir\n");
	continue;
      }
      if(strcmp(cmd_argv[0],"format") == 0){
	if(mkfs(8192)==-1) 
	  print_str("Error in formatting dir\n");
	continue;
      }
      
      if(strcmp(cmd_argv[0],"")==0)continue;

      while(cmd_argv[numofargs])
	numofargs++;

      if(numofargs == 0)
	continue;

      bg =0;
      
      {
	int last=0;
	char* lastarg = cmd_argv[numofargs-1];

	while(lastarg[last])
	  last++;

	if(lastarg[last-1] == '&'){
	  bg = 1;
	  lastarg[last-1] = 0;
	}
      }
      

      if(pid = fork())
	{
	  if(pid < 0)
	    {
	      snprintf(msgbuf,128,"Cannot fork process (errno = %d).\n",pid);
	      print_str(msgbuf);
	      continue;
	    }
	  if(!bg){
	    if ((pid = wait(&res)) == 0) {
	      snprintf(msgbuf,128,"Pid %d exited (status = %d)\n",pid,res);
	      print_str(msgbuf);
	    }
	    else {
	      snprintf(msgbuf,128,"Pid %d exited with status %d.\n",pid,res);
	      print_str(msgbuf);
	    }
	  }
	  // NOT collecting background processes. :P
	}
      else
	{
//	  int t;
	  print_str(cmd_argv[0]);
	  print(1, "\n");
	  exec(cmd_argv[0], cmd_argv);
	  snprintf(msgbuf,128,"Could not exec \"%s\".\n",buf);
//	  t = strlen(msgbuf);
//	  print_int(strlen(msgbuf)); 
	  exit(-2);
	}
    }
}




