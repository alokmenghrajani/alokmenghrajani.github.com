#include "syscall_wrapper.h"
#include "malloc.h"


typedef struct shit_{
  int fuck;
  int slut;
  char cock;
  struct shit_ * next;
  struct shit_ * prev;
  int biatchmotherfucker[100];
} ass_biatch;


void print_int(int i) {
  char buf[2];
  int a;
  buf[1]=0;
  if (i<0) {
    print(1,"-");
    i=-i;
  }
  a=i%10;
  i=i/10;
  buf[0]='0'+a;
  if (i>0)
    print_int(i);
  print(1,buf);
}



ass_biatch* new_fuck(){
  return (ass_biatch*) mm_malloc(sizeof (ass_biatch));
}

int main(){
  ass_biatch* motherfucker;
  int i;
  mm_init();
  motherfucker = new_fuck();
  motherfucker -> next = motherfucker ->prev = motherfucker;
  
  for(i=0; i< 10; i++){
    ass_biatch* t = new_fuck();
    t -> next = motherfucker -> next;
    t -> prev = motherfucker;
    motherfucker -> next = t;
    t -> next-> prev = t;
    print(8,"new guy: ");
    print_int( (int) t);
    print(1,"\n");
  }

  for(i=0; i< 10; i++){
    ass_biatch* t = motherfucker;
    motherfucker -> next-> prev = motherfucker-> prev;
    motherfucker->prev -> next = motherfucker->next;
    motherfucker = motherfucker-> next;
    print(8,"old guy: ");
    print_int( (int) t);
    print(1,"\n");
    mm_free(t);
  }
  return 999;
}
