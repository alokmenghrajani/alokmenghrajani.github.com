/** 
 * 15-412 Project 4 (Filesystem) Test Suite v1.0
 * Yuen-Lin Tan (tyl@cmu.edu)
 */

#ifndef __FS_TESTS_H__
#define __FS_TESTS_H__

/* Disk geometry */
#define NUM_SECTORS 10080
#define SECTOR_SIZE 512

/* Filesystem specific constant(s) */
#define MAXFILENAMESIZE 255

#define SUCCESS 0
#define ERROR   -1
#define NOTRUN  -2
#define FST_MAX_TESTS 50
#define FST_MAX_STRLEN 255
#define RAND_MAX 2147483647

/* ID's of course-provided tests */
typedef enum {FST_BASIC_OPS, FST_PROCESS_FDT, FST_INODE_LIMIT,
              FST_ZERO_DATA, FST_REM_REFCNTS, FST_REM_LNKCNTS,
              FST_CYCL_SYMLNK, FST_LARGE_FILE, FST_ATOM_WRITE,
              FST_BUFF_RWSPEED, FST_3CREATES, FST_LONG_SEEK} fst_testID;

typedef struct {
  int result;
  int (*function) (void);
} fst_test;

/* FS syscall wrappers */
int fst_mkfs (int max_inodes);
int fst_createFile (char *path, int *fd);
int fst_createFiles (int num, char ***pathList, char ***nameList, int *fds);
int fst_closeFile (int fd);
int fst_closeFiles (int *fds, int numFiles);
int fst_openFile (char *filePath, int *fd);
int fst_openFiles (char **filePaths, int numFiles, int *fds);
int fst_verifyDirSize (char *dirPath, int expectedNum);
int fst_verifyDirEntries (char *dirPath, int dirSize, char **entries, int numEntries);
int fst_unlinkFile(char *filePath);
int fst_unlinkFiles(char **filePaths, int numFiles);
int fst_write (int fd, void *buf, int size, int *u_retsize);
int fst_read (int fd, void *buf, int size, int *u_retsize);
int fst_writeReadTest (int *fds, char **filePaths, int numFiles, int dataSize);
int fst_seek (int fd, int off, int *new_off);
int fst_link (char *oldname, char *newname);
int fst_symlink (char *oldname, char *newname);
int fst_filesize (char *pathname, int *retSize);
int fst_mkdir (char *pathname);
int fst_rmdir (char *pathname);
int fst_chdir (char *pathname);

/* Test modules */
int fst_basic_ops ();
int fst_process_fdt ();
int fst_inode_limit ();
int fst_zero_data ();
int fst_rem_refcnts ();
int fst_rem_lnkcnts ();
int fst_cycl_symlnk ();
int fst_large_file ();
int fst_atom_write ();
int fst_buff_rwspeed ();
int fst_3creates ();
int fst_long_seek ();

/* Mini C-library functions */
int fst_atoi (char *buf);
void fst_memset (void *ptr, int size, char byte);
int fst_strcmp(char *a, char *b);
void fst_strncpy (char *dst, char *src, int size);
void fst_print (char *str);

/* Miscellanous functions */
unsigned int fst_timeFunction (void (*fn) (void));
//int fst_cleanup (fst_testState *state);
int fst_regUserTest (int tid, int (*testfn)(void));
void fst_initUserTests ();  /* defined in fst_config.c */

/* Filesystem interface */
int mkfs (int max_inodes);
int open (char *pathname);
int close (int fd);
int create (char *pathname);
int read (int fd, void *buf, int size);
int write (int fd, void *buf, int size);
int seek (int fd, int offset);
int link (char *oldname, char *newname);
int symlink (char *oldname, char *newname);
int unlink (char *pathname);
int filesize (char *pathname);
int mkdir (char *pathname);
int rmdir (char *pathname);
int chdir (char *pathname);
int dirsize (char *pathname);
int direntry (char *pathname, int entrypos, char *entryname);
int sync (void);


#endif
