/*
  to compile:
  gcc -c p1.c -nostdinc -g
  objcopy -R .comment -R .note -R .stab -R .stabstr p1.o p1.o
  ld -T ../proj3/i386linux.x -n -Ttext 1000010 -o p1.out p1.o

*/

#include "syscall_wrapper.h"

int main() {
  int i,l,t;
  char buf[100];
  char c;  
  t = 0;


 if (fork()) {

    for(;;){
      i=readline(100,buf);
      print(i, buf);
    }
 }
  else{
    yield(0);
    for(;;) {
      
      l=rand();
      l=l%20+3;
      for (i=0; i<l; i++) {
	t=rand();
	t=t%('z'-'a'+1);
	c=(char) (t+'a');
	set_term_color(FGND_GREEN | BGND_BLUE);
        print(1,&c);
	set_term_color(FGND_BLUE | BGND_BLACK);
	sleep(30);
      } 
      set_term_color(FGND_GREEN | BGND_BLUE);
      print(1," ");
      set_term_color(FGND_BLUE | BGND_BLACK);
      sleep(100);
    }
    
    for(;;);
  }

}
