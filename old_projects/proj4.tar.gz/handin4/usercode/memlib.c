/* memlib.c - functions for modeling the memory system */
/* $begin memlib */

#ifndef NULL
#define NULL 0
#endif

/* private global variables */
static char *mem_start_brk;  /* points to first byte of the heap */
static char *mem_brk;        /* points to first invalid byte (byte after
				end of heap) */
static char *mem_max_addr;   /* max virtual address for the heap */

/* 
 * mem_init - initializes the memory system model
 */
void mem_init(int max_heap_addr)
{
  /* Find out start of heap. */
  mem_start_brk = (char*)brk((void*)NULL);
  /* Heap starts out being zero-sized. */
  mem_brk = mem_start_brk;
  /* The max address for the heap. */
  mem_max_addr = (void*)max_heap_addr;
}

/* 
 * mem_sbrk - simply uses the the sbrk function. Extends the heap 
 *    by incr bytes and returns the start address of the new area. In
 *    this model, the heap cannot be shrunk.
 */
void *mem_sbrk(int incr) 
{
    char *old_brk = mem_brk;

    /* Error check the request. */
    if ( (incr < 0) || ((mem_brk + incr) > mem_max_addr)) {
      return (void *)NULL;
    }

    /* Issue a SBRK for more memory. */
    if (brk((void*)(mem_brk + incr))) {
      return (void *)NULL;
    }

    mem_brk += incr;
    return (void *)old_brk;
}
/* $end memlib */
