#ifndef USERLIB__H
#define USERLIB__H

#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))

#define ASSERT(ex) {\
if (!(ex)) {\
  print_str("Assert failed !\n"); \
  print_str(__FILE__); \
  print_int(__LINE__); \
  for(;;); \
}}


void print_str(char *str);
void print_int(int i);
void strncpy(char* dest, char* src, int n);
void strcat(char *dest, char*src);
int test_error(int t, int line);

#endif /* USERLIB__H */
