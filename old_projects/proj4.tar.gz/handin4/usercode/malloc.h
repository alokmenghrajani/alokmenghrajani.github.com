/* $begin mallocinterface */
int mm_init(void); 
void *mm_malloc(int size); 
void mm_free(void *bp);
/* $end mallocinterface */

#ifndef NULL
#define NULL 0
#endif
