// USED FOR LINKED USER CODE ONLY

#ifndef ASM_SYSCALL_H
#define ASM_SYSCALL_H

extern int asm_syscall_wrapper(int sysnum, int arg);

#endif /* ASM_SYSCALL_H */
