// USED FOR LINKING USER CODE ONLY

#ifndef USER_SYSCALL_WRAPPER_H
#define USER_SYSCALL_WRAPPER_H

#include "user_syscall.h"

int fork();
int minclone(void);
int yield(int pid);
int deschedule(int *lock);
int make_runnable(int pid);
void *brk(void *addr);
int get_pid(void);
int print(int len,char *st);
void exit(int status);
int readline(int len, char* st);
int set_term_color(int color);
int set_cursor_pos(int row, int col);
int rand(void);
int sleep(int time);
int paint_sprite(sprite *s);
char get_single_char(void);
int exec(char* execname, char ** argvec );
int wait(int * status_ptr);

int mkfs(int max_files);
int open(char* pathname);
int close(int fd);
int create(char* pathname);
int read(int fd, void *buf, int size);
int write(int fd, void *buf, int size);
int seek(int fd, int offset);
int link(char* old, char* new);
int symlink(char* old, char* new);
int unlink(char* pathname);
int filesize(char* pathname);
int mkdir(char* pathname);
int rmdir(char* pathname);
int chdir(char* pathname);
int dirsize(char* pathname);
int direntry(char *pathname, int entrypos, char *entryname);
int sync();
int pwd(char* buffer);

#endif /* USER_SYSCALL_WRAPPER_H */
