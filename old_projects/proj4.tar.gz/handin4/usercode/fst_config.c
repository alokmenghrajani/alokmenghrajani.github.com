/**
 * 15-412 Filesystem test suite
 * Yuen-Lin Tan (tyl@cmu.edu)
 *
 * USER CONFIGURATION (customize to your liking)
 */

#include <412/fst.h>
#include "fst_user.h"

/**
 * If 1, initializes filesystem before each test.
 * If 0, uses filesystem as-is for tests.
 */
char fst_mkfsBeforeTest = 1;

/**
 * If 1, tests prompt user for run-time options, if any.
 * If 0, tests run in their default form.
 */
char fst_promptUser = 1;

/**
 * If fst_mkfsBeforeTest = 1, number of inodes to initialize 
 * filesystem for.
 */
int fst_numInodes = 1024;

/**
 * If 1, all output is lprintf()'d as well as displayed on the
 * OS console (OS console + Simics console + kernel.log).
 * If 0, all output is only displayed on the OS console.
 */
char fst_logOutput = 0;

/**
 * The sequence of course-provided tests to run. Refer to
 * <412/fst.h> for names. Must be terminated with -1.
 */

/*
  REM_REFCNTS
  LARGEFILE
  ATOMWRITE
  RWSPEED ???
*/

fst_testID fst_testSequence[FST_MAX_TESTS] = \
{
  //  FST_BASIC_OPS, FST_PROCESS_FDT, FST_INODE_LIMIT,
  //  FST_REM_REFCNTS, FST_REM_LNKCNTS,
  //  FST_CYCL_SYMLNK,  
  //  FST_BUFF_RWSPEED, FST_3CREATES, 
  //  FST_ATOM_WRITE, 
  //  FST_LONG_SEEK, FST_ZERO_DATA, 
  FST_LARGE_FILE,
 -1};       

/**
 * The sequence of user-provided tests to run. As stated in
 * the HOWTO, ID's for user-provided tests should be defined in
 * fst_user.h.
 */
int fst_usertestSequence[FST_MAX_TESTS] = \
{ -1 };

/**
 * The names of user-provided tests. Used when printing the
 * summary of test results. Fill them in the order in which
 * their ID's were defined in fst_user.h.
 */
char fst_usertestNames[FST_MAX_TESTS][50] = \
{"My first test",  /* Replace these with your own, if any. */
 "My second test"};

/**
 * Register handlers for user-provided tests. Object files
 * for handlers should be linked into the fst_driver executable.
 */
void fst_initUserTests ()
{
  int i;
  extern fst_test fst_usertests[];

  for (i = 0; i < FST_MAX_TESTS; i++)
    fst_usertests[i].result = NOTRUN;

  /* Modify this portion to suit your tests
     Example:
  fst_regUserTest(FST_USER_DEFINED_TEST1, test_function1);
  fst_regUserTest(FST_USER_DEFINED_TEST2, test_function2);
  */
}



/*************** END USER CONFIGURATION **************/
