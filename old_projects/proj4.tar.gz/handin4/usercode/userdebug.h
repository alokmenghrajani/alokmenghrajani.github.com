#ifndef __USERDEBUG_H
#define __USERDEBUG_H

#define MAGIC_BREAK asm("pushl %%ebx; movl $0x2badd00d,%%ebx; xchg %%bx,%%bx; popl %%ebx" : : )

void lprintf(char* fmt, ...);
int snprintf (char *str, int count, const char *fmt, ...);


typedef char *va_list;

#define va_dcl va_list va_alist;
#define va_start(ap) ap = (va_list)&va_alist
#define va_arg(ap,t) ((t *)(ap += sizeof(t)))[-1]
#define va_end(ap) ap = NULL

#endif
