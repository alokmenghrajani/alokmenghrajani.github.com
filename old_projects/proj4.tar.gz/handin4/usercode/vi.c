#include "syscall_wrapper.h"
#include "malloc.h"
#include "userlib.h"
// strlen and strcmp come from shell

/* Very simple vi.
   
   Start by typing vi or vi filename

   Switch from command to edit mode by typing
   i
   
   Switch from edit mode to command by typing
   esc

   In edit mode you can type characters and delete them.

   In command mode:
   :q -> quit (without asking for saving)
   :w -> writes file (save)
   :w filename -> writes file filename (save as)
   h  -> go left
   j  -> go down
   k  -> go up
   l  -> go right
*/

/* Systems defines */
#define MAXPATHNAMELEN 256
#define CONSOLE_HEIGHT 25
#define CONSOLE_WIDTH 80

#define COMMAND 1
#define COMMAND2 2
#define EDIT  3

/* ASCII codes */
#define ESC 27
#define BS 8
#define COLON 58 // actually " on the keyboard
#define DEL 63

#define NULL 0

typedef struct hippo_line_ {
  char *data;
  int size;
  int maxsize;
  struct hippo_line_ *prev;
  struct hippo_line_ *next;
} line_t;


int mode;
char filename[MAXPATHNAMELEN]="";
int file_fd;

line_t *top_margin; // at screen level
line_t *bottom_margin;
int nblines;

int left_margin;    // character where to start writting
line_t *current_line;
int cursor_x;         // index in current line
int cursor_y;

char cmdbuf[CONSOLE_WIDTH-1]="";

void display_cmd();
void display();
void display_line(line_t *l);
line_t* get_new_line();
void insert_text(line_t *l, int pos, char c);
int loadfile();
void savefile();
void cleanup();

int main(int argc, char** argv) {
  int t;
  char key;
  nblines = 0;

  mm_init(); /* init malloc package */
  
  mode = COMMAND;  

  /* If argc is 2, open the file and display it's content */
  t = -1;
  if (argc==2) {
    strncpy(filename, argv[1], MAXPATHNAMELEN);
    t=loadfile();
  } else {
    strncpy(cmdbuf, "Welcome to VI", CONSOLE_WIDTH-1);
    display();
    strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
  }
  if (t==-1) {
    line_t *t = get_new_line();
    top_margin = t;
    bottom_margin = t;
  }
  current_line = top_margin;
  left_margin = 0;
  cursor_x = 0;
  cursor_y = 0;
  
  while(1) {
    key = get_single_char();
    
    if (mode==COMMAND) {
      if (key=='l') { // move right
	if (cursor_x>=current_line->size) {
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	} else {
	  cursor_x++;
	  // Scroll right ?
	  if (cursor_x-left_margin==CONSOLE_WIDTH) {
	    left_margin++;
	    display();
	  } else {
	    display_cmd();
	    test_error(set_cursor_pos(cursor_y, cursor_x-left_margin), __LINE__);
	  }
	}
      } else if (key=='h') { // move left
	if (cursor_x == 0) {
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	} else {
	  cursor_x--;
	  if (cursor_x-left_margin<0) {
	    left_margin--;
	    display();
	  } else {
	    display_cmd();
	    test_error(set_cursor_pos(cursor_y, cursor_x-left_margin), __LINE__);
	  }
	}
      } else if (key=='k') {
	if (current_line->prev==NULL) {
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	} else {
	  // scroll up ?
	  int scroll = 0;
	  cursor_y--;
	  if (current_line==top_margin) {
	    top_margin = top_margin->prev;
	    bottom_margin = bottom_margin->prev;
	    scroll = 1;
	  }
	  current_line = current_line->prev;
	  if (cursor_x>current_line->size)
	    cursor_x = current_line->size;
	  
	  if (scroll==1)
	    display();
	  else {
	    display_cmd();
	    test_error(set_cursor_pos(cursor_y, cursor_x-left_margin), __LINE__);
	  }
	}
      } else if (key=='j') {
	int scroll = 0;
	cursor_y++;
	if (current_line->next != NULL) { // move down
	  // scroll down ?
	  if (current_line==bottom_margin) {
	    top_margin = top_margin->next;
	    bottom_margin = bottom_margin->next;
	    scroll = 1;
	  }
	  current_line = current_line->next;
	} else {
	  // Create a new line
	  line_t *t = get_new_line();
	  current_line->next = t;
	  t->prev = current_line;
	  current_line = t;
	  bottom_margin = current_line;
	  // scroll down ?
	  if (nblines>(CONSOLE_HEIGHT-1)) {
	    top_margin = top_margin->next;
	  }
	  scroll = 1;
	}
	if (cursor_x>current_line->size)
	  cursor_x = current_line->size;
	if (scroll==1)
	  display();
	else {
	  display_cmd();
	  test_error(set_cursor_pos(cursor_y, cursor_x-left_margin), __LINE__);
	}
      } else if (key=='i') {
	mode = EDIT;
	strncpy(cmdbuf, "--EDIT--", CONSOLE_WIDTH-1);
	display_cmd();
      } else if (key==COLON) {
	strcat(cmdbuf, ":");
	mode = COMMAND2;
	display_cmd();
      } else {
	display_cmd();
      }
    } else if (mode==COMMAND2) {
      char str[2]={0, 0};      
      if (key=='\n') {
	char hack=cmdbuf[5]; // so i don't need to write strncmp
	cmdbuf[5] = 0;
	if (strcmp(cmdbuf, "VI :q")==0) {
	  cleanup();
	  test_error(set_cursor_pos(CONSOLE_HEIGHT-1, 0), __LINE__);
	  print_str("\n\nThank you for using VI.\n");
	  exit(0);
	} else if (strcmp(cmdbuf, "VI :w")==0) {
	  // parse cmdbuf to get the optional filename
	  int i, st=0;
	  cmdbuf[5] = hack;
	  if (cmdbuf[5]!=0) {
	    // eat spaces
	    for (i=5; cmdbuf[i]==' '; i++);
	    st = i;
	    // check for no more spaces
	    for (; cmdbuf[i]!=0; i++) {
	      if (cmdbuf[i]==' ') {
		mode = COMMAND;
		strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
		display_cmd();
		strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
		continue;
	      }
	    }
	    strncpy(filename, &cmdbuf[st], MAXPATHNAMELEN);
	  }
	  mode = COMMAND;
	  savefile();
	} else {
	  mode = COMMAND;
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();	  
	  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	}
      } else if (key==BS) {
	int t = strlen(cmdbuf);
	if (t>3) {
	  cmdbuf[t-1]=0;
	  display_cmd();
	}
      } else if (key==ESC) {
	mode = COMMAND;
	strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	display_cmd();
      } else if (key!='\r') {
	if (strlen(cmdbuf)<20) {
	  str[0]=key;
	  strcat(cmdbuf, str);
	  display_cmd();
	} else {
	  mode = COMMAND;
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	}
      }
    } else if (mode==EDIT) {
      if (key==ESC) {
	mode = COMMAND;
	strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
	display_cmd();
      } else if (key==BS) {
	if (cursor_x>0) { // erase one character
	  int i;
	  for (i=cursor_x; i<current_line->size; i++)
	    current_line->data[i-1]=current_line->data[i];
	  current_line->size--;
	  cursor_x--;
	  display_cmd();
	  test_error(set_cursor_pos(cursor_y, 0), __LINE__);
	  display_line(current_line);
	  test_error(set_cursor_pos(cursor_y, cursor_x), __LINE__);	  
	} else if (current_line->prev != NULL) {
	  // move line up
	  line_t *u, *t = current_line->prev;
	  int i;
	  cursor_x = t->size;
	  if (cursor_x-left_margin>=CONSOLE_WIDTH) {
	    left_margin = cursor_x - CONSOLE_WIDTH + 1;
	  }
	  for (i=0; i<current_line->size; i++)
	    insert_text(t, t->size, current_line->data[i]);
	  t->next = current_line->next;
	  if (current_line->next != NULL)
	    current_line->next->prev = t;
	  u=current_line;
	  current_line = t;
	  mm_free(u->data);
	  mm_free(u);
	  display();
	} else {
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "--EDIT--", CONSOLE_WIDTH-1);
	}
      } else if (key==DEL) {
	if (cursor_x<current_line->size) { // delete one character
	  int i;
	  for (i=cursor_x; i<current_line->size-1; i++) {
	    current_line->data[i]=current_line->data[i+1];
	  }
	  current_line->size--;
	  display_cmd();
	  test_error(set_cursor_pos(cursor_y, 0), __LINE__);
	  display_line(current_line);
	  test_error(set_cursor_pos(cursor_y, cursor_x), __LINE__);
	} else if (current_line->next!=NULL) {
	  int i;
	  line_t *t = current_line->next;
	  for (i=0; i<t->size; i++) {
	    insert_text(current_line, current_line->size, t->data[i]);
	  }
	  current_line->next = t->next;
	  if (t->next!=NULL)
	    t->next->prev = current_line;
	  mm_free(t->data);
	  mm_free(t);
	  display();
	} else {
	  strncpy(cmdbuf, "Err", CONSOLE_WIDTH-1);
	  display_cmd();
	  strncpy(cmdbuf, "--EDIT--", CONSOLE_WIDTH-1);	  
	}
      } else if (key=='\n') {
	int i;
	// Create a new line
	line_t *t = get_new_line();
	if (current_line->next!=NULL)
	  current_line->next->prev = t;
	t->next = current_line->next;
	current_line->next = t;
	t->prev = current_line;
	// copy the data that was on the line after the cursor to the new one
	for (i=cursor_x; i<current_line->size; i++) {
	  insert_text(t, i-cursor_x, current_line->data[i]);
	}
	current_line->size = cursor_x; // account for deleted characters
	current_line = t;
	cursor_x = 0;
	left_margin = 0;
	cursor_y++;
	if (bottom_margin==current_line->prev) {
	  if (current_line->next == NULL) { // we added a line at the end
	    bottom_margin = current_line;
	  }
	  // scroll down ?
	  if (nblines>(CONSOLE_HEIGHT-1)) {
	    top_margin = top_margin->next;
	    bottom_margin = current_line;
	  }
	}
	display();
      } else if (key!='\r') {
	insert_text(current_line, cursor_x, key);
	cursor_x++;
	// Scroll right ?
	if (cursor_x-left_margin==CONSOLE_WIDTH) {
	  left_margin++;
	  display();
	} else {
	  display_cmd();
	  test_error(set_cursor_pos(cursor_y, 0), __LINE__);
	  display_line(current_line);
	  test_error(set_cursor_pos(cursor_y, cursor_x), __LINE__);
	}
      } else {
	display_cmd();
      }
    }
  }
  return 0;
}

void cleanup() {
  // get rid of all the datastructures:
  line_t *t, *n;
  for (t=top_margin; t!=NULL; t=t->prev);
  n = t;
  while (n!=NULL) {
    t = t->next;
    mm_free(n->data);
    mm_free(n);
    n = t;
  }
}

void savefile() {
  line_t *t;
  // delete previous file
  unlink(filename);
  file_fd = create(filename);
  if (file_fd == -1) {
    strncpy(cmdbuf, "VI - error trying to create file.", CONSOLE_WIDTH-1);      
    display_cmd();
    strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
    return;
  }
  /* find first line */
  for (t=top_margin; t->prev!=NULL; t=t->prev);
  while (t!=NULL) {
    write(file_fd, t->data, t->size);
    write(file_fd, "\n", 1);
    t=t->next;
  }
  strncpy(cmdbuf, "VI - file saved.", CONSOLE_WIDTH-1);
  display_cmd();
  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
  test_error(close(file_fd), __LINE__);
}

int loadfile() {
  int i, n;
  char buf[100];
  file_fd = open(filename);
  if (file_fd == -1) {
    file_fd = create(filename);
    if (file_fd == -1) {
      strncpy(cmdbuf, "Welcome to VI - error trying to create file.", CONSOLE_WIDTH-1);
      display();
      strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
      return -1;
    }
    test_error(close(file_fd), __LINE__);
    strncpy(cmdbuf, "Welcome to VI - file created.", CONSOLE_WIDTH-1);
    display();
    strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);
    return -1;
  } else {
    line_t *t = get_new_line();
    line_t *prev = NULL;

    top_margin = t;
    do {
      n=test_error(read(file_fd, buf, 100), __LINE__);
      for (i=0; i<n; i++) {
	if (t==NULL) {
	  ASSERT(prev!=NULL);
	  t = get_new_line();
	  t->prev = prev;
	  prev->next = t;
	}
	if (buf[i]=='\n') {
	  prev = t;
	  t=NULL;
	} else if (buf[i]!='\r') {
	  insert_text(t, t->size, buf[i]);
	}
      }
    } while(n==100);
    if (t==NULL)
      bottom_margin = prev;
    else
      bottom_margin = t;
  }
  test_error(close(file_fd), __LINE__);

  strncpy(cmdbuf, "Welcome to VI - file loaded.", CONSOLE_WIDTH-1);
  display();
  strncpy(cmdbuf, "VI ", CONSOLE_WIDTH-1);

  return 0;
}

void display_cmd() {
  int i;
  test_error(set_cursor_pos(CONSOLE_HEIGHT-1, 0), __LINE__);
  for (i=0; i<CONSOLE_WIDTH-1; i++)
    print(1, " ");
  test_error(set_cursor_pos(CONSOLE_HEIGHT-1, 0), __LINE__);
  print_str(cmdbuf);
  if (mode!=COMMAND2) {
    test_error(set_cursor_pos(cursor_y, cursor_x-left_margin), __LINE__);
  }  
}

void display() {
  line_t *t = top_margin;
  int i;
  int cy = 0;
  // Display CONSOLE_HEIGHT-1 lines
  cursor_y = 0;
  test_error(set_cursor_pos(0, 0), __LINE__);
  while ((cy<CONSOLE_HEIGHT-1) && (t!=NULL))  {
    if (current_line==t)
      cursor_y = cy;
    display_line(t);
    cy++;
    t = t->next;
  }
  // Display ~ to fill up the screen
  while (cy<CONSOLE_HEIGHT-1) {
    print(1, "~");
    for (i=0; i<CONSOLE_WIDTH-1; i++)
      print(1, " ");
    cy++;
  }
  // Display message
  display_cmd();
}

void display_line(line_t *l) {
  int n = l->size - left_margin;
  int i;
  if (n>0) {
    if (n>CONSOLE_WIDTH)
      n=CONSOLE_WIDTH;
    print(n, &l->data[left_margin]);
  }
  for (i=0; i<CONSOLE_WIDTH-n; i++)
    print(1, " ");
}

line_t* get_new_line() {
  line_t *t = (line_t *) mm_malloc(sizeof(line_t));
  t->data = (char*) mm_malloc(sizeof(char)*100);
  t->maxsize = 100;
  t->size = 0;
  t->prev = NULL;
  t->next = NULL;
  nblines++;
  return t;
}

void insert_text(line_t *l, int pos, char c) {
  int i;
  ASSERT(pos<=l->size);    
  if (l->size == l->maxsize) {
    char *newdata;
    // Extend the line
    l->maxsize += 100;
    newdata = (char*) mm_malloc(sizeof(char)*(l->maxsize));

    // copy old data
    for (i=0; i<l->size; i++)
      newdata[i] = l->data[i];
    mm_free(l->data);
    l->data = newdata;
  }
  i = l->size - pos;
  if (i>0) {
    for (i=l->size; i>=pos; i--)
      l->data[i+1]=l->data[i];
  }
  l->data[pos] = c;
  l->size++;
}
