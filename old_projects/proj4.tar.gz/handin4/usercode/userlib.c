#include "userlib.h"

void print_str(char *str) {
  test_error(print(strlen(str), str), __LINE__);
}

void print_int(int i) {
  char buf[2];
  int a;
  buf[1]=0;
  if (i<0) {
    test_error(print(1,"-"), __LINE__);
    i=-i;
  }
  a=i%10;
  i=i/10;
  buf[0]='0'+a;
  if (i>0)
    print_int(i);
  test_error(print(1,buf), __LINE__);
}

void strncpy(char* dest, char* src, int n) {
  while((n>0) && (*src!=0)) {
    *dest=*src;
    dest++;
    src++;
    n--;
  }
  if (n>0)
    *dest=0;
}

void strcat(char *dest, char*src) {
  while (*dest!=0)
    dest++;
  while (*src!=0) {
    *dest = *src;
    dest++;
    src++;
  }
  *dest = 0;
}

int test_error(int t, int line) {
  if (t==-1) {
    print(6, "error:");
    print_int(line);
    print(1, "\n");
    exit(-1);
  }
  return t;
}
