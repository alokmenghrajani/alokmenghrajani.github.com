// USED FOR LINKED TO USER CODE ONLY

/*
  C Wrapper of the system calls.
  Uses the asm_syscall
*/

#include "asm_syscall.h"
#include "user_syscall.h"
#include "userlib.h"


int fork() {
  return asm_syscall_wrapper(SYSCALL_FORK, 0);
}

// Unused wrapper !
int minclone(void) {
  return asm_syscall_wrapper(SYSCALL_MINCLONE, 0);
}

int yield(int pid) {
  return asm_syscall_wrapper(SYSCALL_YIELD, pid);
}

int deschedule(int *lock) {
  return asm_syscall_wrapper(SYSCALL_DESCHEDULE, (int) lock);
}

int make_runnable(int pid) {
  return asm_syscall_wrapper(SYSCALL_MAKE_RUNNABLE, pid);
}

void *brk(void *addr) {
  return ((void*) asm_syscall_wrapper(SYSCALL_SBRK, (int) addr));
}

int get_pid(void) {
  return asm_syscall_wrapper(SYSCALL_GETPID, 0);
}
int getpid(void) {
  return asm_syscall_wrapper(SYSCALL_GETPID, 0);
}


int print(int len, char *st) {
  pstring_t t;
  t.len = len;
  t.st = st;
  return asm_syscall_wrapper(SYSCALL_PRINT, (int) (&t));
}
void exit(int status) {
  asm_syscall_wrapper(SYSCALL_EXIT, status);
}

int readline(int len, char* st) {
  pstring_t t;
  t.len = len;
  t.st = st;
  return asm_syscall_wrapper(SYSCALL_READLINE, (int) (&t));
}

int set_term_color(int color) {
  return asm_syscall_wrapper(SYSCALL_SET_TERM_COLOR, color);
}

int set_cursor_pos(int row, int col) {
  cpos p;
  p.row = row;
  p.col = col;
  return asm_syscall_wrapper(SYSCALL_SET_CURSOR_POS, (int) &p);
}

int rand(void) {
  return asm_syscall_wrapper(SYSCALL_RAND, 0);
}

int sleep(int time) {
  return asm_syscall_wrapper(SYSCALL_SLEEP, time);
}

int paint_sprite(sprite *s) {
  return asm_syscall_wrapper(SYSCALL_PAINT_SPRITE, (int) s);
}


char get_single_char(void) {
  return ((char) asm_syscall_wrapper(SYSCALL_GET_SINGLE_CHAR, 0));
}

char getchar(void) {
  return ((char) asm_syscall_wrapper(SYSCALL_GET_SINGLE_CHAR, 0));
}

int exec(char* execname, char ** argvec ){
  exec_t t;
  t.execname = execname;
  t.argvec = argvec;
  return asm_syscall_wrapper(SYSCALL_EXEC, (int) (&t));
}


int wait(int * status_ptr){
  return asm_syscall_wrapper(SYSCALL_WAIT, (int) status_ptr);
}


int mkfs(int max_files){
  return asm_syscall_wrapper(SYSCALL_FS_MKFS,max_files);
}

int open(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_OPEN, (int)pathname);
}

int close(int fd){
  return asm_syscall_wrapper(SYSCALL_FS_CLOSE, fd);
}

int create(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_CREATE,(int)pathname);
}

int read(int fd, void *buf, int size){
  io_t stuff = {fd, buf, size};
  return asm_syscall_wrapper(SYSCALL_FS_READ, (int)&stuff);
  
}

int write(int fd, void *buf, int size){
  io_t stuff = {fd, buf, size};
  return asm_syscall_wrapper(SYSCALL_FS_WRITE, (int) &stuff);
}

int seek(int fd, int offset){
  seeker_t s = {fd,offset};
  return asm_syscall_wrapper(SYSCALL_FS_SEEK, (int)&s);
}

int link(char* old, char* new){
  filename_t t = {old,new};
  return asm_syscall_wrapper(SYSCALL_FS_LINK,(int) &t);
}

int symlink(char* old, char* new){
  filename_t t = {old,new};
  return asm_syscall_wrapper(SYSCALL_FS_SYMLINK, (int)&t);
}

int unlink(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_UNLINK,(int) pathname);
}

int filesize(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_FILESIZE, (int)pathname);
}

int mkdir(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_MKDIR, (int)pathname);
}

int rmdir(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_RMDIR, (int)pathname);
}


int chdir(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_CHDIR,(int) pathname);
}

int dirsize(char* pathname){
  return asm_syscall_wrapper(SYSCALL_FS_DIRSIZE, (int)pathname);
}

int direntry(char *pathname, int entrypos, char *entryname){
  direntry_t d = {pathname, entrypos, entryname};
  return asm_syscall_wrapper(SYSCALL_FS_DIRENTRY,(int)&d);
}

int sync(){
  return asm_syscall_wrapper(SYSCALL_FS_SYNC,0);
}


int pwd(char * buffer){
  return asm_syscall_wrapper(SYSCALL_FS_PWD,buffer);
}
