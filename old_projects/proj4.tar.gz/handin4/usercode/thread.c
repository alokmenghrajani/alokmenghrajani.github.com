#include "../threadlib/olduserdebug.h"
#include "../threadlib/oldsyscall_wrapper.h"
#include "syscall_wrapper.h"
#include "../threadlib/asm_spinlock.h"
#include "../threadlib/thr.h"
#include "../threadlib/util.h"
#include "../threadlib/mutex.h"
#include "../threadlib/safe_malloc.h"

static int titilock = 1;

static mutex_t* tatamutex;

void* toto(void *);


int main() {
  int i =0 , pid, ret;
  titilock = 1;

  thread_safe_mminit();    
  thr_init(1024);

  lprintf("in main");
  tatamutex = (mutex_t *) thread_safe_malloc(sizeof(mutex_t));
  
  if(tatamutex == NULL)
    lprintf("shit my eye!");
  mutex_init(tatamutex);
  print_int(tatamutex->lock);
  lprintf("Trying init.");


 
  //get_spinlock(&titilock);
  mutex_lock(tatamutex);

  /*  for(i = 0; i< 5; i++) {
    pid = thr_create((void*) toto, (void*)i);
    sys_yield(pid);
    lprintf("thr_create returned: %d\n", pid);
    }*/

  pid = thr_create((void*) toto, NULL);

  mutex_unlock(tatamutex);
  /*
  for (i = 0; i<5; i++) {
    thr_join(i+2, &pid,&ret);
    lprintf("Root thread detected end of %d : returned with %d ", pid,ret);
    }*/
  
  thr_join(0,&pid, &ret);
  lprintf("Root thread detected end of %d : returned with %d ", pid,ret);
  
  //  pid = thr_create((void*) toto, (void*)3);
  
  sys_sleep(1000);
  lprintf("wake!");
  //  thr_join(0,&pid, &ret); 
  lprintf("Root thread detected end of %d : returned with %d ", pid,ret);
  lprintf("Root thread finished !!!!");
  while(1);
}

void* toto(void* b) {
  int a = (int) b;
  int pid = sys_get_pid();
  int i;
  if(a%2){
    mutex_lock(tatamutex);
    mutex_unlock(tatamutex);
  }
  for (i=0; i<2; i++) {
    lprintf("assssss! %d : %d", pid, (int) a);
    sys_yield(0);
  }
  return b;
}
