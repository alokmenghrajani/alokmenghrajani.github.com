/**************************************************************
 * 15-412 User Debugging
 * Yuen-Lin Tan (tyl@cmu.edu)
 *
 * Provides: lprintf(), snprintf()
 *
 * Portions by Patrick Powell.
 *
 * NOTE: Does not do floating point (%f, etc).
 *
 **************************************************************/

#include "userdebug.h"

#define NULL 0

#define VA_LOCAL_DECL va_list ap;
#define VA_START(f) va_start(ap) /* f is ignored! */
#define VA_SHIFT(v,t) v = va_arg(ap,t)
#define VA_END va_end(ap)

static const char cntrl[] = "\
\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\
\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f ";

static int vplp_snprintf(char *str, int count, const char *fmt, va_list args, char **pf_end, char **pf_output);
static void dopr(char *buffer, const char *format, va_list args, char **pf_end, char **pf_output);

static void fmtstr( char *value, int ljust, int len, int zpad, char **pf_end, char **pf_output);
static void fmtnum( long value, int base, int dosign,
                    int ljust, int len, int zpad, char **pf_end, char **pf_output );
static void dostr( char *, char **, char ** );
static void dopr_outch(int c, char **pf_end, char **pf_output);
static int uplStrlen(char* s);


/**
 * 15-412 PrintLogging
 * Use as printf() -- lprintf_user(char *format, ...)
 */
//void lprintf (va_list va_alist)
void lprintf(char* fmt, ...)
{
  char str[256];
  char *pf_end, *pf_output;
  va_list ap;

  ap = (va_list)&fmt;
  ap += 4;
  //  fmt = va_arg(ap, char *);
  vplp_snprintf (str, 256, fmt, ap, &pf_end, &pf_output);
  va_end(ap);

  asm("pushl %%eax" : :);
  asm("pushl %%ebx" : :);

  asm("movl %0, %%eax" : : "m"(str) : "%eax"); // store address of charbuf in %eax
  asm("movl $0x1badd00d, %%ebx" : : : "%ebx"); // set lprintf_user flag
  asm("xchg %%bx,%%bx" : : );                  // call magic instruction

  asm("popl %%ebx" : :);
  asm("popl %%eax" : :);

}

int snprintf (char *str, int count, const char *fmt, ...)
{
  char *pf_end, *pf_output;  
  va_list ap;
    
  ap = (va_list) &str;

  //VA_SHIFT (str, char *);
  //VA_SHIFT (count, int);
  //VA_SHIFT (fmt, char *);

  ap += 12;

  vplp_snprintf (str, count, fmt, ap, &pf_end, &pf_output);

  va_end(ap);

  return uplStrlen(str);
}

/* Returns the length of the string, not including the
   null character. */
static int uplStrlen(char* s) {
  int len = 0;
  while(*(s++)) len++;
  return len;
}

static int iscntrl(int c) {
  int size;
  for (size=0;size<30;size++)
    if (cntrl[size] == c) return 1;
  return 0;
}

static int vplp_snprintf(char *str, int count, const char *fmt, va_list args, char **pf_end, char **pf_output)
{
  str[0] = 0;
  *pf_end = str+count-1;
  dopr(str, fmt, args, pf_end, pf_output);
  if( count>0 ){
    (*pf_end)[0] = 0;
  }
  return(uplStrlen(str));
}

/*
 * dopr(): poor man's version of doprintf
 */
static void dopr(char *buffer, const char *format, va_list args, char **pf_end, char **pf_output)
{
  int ch;
  long value;
  int longflag = 0;
  char *strvalue;
  int ljust;
  int len;
  int zpad;

  *pf_output = buffer;
  while( (ch = *format++) ){

    switch( ch ){

    case '%':
      ljust = len = zpad = 0;
    nextch:
      ch = *format++;
      switch( ch ){
      case 0:
        dostr( "**end of format**", pf_end, pf_output );
        return;
      case '-': ljust = 1; goto nextch;
      case '0': /* set zero padding if len not set */
        if(len==0) zpad = '0';
      case '1': case '2': case '3':
      case '4': case '5': case '6':
      case '7': case '8': case '9':
        len = len*10 + ch - '0';
        goto nextch;
      case 'l': longflag = 1; goto nextch;
      case 'u': case 'U':
        /*fmtnum(value,base,dosign,ljust,len,zpad) */
        if( longflag ){
          value = va_arg( args, long );
        } else {
          value = va_arg( args, int );
        }
        fmtnum( value, 10,0, ljust, len, zpad, pf_end, pf_output ); break;
      case 'o': case 'O':
        /*fmtnum(value,base,dosign,ljust,len,zpad) */
        if( longflag ){
          value = va_arg( args, long );
        } else {
          value = va_arg( args, int );
        }
        fmtnum( value, 8,0, ljust, len, zpad, pf_end, pf_output ); break;
      case 'd': case 'D':
        if( longflag ){
          value = va_arg( args, long );
        } else {
          value = va_arg( args, int );
        }
        fmtnum( value, 10,1, ljust, len, zpad, pf_end, pf_output ); break;
      case 'x':
        if( longflag ){
          value = va_arg( args, long );
        } else {
          value = va_arg( args, int );
        }
        fmtnum( value, 16,0, ljust, len, zpad, pf_end, pf_output ); break;
      case 'X':
        if( longflag ){
          value = va_arg( args, long );
        } else {
          value = va_arg( args, int );
        }
        fmtnum( value,-16,0, ljust, len, zpad, pf_end, pf_output ); break;
      case 's':
        strvalue = va_arg( args, char *);
        fmtstr( strvalue,ljust,len,zpad,pf_end,pf_output ); break;
      case 'c':
        ch = va_arg( args, int );
        dopr_outch(ch, pf_end, pf_output); break;
      case '%': dopr_outch(ch, pf_end, pf_output); continue;
      default:
        dostr( "???????", pf_end, pf_output );
      }
      longflag = 0;
      break;
    default:
      dopr_outch(ch, pf_end, pf_output);
      break;
    }
  }
  *(*pf_output) = 0;
}

static void fmtstr(char *value, int ljust, int len, int zpad, char **pf_end, char **pf_output)
{
  int padlen, strlen; /* amount to pad */

  if( value == 0 ){
    value = "<NULL>";
  }
  for( strlen = 0; value[strlen]; ++ strlen ); /* strlen */
  padlen = len - strlen;
  if( padlen < 0 ) padlen = 0;
  if( ljust ) padlen = -padlen;
  while( padlen > 0 ) {
    dopr_outch(' ', pf_end, pf_output);
    --padlen;
  }
  dostr( value, pf_end, pf_output );
  while( padlen < 0 ) {
    dopr_outch(' ', pf_end, pf_output);
    ++padlen;
  }
}

static void fmtnum(long value, int base, int dosign, int  ljust, 
		   int len, int zpad, char **pf_end, char **pf_output)
{
  int signvalue = 0;
  unsigned long uvalue;
  char convert[20];
  int place = 0;
  int padlen = 0; /* amount to pad */
  int caps = 0;

  /* DEBUGP(("value 0x%x, base %d, dosign %d, ljust %d, len %d, zpad %d\n",
     value, base, dosign, ljust, len, zpad )); */
  uvalue = value;
  if( dosign ){
    if( value < 0 ) {
      signvalue = '-';
      uvalue = -value;
    }
  }
  if( base < 0 ){
    caps = 1;
    base = -base;
  }
  do{
    convert[place++] =
      (caps? "0123456789ABCDEF":"0123456789abcdef")
      [uvalue % (unsigned)base ];
    uvalue = (uvalue / (unsigned)base );
  }while(uvalue);
  convert[place] = 0;
  padlen = len - place;
  if( padlen < 0 ) padlen = 0;
  if( ljust ) padlen = -padlen;
  /* DEBUGP(( "str '%s', place %d, sign %c, padlen %d\n",
     convert,place,signvalue,padlen)); */
  if( zpad && padlen > 0 ){
    if( signvalue ){
      dopr_outch(signvalue, pf_end, pf_output);
      --padlen;
      signvalue = 0;
    }
    while( padlen > 0 ){
      dopr_outch(zpad, pf_end, pf_output);
      --padlen;
    }
  }
  while( padlen > 0 ) {
    dopr_outch(' ', pf_end, pf_output );
    --padlen;
  }
  if( signvalue ) dopr_outch(signvalue, pf_end, pf_output);
  while( place > 0 ) dopr_outch(convert[--place], pf_end, pf_output);
  while( padlen < 0 ){
    dopr_outch(' ', pf_end, pf_output );
    ++padlen;
  }
}

static void dostr(char *str, char **pf_end, char **pf_output)
{
  while(*str) dopr_outch(*str++, pf_end, pf_output);
}

static void dopr_outch(int c, char **pf_end, char **pf_output )
{
  if( iscntrl(c) && c != '\n' && c != '\t' ){
    c = '@' + (c & 0x1F);
    if(*pf_end == 0 || *pf_output < *pf_end ){
      *((*pf_output)++) = '^';
    }
  }
  if(*pf_end == 0 || *pf_output < *pf_end ){
    *((*pf_output)++) = c;
  }
}
