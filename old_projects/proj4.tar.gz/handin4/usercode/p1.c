#include "syscall_wrapper.h"
#include "userlib.h"

#define MAXFILENAMESIZE 32
#define MAXPATHNAMELEN 100

char treebuf[MAXFILENAMESIZE];
void tree(char *pathname, int ident) {
  char treebuf2[MAXPATHNAMELEN];
  int s=dirsize(pathname);
  int i, t;
  if (ident==0) {
    print(strlen(pathname), pathname);
    print(1, "\n");
    ident++;
  }
  for (i=0; i<s; i++) {
    t=direntry(pathname, i, treebuf);
    if (strcmp(treebuf, ".")==0)
      continue;
    if (strcmp(treebuf, "..")==0)
      continue;
    for (t=0; t<ident; t++) {
      print(1, " ");
    }
    print(strlen(treebuf), treebuf);
    print(1, "\n");
    strncpy(treebuf2, pathname, MAXPATHNAMELEN);
    strcat(treebuf2, "/");
    strcat(treebuf2, treebuf);
    tree(treebuf2, ident+1);
  }
}

int a = 0;
int b = 1;

int fail() {
  return b/a;
}

int main(int argc, char** argv) {
  fail();
  print_str("never\n");
  exit(-3);
}

