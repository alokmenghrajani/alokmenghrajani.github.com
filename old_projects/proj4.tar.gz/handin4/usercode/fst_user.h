/**
 * 15-412 Filesystem test suite
 * Yuen-Lin Tan (tyl@cmu.edu)
 *
 * User-defined tests
 */

#ifndef __FST_USER_H__
#define __FST_USER_H__

/**
 * Define ID's for your tests here.
 */
typedef enum
{
  FST_USER_DEFINED_TEST1,  /* Replace these with your own. */
  FST_USER_DEFINED_TEST2
} fst_usertestID;


/**
 * List your test handlers here. They should be of type
 * 'int function (void)'.
 */

/* Example:
int test_function1 ();
int test_function2 ();
*/

#endif
