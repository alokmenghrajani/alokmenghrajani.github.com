#ifndef PAGE__H
#define PAGE__H

#include "kernel.h"

/* when a page fault occurs:
   - if it's in the kernel code, then something really bad has happened !!!
   - if it's a user code and near user's sp, allocate a new page. else kill the process ?
*/

#define PAGE_SIZE 4096
#define PAGE_TABLE_SIZE 1024

extern int page_fault_handler_wrapper();
void page_fault_handler(mem_t, mem_t);



ptd_struct* page_init();

/* allocates a new page
   and register's it in the ptd.
   ptd should not be null !
   returns ptr if ok
   returns 0 ??? if error (prob out of memory)
*/
int page_get_new(ptd_struct* ptd, mem_t);

// Create a new page table directory, with the 
ptd_struct* page_new_ptd();

void page_ptd_purge(ptd_struct* ptd);


/*void page_get_new_registered(void* pcb, read_write?, user_super?, start_addr);

  assumes pdt is set
  if entry in pdt is inactif (means we need a new pt), then allocate a new pt, add it to pdt and set it to actif.
  assume that pt entry is inactif (else means we have an error in kernel code !)
  allocate a new page. If fails, free the pt if one was allocated for this purpose !!!!!!!!
  add it to pt
  increment in pcb
  set modes, etc...

*/

/* checks if the address addr is valid for user access in ptd*/
int valid_user_mem(ptd_struct* ptd, mem_t addr);


#endif /* PAGE__H */
