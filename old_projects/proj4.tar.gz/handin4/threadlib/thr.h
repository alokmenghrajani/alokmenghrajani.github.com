#ifndef THR__H
#define THR__H

#define RUNNING 0
#define ZOMBIE 1


typedef struct _waiting_hippo_queue_node {
  struct  _waiting_hippo_queue_node *next;
  void* threadt;
} queue_node;

typedef struct _thread {
  struct _thread *next;      // Linked list of threads. The first one is referenced by threads_list.
  int tid;		     // Thread ID, same as process ID.
  void *stack;		     // Pointer to the thread's stack.
			     // This is actually a pointer to the bottom of the stack, since it's the
			     // pointer returned by malloc before we add the size of the stack to it (because
			     // stacks grow downwards)
  int joinerlock;	     // A spinlock to avoid two people from joining on a given thread at the same time.
  queue_node * joiners;      // List of threads to wake up on exit
  void* exit_status;         // This is where the exit status is saved when the thread exits.
  int state;                 // The state of the thread, either running or zombie (exited, ready to be reaped)
  int runlock;		     // lock to avoid going to sleep right after a call to wake up.
  int exitlock;		     // exitlock is a spinlock to avoid a thread from being reaped before it has done with
			     // exiting.
} thread_t;

int thr_init(unsigned int size);
int thr_create(void *(*func)(void *), void *args);
int thr_join(int tid, int *departed, void **status);
void thr_exit(void *status);
thread_t* thr_new();
thread_t* find_thread_t(int tid);
int thr_getid();


#endif /* THR__H */
