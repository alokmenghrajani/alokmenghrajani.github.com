
#include "thr.h"
#include "maze.h"
#include "draw.h"
#include "common.h"
#include "queue.h"
#include "util.h"



//sleeping threads
queue* sleepers;
int sleeperlock;

//the board!
cell_t board[BOARD_WIDTH][BOARD_HEIGHT];

//list of monsters!
monster_t * monsters;
int monsterslock;

//monster_ids
monid_t next_monid;


monster_t * find_monster(monid_t mon);
int compute_move(direction_t dir, monster_t * themonster, int* destx, int* desty);
int find_deadlock(monid_t mon, cell_t * cell);



//functions for removing adding and finding dependencies
void remove_deps(monid_t mon, cell_t * cell);
void add_deps (monster_t ** mons, int n, cell_t * cell);




int game_status;
int game_status_lock;

int maze_init(){
  int i,j;
  char* author_usernames[2] = {"vikramm", "amenghra"};
  char* author_realnames[2] = {"Vikram Manjunath", "Alok Menghrajani"};

  
  sleepers = new_queue();
  monsters  = NULL;
  next_monid = 0;
  for(i = 0; i < BOARD_WIDTH; i++)
    for(j = 0; j < BOARD_HEIGHT; j++){
      board[i][j].tile = EMPTY;
      board[i][j].lock  = 1;
      board[i][j].monster  = NULL;      
      board[i][j].reserve = NULL;
      board[i][j].reserve_n = 0;
      board[i][j].deps = NULL;
      cond_init(&(board[i][j].wait));
      game_draw_board_tile(i,j,board[i][j].tile);
    }
  
  sleeperlock = 1;
  monsterslock = 1;
  game_status_lock = 1;
  

  maze_authors(author_usernames, author_realnames, 2);
  return SUCCESS;
}

int maze_cleanup(){
  int i,j;
  monster_t * temp;
  // deallocate the monsters and the sleepers.

  get_spinlock(&sleeperlock);
  while(!isempty(sleepers))
    dequeue(sleepers);
  thread_safe_free(sleepers); 
  put_spinlock(&sleeperlock);

  get_spinlock(&monsterslock);
  while(monsters){
    temp = monsters;
    monsters = monsters -> next;
    board[temp->x][temp->y].monster=NULL;
    thread_safe_free(temp);
  }
  next_monid = 0;
  put_spinlock(&monsterslock);
  /* Clear all reservations */
  for (i=0; i<BOARD_WIDTH; i++)
    for (j=0; j<BOARD_HEIGHT; j++) {
      get_spinlock(&board[i][j].lock);
      if (board[i][j].reserve) {
	thread_safe_free(board[i][j].reserve);
	board[i][j].reserve = NULL;
	board[i][j].reserve_n = 0;
	cond_destroy(&(board[i][j].wait));
      }
      put_spinlock(&board[i][j].lock);
    }
  return SUCCESS;
}

tile_t maze_get_board_contents(int x, int y){
  // Return the monster if there is one here, otherwise the normal board tile
  tile_t t;
  t = board[x][y].monster ? board[x][y].monster->color: board[x][y].tile;
  return t;
}

// maze_set_board_contents()
int maze_set_board_contents(int x, int y, tile_t tile){
  get_spinlock(&(board[x][y].lock));
  board[x][y].tile = tile;

//  game_draw_board_tile(x, y, tile);
  game_draw_board_tile(x, y, maze_get_board_contents(x, y));
  put_spinlock(&(board[x][y].lock));

  return SUCCESS;
}

monid_t maze_new_monster(tile_t tile, int x, int y){
  monster_t* newmonst;

  if(board[x][y].reserve)
    return FAILURE;

  // Check to see if tile is valid:
  if (!game_can_monster_enter_cell(tile, maze_get_board_contents(x, y)))
    return -1;
  // Create new monster
  newmonst = (monster_t *)thread_safe_malloc (sizeof(monster_t));
  if(!newmonst)
    return -1;
  get_spinlock(&monsterslock);
  // Add to the monsters list
  newmonst -> next = monsters;
  monsters = newmonst;
  // Set parameters
  newmonst -> color = tile;
  newmonst -> x = x;
  newmonst -> y = y;
  newmonst -> monid = next_monid++;
  put_spinlock(&monsterslock);
  game_draw_board_tile(x,y,tile);

  get_spinlock(&(board[x][y].lock));
  board[x][y].monster = newmonst;
  put_spinlock(&(board[x][y].lock));

//  lprintf("maze_new_monster_end %d", newmonst->monid);
  return (newmonst->monid);
}

int maze_destroy_monster(monid_t mon){
  monster_t* temp, * temp2;
  int i, j;
  get_spinlock(&monsterslock);
  //remove any want edges from this monster.  

  for(i = 0 ; i < BOARD_WIDTH; i++)
    for(j = 0 ; j < BOARD_HEIGHT; j++){
      get_spinlock(&(board[i][j].lock));
      remove_deps(mon, &(board[i][j]));
      put_spinlock(&(board[i][j].lock));
    }

  //remove the monster from monsters list
  if(monsters -> monid == mon){
    temp = monsters;
    monsters = monsters->next;
    board[temp->x][temp->y].monster=NULL;
    thread_safe_free(temp);
    put_spinlock(&monsterslock);
    //    lprintf("maze_destroy_end");
    return SUCCESS;
  }

  temp = monsters;
  while(temp->next && temp ->next->monid != mon)
    temp = temp-> next;
  if(temp -> next){
    temp2 = temp->next;
    temp->next = temp->next->next;
    board[temp2->x][temp2->y].monster=NULL;
    thread_safe_free(temp2);
    put_spinlock(&monsterslock);
    //    lprintf("maze_destroy_end");
    return SUCCESS;
  }  
  put_spinlock(&monsterslock);
  //  lprintf("maze_destroy_end with failure");
  return FAILURE;
}

int maze_move_monster(monid_t mon, direction_t dir){
  monster_t * themonster = find_monster(mon); 
  int i, x, y,oldx,oldy, t;
  tile_t oldtile;

  if(!themonster)
    return FAILURE;
  oldx = themonster->x;
  oldy =  themonster->y;

  if(FAILURE == compute_move(dir,themonster,&x,&y)) {

    return FAILURE;  
  }
  get_spinlock(&(board[x][y].lock));  

  //XXX Now that you are actually going to move, you can get off the list since you don't
  // "depend" but you "have"
  remove_deps(mon,&(board[x][y]));

  
  // make sure that the cell isn't reserved for someone else.
  if (board[x][y].reserve) {
    int ok = 0;
    for(i=0; i < board[x][y].reserve_n;  i++)
      if(board[x][y].reserve[i]->monid ==mon){
	  ok = 1;
	  break;
      }
    if (!ok) {
      put_spinlock(&(board[x][y].lock));
      return FAILURE;
    }
  }
    
  
  oldtile = maze_get_board_contents(x, y);
  t = game_can_monster_enter_cell(themonster->color, oldtile);
  
  if(t) {
    themonster->x = x;
    themonster->y = y;
    
    // Clear old cell and wake up the guys waiting on it.
    get_spinlock(&(board[oldx][oldy].lock));
    board[oldx][oldy].monster = NULL;
    game_draw_board_tile(oldx,oldy, board[oldx][oldy].tile);
    cond_broadcast(&(board[oldx][oldy].wait));
    put_spinlock(&(board[oldx][oldy].lock));

    // Set new cell
    game_draw_board_tile(x,y, themonster->color);
    board[x][y].monster = themonster;
    put_spinlock(&(board[x][y].lock)); 
    // Clear the reservation list
    if (board[x][y].reserve) {
      thread_safe_free(board[x][y].reserve);
      board[x][y].reserve = NULL;
      board[x][y].reserve_n = 0;
    }
    return oldtile;
  }
  put_spinlock(&(board[x][y].lock)); 
  return FAILURE;
}



int maze_request_move(move_combo_t *ml, int n){
  /*
    if all are possible return SUCCESS
    if not, then put on a wait queue until it is possible to return SUCCESS
    as long as this won't lead to a deadlock.
    If it leads to a deadlock, it should return ERROR_LOCK.
    if illegal, return FAILURE
   */
  int i,j,k;
  monid_t mon;
  direction_t dir;
  int moveable = 0;
  int queueable = 0;
  monster_t** moving_monsters = (monster_t **)thread_safe_malloc(n*4); 
  int* destx = (int *)thread_safe_malloc(n*4); 
  int* desty = (int *)thread_safe_malloc(n*4); 

  for(i = 0; i < n; i++){
    moving_monsters[i] = find_monster(ml[i].mon);
    if(FAILURE == compute_move(ml[i].dir, moving_monsters[i], &(destx[i]),  &(desty[i]))) {
      //out of bounds
      return FAILURE;
    }
    // Check if the monster is trying to on a wall
    if(!game_can_monster_enter_cell(moving_monsters[i]->color, board[destx[i]][desty[i]].tile)) {
      return FAILURE;
    }
    // Check that no two sources are equal, no two destinations are equal and no source=no destination
    for (j = 0; j<i; j++) {
      if ((moving_monsters[i]->x == moving_monsters[j]->x) && (moving_monsters[i]->y == moving_monsters[j]->y)) {
	return FAILURE;
      }
      if ((destx[i] == destx[j]) && (desty[i] == desty[j])) {
	return FAILURE;
      }
      if ((moving_monsters[i]->x == destx[j]) && (moving_monsters[i]->y == desty[j])) {
	return FAILURE;
      }
    }

  } 
  
  // put yourself on the lists
  //get locks first
   for(i = 0 ; i < n; i++)
	get_spinlock(&(board[destx[i]][desty[i]].lock));
   for(i = 0; i< n; i++)
     add_deps(moving_monsters,n, &(board[destx[i]][desty[i]]));
   //put the locks back
   for(i = 0 ; i < n; i++)
     put_spinlock(&(board[destx[i]][desty[i]].lock));

   //Here by queueable, we mean that we can in fact make a reservation.
   // by moveable, we mean that we can actually go ahead and return SUCCESS
   // and the calling monsters can actually make that move.


  while(!moveable){
    // Keep looping until all the cells are queueable
    while(!queueable){
      for(i = 0 ; i < n; i++)
	get_spinlock(&(board[destx[i]][desty[i]].lock));
      //get the locks for all n destinations
      
      for(i = 0 ; i < n; i++){
	monster_t *t = board[destx[i]][desty[i]].monster;
	// Deadlock detection
	
	if(t != NULL){
	  for(j = 0; j < n; j++){
	    int x = moving_monsters[j]->x;
	    int y = moving_monsters[j]->y;
	    if (find_deadlock(t->monid, &board[x][y]) == FAILURE) {
	      lprintf("DEADLOCK !!!\n");
	      // XXX get off the lsit
	      for(i = 0; i< n; i++)
		remove_deps(moving_monsters[i]->monid, &(board[destx[i]][desty[i]]));
	      //put back the locks!!
	      for(i = 0 ; i < n; i++)
		put_spinlock(&(board[destx[i]][desty[i]].lock));
	      return ERROR_LOCK;
	    }
	  }
	}
	
	queueable = !board[destx[i]][desty[i]].reserve;      
	if(!queueable){
	  //unlock all
	  for(j = 0 ; j < n; j++)
	    if(j!=i)
	      put_spinlock(&(board[destx[j]][desty[j]].lock));
	  
	  // go to sleep on the current cell's condition variable
	  cond_wait_spin(&(board[destx[i]][desty[i]].wait),&(board[destx[i]][desty[i]].lock));
	  put_spinlock(&board[destx[i]][desty[i]].lock);
	  break;
	}
      }
    }
    
    // Put yourself on the reservation
    for(i = 0; i < n; i ++) {
      board[destx[i]][desty[i]].reserve_n = n;
      board[destx[i]][desty[i]].reserve = (monster_t**)thread_safe_malloc(n*4);
      for (j = 0  ; j< n ; j++)
	board[destx[i]][desty[i]].reserve[j] = moving_monsters[j];
    }
    //unlock all
    for(i = 0 ; i < n; i++)
      put_spinlock(&(board[destx[i]][desty[i]].lock));
    
    // Check to see if moveable
    for(i = 0 ; i < n; i++) {
      
      moveable =  (game_can_monster_enter_cell(moving_monsters[i]->color, maze_get_board_contents(destx[i],desty[i])));
      if(!moveable){
	
	/* Clear all reservations since you now have to go back to sleep and have to wait*/
	for (j=0; j<n; j++){
	  get_spinlock(&board[destx[j]][desty[j]].lock);
	  if (board[destx[j]][desty[j]].reserve) {
	    thread_safe_free(board[destx[j]][desty[j]].reserve);
	    board[destx[j]][desty[j]].reserve = NULL;
	    board[destx[j]][desty[j]].reserve_n = 0;
	  }
	  if(i!= j)
	    put_spinlock(&board[destx[j]][desty[j]].lock);
	}
	
	cond_wait_spin(&(board[destx[i]][desty[i]].wait),&(board[destx[i]][desty[i]].lock));
	put_spinlock(&board[destx[i]][desty[i]].lock);
	break;	// go to sleep on the current cell's condition variable
      }
    }
  }
//  lprintf("MOVING NOW");

  
  // free moving_monsters
  thread_safe_free(moving_monsters);
  thread_safe_free(destx);
  thread_safe_free(desty);

  return SUCCESS;
}

// This function computes the move from dir and the position of the monster
// The destination coordinates are put at the addresses of destx and desty.
// in the case of moves out of bounds, FAILURE is returned.
int compute_move(direction_t dir, monster_t * themonster, int* destx, int* desty){
  int x,y;
  
  x = themonster->x;
  y = themonster->y;
  switch(dir){
  case UP:
    y--;
    if(y < 0) return FAILURE;
    break;
  case DOWN:
    y++;
    if(y >= BOARD_HEIGHT) return FAILURE;
    break;
  case RIGHT:
    x++;
    if (x >= BOARD_WIDTH) return FAILURE;
    break;
  case LEFT:
    x--;
    if(x < 0 ) return FAILURE;
  }
  
  *destx = x;
  *desty = y;
  return SUCCESS;
}

void maze_set_game_status(int s){
  get_spinlock(&game_status_lock);
  game_status = s;
  put_spinlock(&game_status_lock);
}

int maze_get_game_status(void){
  return game_status;
}

void maze_abort(void){
  int i,j;
  thread_t * t;

  //wake up everyone who is sleeping.
  get_spinlock(&sleeperlock);

  while(!isempty(sleepers)){
    t =(thread_t*) dequeue(sleepers);
    t ->runlock = 1;
    sys_markrunnable(t->tid) != -1;
  }
  put_spinlock(&sleeperlock);
  /* Clear all reservations */
  for (i=0; i<BOARD_WIDTH; i++)
    for (j=0; j<BOARD_HEIGHT; j++) {
      get_spinlock(&board[i][j].lock);
      if (board[i][j].reserve) {
	thread_safe_free(board[i][j].reserve);
	board[i][j].reserve = NULL;
	board[i][j].reserve_n = 0;
	cond_destroy(&(board[i][j].wait));
      }
      put_spinlock(&board[i][j].lock);
    }
}

void maze_wait(void){
  //find your own thread_t and using that go to sleep on the 
  // queue
  thread_t * me = find_thread_t(sys_get_pid());
  get_spinlock(&sleeperlock);
  enqueue(sleepers, (void*)me);
  me->runlock = 0;
  
  put_spinlock(&sleeperlock); 
  sys_stopme(&(me->runlock));
}

int maze_consume(monid_t mon){
  monster_t *t = find_monster(mon);
  if (!t)
    return FAILURE;
  board[t->x][t->y].tile = EMPTY;
}


//returns the monster_t corrsponding to mon
monster_t * find_monster(monid_t mon){
  monster_t * temp;
  get_spinlock(&monsterslock);
  for(temp = monsters; temp && temp->monid != mon; temp = temp->next);
  put_spinlock(&monsterslock);
  return temp;
}



// This is the main routine for finding deadlocks.
//It does a DFS over the graph formed by viewing
// the monsters as nodes and the presence of a monster
// one another monster's current cell's list as an edge
//returns SUCCESS if there is no deadlock.
int find_deadlock(monid_t mon, cell_t * cell){
  int i;
  monster_t* temp;
  waitlist * t = cell->deps;
  
  while(t){
    for(i = 0; i< t->dep_n; i++){
      temp = t->dep[i];
      if(temp->monid == mon)
	return FAILURE;
      if(FAILURE==find_deadlock(mon, &(board[temp->x][temp->y])))
	return FAILURE;
    }
    t = t->next; 
  }
  return SUCCESS;
}




// removes the monster mon from the dependency (wait list) of cell
void remove_deps(monid_t mon, cell_t * cell){
  waitlist* t = cell -> deps,* t2;
  int i, found;
  // since a copy is made for you when you add, this will delete the array of monsters_ts.  
  if(!t) return; //empty list
  found = 0;
  for(i = 0; i < t->dep_n; i++)//the first one is what we want
    if(t->dep[i]->monid == mon){
      cell->deps = t->next;
      thread_safe_free(t->dep);
      thread_safe_free(t);
      return;
    }
      
  while(t->next){
    t2 = t->next;
    for(i = 0; i < t2->dep_n; i++)//the first one is what we want
      if(t2->dep[i]->monid == mon){
	t->next = t2->next;
	thread_safe_free(t2->dep);
	thread_safe_free(t2);
	return;
      }
    t =  t->next;
  }	      
}


//adds the n monsters in mons to the waitlist of cell.
void add_deps (monster_t ** mons, int n, cell_t * cell){
  waitlist * newdeps = (waitlist *)thread_safe_malloc(sizeof(waitlist));
  int i;
  newdeps -> dep = (monster_t **)thread_safe_malloc (n*4);
  for(i=0; i< n; i++)
    newdeps->dep[i] = mons[i];
  newdeps -> dep_n = n;
  newdeps -> next = cell->deps;
  cell ->deps = newdeps;
  // NOTE: when you add, you just send in the mons. A copy is made for you.
}


