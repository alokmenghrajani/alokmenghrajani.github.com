#ifndef SAFE_MALLOC__H
#define SAFE_MALLOC__H

void *thread_safe_malloc(int size);
void thread_safe_free(void *bp);
void thread_safe_mminit();

#endif /* SAFE_MALLOC__H */
