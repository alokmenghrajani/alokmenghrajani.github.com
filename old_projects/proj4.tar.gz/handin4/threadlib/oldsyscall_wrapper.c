/*
  C Wrapper of the system calls.
  Uses the asm_syscall
*/

#include "oldasm_syscall.h"
#include "olduser_syscall.h"

// Unused wrapper !
int sys_minclone(void) {
  return oldasm_syscall_wrapper(SYSCALL_MINCLONE, 0);
}

int sys_yield(int pid) {
  return oldasm_syscall_wrapper(SYSCALL_YIELD, pid);
}

int sys_stopme(int *lock) {
  return oldasm_syscall_wrapper(SYSCALL_DESCHEDULE, (int) lock);
}

int sys_markrunnable(int pid) {
  return oldasm_syscall_wrapper(SYSCALL_MAKE_RUNNABLE, pid);
}

void *sys_sbrk(void *addr) {
  return ((void*) oldasm_syscall_wrapper(SYSCALL_SBRK, (int) addr));
}

int sys_get_pid(void) {
  return oldasm_syscall_wrapper(SYSCALL_GETPID, 0);
}

int sys_print(print_t *p) {
  return oldasm_syscall_wrapper(SYSCALL_PRINT, (int) p);
}

void sys_exit(int status) {
  oldasm_syscall_wrapper(SYSCALL_EXIT, status);
}

void sys_readline(char *buf) {
  oldasm_syscall_wrapper(SYSCALL_READLINE, (int) buf);
}

int sys_set_term_color(int color) {
  return oldasm_syscall_wrapper(SYSCALL_SET_TERM_COLOR, color);
}

int sys_set_cursor_pos(oldcpos *p) {
  return oldasm_syscall_wrapper(SYSCALL_SET_CURSOR_POS, (int) p);
}

int sys_rand(void) {
  return oldasm_syscall_wrapper(SYSCALL_RAND, 0);
}

int sys_sleep(int time) {
  return oldasm_syscall_wrapper(SYSCALL_SLEEP, time);
}

int sys_paint_sprite(oldsprite *s) {
  return oldasm_syscall_wrapper(SYSCALL_PAINT_SPRITE, (int) s);
}


char sys_get_single_char(void) {
  return ((char) oldasm_syscall_wrapper(SYSCALL_GET_SINGLE_CHAR, 0));
}

