#ifndef ASM_SPINLOCK__H
#define ASM_SPINLOCK__H

extern void get_spinlock(int *lock);
extern void put_spinlock(int *lock);
extern int asm_XCHG (int * lock, int value);


#endif /* ASM_SPINLOCK__H */
