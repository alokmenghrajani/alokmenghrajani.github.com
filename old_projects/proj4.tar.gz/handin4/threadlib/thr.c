/*
   Thread library
*/

#include "thr.h"
#include "asm_sysminclone.h"
#include "asm_sysexit.h"
#include "util.h"
#include "safe_malloc.h"


static unsigned int stack_size=0;

// Linked list of all the processes
thread_t *threads_list;


//Universal list of all the processes joining on 0
queue_node* universal_joiners;


// Locks
int threads_list_lock; //= 1;
int universal_joiners_lock; //= 1;

void print_threads();
void threads_list_add(thread_t *thr);
void unsafe_threads_list_remove(thread_t *thr);
thread_t *find_thread_t(int);
thread_t *unsafe_find_thread_t(int);
queue_node* new_joiner();
void unsafe_thr_reap(thread_t *reap, int *departed, void **status);
void remove_universal_list(queue_node *thr);

int thr_init(unsigned int size) {

threads_list_lock= 1;
universal_joiners_lock= 1;

//  lprintf("thr_init_entered %d", size);
  // Check to see that thr_init has never been called
  if (stack_size!=0) {
//    lprintf("thr_init exited with -1");
    return -1;
  }
  stack_size = size;


  threads_list = thr_new();


  // make root process a thread
  threads_list->next = NULL;
  threads_list->tid = sys_get_pid();
  threads_list->stack = NULL;
  threads_list->joinerlock=1;
  threads_list->joiners = NULL;
  threads_list->exit_status = NULL;
  threads_list->state = RUNNING;
  threads_list->runlock = 1;
  threads_list->exitlock = 1;

  universal_joiners = NULL;
//  lprintf("thr_init_end");
  return 0;
}

int thr_create(void *(*func)(void *), void *args) {
  /* In order to ensure that when the child reads his tid (from the linked list)
     the parent has finished setting it, we are setting the lock before the fork.
     We are also sending the child the parent's pid, in order to do a yield.
     
     In other words, it means that after the fork, the parent will probably
     be running before the child.
  */
  int cpid;
  void *cstack;
  int * cstack_dummy;
  thread_t *thr = thr_new();
//  lprintf("thr_create_entered");
  if (thr==NULL) {
//    lprintf("thr_create exited with -1 (%s, %d)", __FILE__, __LINE__);
    return -1;
  }
//  print_threads();
  threads_list_add(thr);
  
  // create a new stack and make it point to top (higher address)
  cstack = thread_safe_malloc(stack_size);
  //lprintf("%x",cstack);

  if (cstack==NULL) {
//    lprintf("thr_create exited with -1 (%s, %d)", __FILE__, __LINE__);
    return -1;
  }
  //setup for the thread_t
  thr->stack = cstack;
  thr->joiners = NULL;
  thr->joinerlock = 1;
  thr->exit_status = NULL;
  thr->state = RUNNING;
  thr->runlock = 1;
  thr->exitlock = 1;

  // Set up the stack for the child
  cstack = (void*)(((char *)cstack) + stack_size);
  cstack_dummy = (int *)cstack ;
  cstack_dummy-=3;
  cstack_dummy[0] = (int)func;
  cstack_dummy[1] = (int) asm_default_exit;
  cstack_dummy[2] = (int)args;
  cstack = (void*) cstack_dummy;
    
  // get lock
  get_spinlock(&threads_list_lock);
  // call assembly routine for making a clone
  cpid = asm_sysminclone(cstack);

  //The children will never return here.
  if (cpid == -1) {
    // remove the thread from the list
    threads_list=threads_list->next;
    // unlock
    put_spinlock(&threads_list_lock);
//    lprintf("thr_create_ended with -1", cpid);
    return -1;
  }
  
  // we are in the parent process (cos child has been sent to func)
  thr->tid = cpid;
  // unlock
  put_spinlock(&threads_list_lock);
//  lprintf("thr_create_ended (cpid=%d)", cpid);
  return cpid;
}

void unsafe_thr_reap(thread_t *reap, int *departed, void **status) {
  queue_node *c, *n;
//  lprintf("thr_reap entered");
  // Wait for thread to finish
  get_spinlock(&(reap->exitlock));
  put_spinlock(&(reap->exitlock));
  // Set parameters if need be
  if(departed != NULL)
    *departed = reap->tid;
  if(status != NULL)
    *status = reap->exit_status;  
  // Free the joiners list
  for (c=reap->joiners; c!=NULL; c=n) {
    n = c->next;
    thread_safe_free(c);
  }
  reap->joiners = NULL;
  
  // Remove from list
  unsafe_threads_list_remove(reap);
  // Free the stack
  thread_safe_free(reap->stack);
  // Free the thread_t ** ADDED BY ALOK after change of API **

  thread_safe_free(reap);
//  lprintf("thr_reap exited");
}


int thr_join(int tid, int *departed, void **status) {
  queue_node *  me = new_joiner();
  thread_t * mythread, * reapyou;

  if(me == NULL) {
    return -1;
  }


  mythread = find_thread_t(sys_get_pid());
  ASSERT(mythread != NULL);
  
  me-> threadt = (void *) mythread;
  
  if (tid) {
    // Join on one thread
    //get the thread that I want to join on and add myself to its joinerlist
    reapyou = find_thread_t(tid);
    if(reapyou == NULL) {
      return -1;
    }
       
    // If it's already a zombie, reap it
    if(reapyou->state ==  ZOMBIE){
      get_spinlock(&(threads_list_lock));
      unsafe_thr_reap(reapyou, departed, status);
      put_spinlock(&(threads_list_lock));
      put_spinlock(&(reapyou->exitlock));
//      lprintf("thr_join(%d,%d,%d) success",tid,departed,status);
      return 0;
    }
    
    get_spinlock(&(reapyou->exitlock));
    me-> next = reapyou->joiners;
    reapyou->joiners = me;
    mythread->runlock = 0;  
    put_spinlock(&(reapyou->exitlock));

    sys_stopme(&(mythread->runlock));

    // Now you have woken me up:)
    get_spinlock(&threads_list_lock);
    reapyou = unsafe_find_thread_t(tid);
    if (reapyou == NULL) {
      put_spinlock(&threads_list_lock);
//      lprintf("thr_join exited with -1 (%s, %d)", __FILE__, __LINE__);
      return -1;
    }
    ASSERT(reapyou->state == ZOMBIE);
    unsafe_thr_reap(reapyou, departed, status);
    put_spinlock(&threads_list_lock);
//    lprintf("thr_join(%d,%d,%d) success",tid,departed,status);
    return 0;

  } else {
    // Universal join
    //add myself to the front of the list of universal list
    get_spinlock(&universal_joiners_lock);
    me-> next = universal_joiners;
    universal_joiners = me;
    put_spinlock(&universal_joiners_lock);
   
    while(1){
      // Search for any zombie
      get_spinlock(&universal_joiners_lock);
      get_spinlock(&threads_list_lock);
      for(reapyou = threads_list; reapyou != NULL && reapyou->state != ZOMBIE; reapyou = reapyou->next);
      if (reapyou != NULL) {
	ASSERT(reapyou->state == ZOMBIE);
//	lprintf("I'm gonna reap %d", reapyou->tid);
	unsafe_thr_reap(reapyou, departed, status);
	put_spinlock(&threads_list_lock);

	remove_universal_list(me);
	put_spinlock(&universal_joiners_lock);
//	lprintf("thr_join(%d,%d,%d) success",tid,departed,status);
	return 0;
      }
      // No zombies found this time, go (back) to sleep
      put_spinlock(&threads_list_lock);

      mythread->runlock = 0;
      put_spinlock(&universal_joiners_lock);

      sys_stopme(&(mythread->runlock));
      // Now you have woken me up :)
    }

  }
  
}


void thr_exit(void *status) {
  thread_t * mythread, *current;
  queue_node* joiners;
//  lprintf("%d - thr_exit", sys_get_pid());
//  print_threads();
  mythread = find_thread_t(sys_get_pid());
  ASSERT(mythread != NULL);

  mythread-> exit_status = status;

  //lock myself so that I am not reaped before I finish
  get_spinlock(&(mythread->exitlock));
  mythread-> state = ZOMBIE;
  joiners = mythread -> joiners;

  // Wake up my joiners
  while(joiners){
    current = (thread_t *)(joiners -> threadt);
    current->runlock = 1;
    sys_markrunnable (current-> tid);
    joiners=joiners->next;
  }
  // grab universal lock and wake up first one (last one actually)
  get_spinlock(&universal_joiners_lock);
  joiners = universal_joiners;

  if(joiners != NULL){
    current = (thread_t *)(joiners -> threadt);
    current->runlock = 1;
    sys_markrunnable(current->tid);
  }
//  lprintf("Asta la vista %d", mythread->tid);

  put_spinlock(&universal_joiners_lock);
  asm_unlock_sysexit(&(mythread->exitlock));
}


thread_t* find_thread_t(int tid) {
  thread_t* t;
  get_spinlock(&threads_list_lock);  
  for(t = threads_list; t != NULL && t->tid != tid ; t = t->next);
  put_spinlock(&threads_list_lock);  
  return t;
}


thread_t* unsafe_find_thread_t(int tid) {
  thread_t* t;
  for(t = threads_list; t != NULL && t->tid != tid; t = t->next);
  return t;
}


void unsafe_threads_list_remove(thread_t *thr) {
  thread_t *t;
  ASSERT(thr!=NULL);
  ASSERT(threads_list_lock==0);
  if(threads_list == thr) {
    threads_list = thr->next;
    return;
  }
  for(t = threads_list; t != NULL && t->next != thr; t = t->next);
  if(t == NULL)
    return;
  else
    t->next = thr -> next;
    
}

void threads_list_add(thread_t *thr) {
  // lock
  get_spinlock(&threads_list_lock);
  thr->next = threads_list;
  threads_list = thr;
  
  // unlock
  put_spinlock(&threads_list_lock);
}

thread_t *thr_new(){
  return ((thread_t *) (thread_safe_malloc(sizeof (thread_t))));
}

queue_node* new_joiner(){
  return ((queue_node *) (thread_safe_malloc(sizeof (queue_node))));
}

void remove_universal_list(queue_node *joiner) {
  // Assume that joiner exists in list
  queue_node *t;
  if (universal_joiners == joiner) {
    universal_joiners = joiner->next;
    thread_safe_free(joiner);
    return;
  }
  for (t=universal_joiners; t!=NULL && t->next!=joiner; t=t->next);
  ASSERT(t!=NULL);
  t->next = joiner->next;
  thread_safe_free(joiner);
  return;
}

int thr_getid() {
  return sys_get_pid();
}


void print_threads(){
  thread_t * t = threads_list;

  lprintf("PRINT_THREADS_BEGIN");

  while(t){
    lprintf("%d",t->tid);
    t = t->next;
  }

  lprintf("PRINT_THREADS_END");
}
