#ifndef OLDSYSCALL_WRAPPER_H
#define OLDSYSCALL_WRAPPER_H

#include "olduser_syscall.h"

int sys_minclone(void);
int sys_yield(int pid);
int sys_stopme(int *lock);
int sys_markrunnable(int pid);
void *sys_sbrk(void *addr);
int sys_get_pid(void);
int sys_print(print_t *p);
void sys_exit(int status);
void sys_readline(char *buf);
int sys_set_term_color(int color);
int sys_set_cursor_pos(oldcpos *p);
int sys_rand(void);
int sys_sleep(int time);
int sys_paint_sprite(oldsprite *s);
char sys_get_single_char(void);

#endif /* OLDSYSCALL_WRAPPER_H */
