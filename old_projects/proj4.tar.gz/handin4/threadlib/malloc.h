int mm_init(void); 
void *mm_malloc(int size); 
void mm_free(void *bp);

#ifndef NULL
#define NULL 0
#endif
