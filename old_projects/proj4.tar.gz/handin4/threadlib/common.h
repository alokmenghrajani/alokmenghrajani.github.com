#ifndef COMMON_H
#define COMMON_H

/* defines */
#define EMPTY 0
#define WALL 1
#define PINK_MONSTER 2
#define GREEN_MONSTER 3
#define BLUE_MONSTER 4
#define PLAYER 5
#define CHERRY 6
#define GOLD 7
#define PLATFORM 11

#define SQUARE_WIDTH 4
#define SQUARE_HEIGHT 2
#define BOARD_WIDTH 10
#define BOARD_HEIGHT 10

#define UP 0
#define RIGHT 1
#define DOWN 2
#define LEFT 3

#define BASE_SPEED 800000
#define LEVEL_SPEED 10000
#define RANDOM_SPEED 30000

#define FAILURE -1
#define SUCCESS 1
#define ERROR_LOCK -2

#define NULL 0
#define MAX_THREADS 10

int game_can_monster_enter_cell(int mon, int dst);
void maze_authors(char **author_usernames, 
                  char **author_realnames, int n);
#endif
