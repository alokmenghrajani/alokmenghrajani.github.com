#ifndef QUEUE__H
#define QUEUE__H

typedef struct _q_node {
  struct  _q_node *next;
  void* data;
} q_node;

typedef struct _queue {
  q_node* front;
  q_node* back;
} queue;

queue* new_queue();
void enqueue(queue*,void* );
void* dequeue(queue*);
void clear(queue*);
int isempty(queue*);

#endif /* QUEUE__H */
