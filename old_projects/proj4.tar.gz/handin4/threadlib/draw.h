#ifndef DRAW_H
#define DRAW_H

// x and y are logical coords, mapid is type
int game_draw_board_tile(int x, int y, int mapid);

#endif
