#ifndef MUTEX__H
#define MUTEX__H
#include "queue.h"

typedef struct _hippo_is_sleepy_mutex {
  int lock;
  int qlock;
  queue* q;
} mutex_t;


int mutex_init(mutex_t * mp);
int mutex_destroy(mutex_t * mp);
int mutex_lock(mutex_t * mp);
int mutex_unlock(mutex_t * mp);


#endif /* MUTEX__H */
