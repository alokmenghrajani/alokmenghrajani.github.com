/*
  Thread safe version of malloc package.

 Used to do boundary checking (to detect data corruption / calling free twice on same block) and keeps track of how many blocks/how much memory is allocated.
  
*/

#include "safe_malloc.h"
#include "asm_spinlock.h"
#include "../usercode/malloc.h"
#include "util.h"



void print_int(int i);
int test_error(int t, int line);

void print_int(int i) {
  char buf[2];
  int a;
  buf[1]=0;
  if (i<0) {
    test_error(print(1,"-"), __LINE__);
    i=-i;
  }
  a=i%10;
  i=i/10;
  buf[0]='0'+a;
  if (i>0)
    print_int(i);
  test_error(print(1,buf), __LINE__);
}


int test_error(int t, int line) {
  if (t==-1) {
    print(6, "error:");
    print_int(line);
    print(1, "\n");
    exit(-1);
  }
  return t;
}

int malloc_lock;

void thread_safe_mminit() {
  mm_init();
  malloc_lock=1;
}


// lock

// debugging counters
//static int malloc_counter1 = 0;  // number of blocks allocated
//static int malloc_counter2 = 0;  // total size of blocks allocated

void *thread_safe_malloc(int size) {
  void *bp;
//  malloc_counter1++;
//  malloc_counter2+=size;
  // set lock
  get_spinlock(&malloc_lock);
//  bp = mm_malloc(size+12);
  bp = mm_malloc(size);
  ASSERT(bp!=NULL);
  // unlock
  put_spinlock(&malloc_lock);
//  *(int *)bp = 0xDEAD0101;
//  *(int *)(bp+4) = size;
//  *(int *)(bp+size+8) = 0xDEAD0202;
//  return bp+8;
  return bp;
}

void thread_safe_free(void *bp) {
//  int size;
//  size = *(int*)(bp-4);
//  malloc_counter1--;
//  malloc_counter2-=size;
//  ASSERT(malloc_counter1>=0);
//  ASSERT(malloc_counter2>=0)
//  ASSERT(*(int*)(bp-8)==0xDEAD0101);
//  ASSERT(*(int*)(bp+size)==0xDEAD0202);
//  *(int*)(bp-8) = 0xDEADBEEF;
//  *(int*)(bp+size) = 0xDEADBEEF;

  // set lock  
  get_spinlock(&malloc_lock);

//  ASSERT((bp-8)!=NULL);
//  if( (bp-8) != NULL)
//    mm_free(bp-8);
  if (bp!=NULL)
    mm_free(bp);

  // unlock
  put_spinlock(&malloc_lock);
}
