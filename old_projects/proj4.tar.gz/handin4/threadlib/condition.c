#include "util.h"
#include "asm_spinlock.h"
#include "thr.h"
#include "condition.h"

// Don't call wait with emtpy queue ???

int cond_init(cond_t * cv){
  cv->lock= 1;
  cv->q = new_queue();  
  return (cv->q == NULL ? -1 : 0);  
}

/* this simply frees the memory allocated by init */
int cond_destroy(cond_t * cv){
  clear(cv->q);
  thread_safe_free(cv->q);
  return 0;
}



/* the calling process is put to sleep until another process
   calls either cond_signal (while that process is at the top of the queue
   or cond_broadcast. The mutex is release just before the thread goes to sleep.
*/
int cond_wait(cond_t * cv,mutex_t * mp){
  thread_t * me = find_thread_t(sys_get_pid());

  get_spinlock(&(cv->lock));
  enqueue(cv->q, (void*)me);
  me->runlock = 0;
  
  put_spinlock(&(cv->lock)); 
  if(mp != NULL)
    mutex_unlock(mp);
  sys_stopme(&(me->runlock));
  mutex_lock(mp);
  return 0;
}

/* this is the same as cond_wait, except it uses a spinlock instead of a mutex.*/

int cond_wait_spin(cond_t * cv, int *spinlock){
  thread_t * me = find_thread_t(sys_get_pid());

  get_spinlock(&(cv->lock));
  enqueue(cv->q, (void*)me);
  me->runlock = 0;  
  put_spinlock(&(cv->lock)); 
  if(spinlock != NULL)
    put_spinlock(spinlock);
  sys_stopme(&(me->runlock));
  get_spinlock(spinlock);
  return 0;
}

/* wakes up the first thread on the queue*/
int cond_signal(cond_t * cv){
  thread_t * t;
  get_spinlock(&(cv->lock));
  if(isempty(cv->q)){
    put_spinlock(&(cv->lock));
    return -1;
  }
  else {
    t =(thread_t*) dequeue(cv->q);
    t ->runlock = 1;
    ASSERT(sys_markrunnable(t->tid)!=-1);
  }
  put_spinlock(&(cv->lock));
  return 0;
}


/* wake up all the threads on the queue*/

int cond_broadcast(cond_t * cv){
  thread_t * t;
  get_spinlock(&(cv->lock));
  while(!isempty(cv->q)){
    t =(thread_t*) dequeue(cv->q);
    t ->runlock = 1;
    ASSERT(sys_markrunnable(t->tid)!=-1);
  }
  put_spinlock(&(cv->lock));
  return 0;
}
