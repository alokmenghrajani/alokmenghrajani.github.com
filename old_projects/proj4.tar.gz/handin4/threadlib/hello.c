#include "userdebug.h"
#include "syscall_wrapper.h"
#include "asm_spinlock.h"
#include "thr.h"
#include "util.h"
#include "mutex.h"

static int titilock = 1;

static mutex_t* tatamutex;

void* toto(void *);

int main() {
  int i =0 , pid, ret;
   mm_init(); 
  thr_init(1024);

  lprintf("in main");
  tatamutex = (mutex_t *) safe_malloc(sizeof(mutex_t));
  if(tatamutex == NULL)
    lprintf("shit my eye!");
 mutex_init(tatamutex);
  lprintf("Trying init.");


 
  //get_spinlock(&titilock);
  mutex_lock(tatamutex);
  for(i = 0; i< 5; i++) {
    pid = thr_create((void*) toto, (void*)i, thr_new());
    sys_yield(pid);
    lprintf("thr_create returned: %d\n", pid);//thr_create((void*) toto, (void*)i, thr_new()));
  }
  //  put_spinlock(&titilock);
  mutex_unlock(tatamutex);
  for (i = 0; i<5; i++) {
    thr_join(i+2, &pid,&ret);
    lprintf("Root thread detected end of %d : returned with %d ", pid,ret);
  }
  pid = thr_create((void*) toto, (void*)3, thr_new());
  
  sys_sleep(1000);
  lprintf("wake!");
  thr_join(0,&pid, &ret); 
  lprintf("Root thread detected end of %d : returned with %d ", pid,ret);
  lprintf("Root thread finished !!!!");
  while(1);
}

void* toto(void* b) {
  int a = (int) b;
  int pid = sys_get_pid();
  int i;
  if(a%2){
    mutex_lock(tatamutex);
    mutex_unlock(tatamutex);
  }
  for (i=0; i<20; i++) {
    lprintf("assssss! %d : %d", pid, (int) a);
    sys_yield(0);
  }
  return b;
}
