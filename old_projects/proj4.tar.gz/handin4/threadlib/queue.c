#include "queue.h"
#include "util.h"

/*
  HOW THE QUEUE WORKS:

  Front (Dequeue here)  Back (Enqueue here)
    |                     |
    |                     |
    V                     V
   [1]->[2]->.....->[5]->[6]->NULL

   This package is thread unsafe !
*/

queue* new_queue(){
  queue* new = (queue*)thread_safe_malloc(sizeof(queue));
  new->front = NULL;
  new->back = NULL;
  return new;
}

void enqueue(queue* q, void* data){
  q_node * t = (q_node*)thread_safe_malloc(sizeof(q_node));
  t->data = data;
  t->next = NULL;

  // Is it the first element
  if(q->front == NULL){
    q->front = t;
  } else {
    ASSERT(q->back != NULL);
    q->back->next = t;
  }
  q->back = t;
}

void* dequeue(queue* q){
  q_node* temp;
  void* ret;
  
  temp = q->front;
  q->front = temp -> next;
  // Check to see if we removed last element
  if(q->front == NULL)
    q->back == NULL;
  ret = temp -> data;
  thread_safe_free(temp);
  return ret;
}

void clear(queue* q){
  while(!isempty(q))
    dequeue(q);
}

int isempty(queue* q){
  return (q->front == NULL);
}


