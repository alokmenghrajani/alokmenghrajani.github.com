#ifndef OLDASM_SYSCALL_H
#define OLDASM_SYSCALL_H

extern int oldasm_syscall_wrapper(int sysnum, int arg);

#endif /* OLDASM_SYSCALL_H */
