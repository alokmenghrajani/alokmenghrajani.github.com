#ifndef MAZE_H
#define MAZE_H
#include "condition.h"
#include "common.h"
 


// defines

#define GAME_ON 1
#define STALL 2
#define DONE 4


// types
typedef int monid_t;
typedef int direction_t;
typedef int tile_t;

typedef struct move_combo
{
  monid_t mon;
  direction_t dir;
} move_combo_t;

typedef struct _hippo_became_a_monster_like_in_thriller_{
  monid_t monid;
  struct _hippo_became_a_monster_like_in_thriller_ * next;
  int x;
  int y;
  tile_t color;
} monster_t;

typedef struct _hippo_is_bored_of_waiting {
  monster_t ** dep;
  int dep_n;
  struct _hippo_is_bored_of_waiting * next;
} waitlist;

typedef struct hippo_plays_pacman{
  tile_t tile;
  monster_t * monster; 	// This points to 
			//the mosnter standing on that tile
  int lock; 		// we have locks for each cell
  monster_t** reserve;  // This is to make 
			//reservations through make_request_move
  int reserve_n;	// This is the  number of threads that have
			// reserved that tile
  waitlist* deps;	// This is a queue of monsters waiting on the cell
  cond_t wait;		// The condition variable that monsters can wait on
} cell_t;



// maze_* function prototypes
int maze_init();
int maze_cleanup();
tile_t maze_get_board_contents(int x, int y);
int maze_set_board_contents(int x, int y, tile_t tile);
monid_t maze_new_monster(int c, int x, int y);
int maze_destroy_monster(monid_t mon);
int maze_move_monster(monid_t mon, direction_t dir);
int maze_request_move(move_combo_t *ml, int n);
// int maze_abort_request(monid_t mon, direction_t dir); DEPRICATED
void maze_set_game_status(int s);
int maze_get_game_status(void);
void maze_abort(void);
void maze_wait(void);
int maze_consume(monid_t mon);



#endif
