#ifndef COND__H
#define COND__H
#include "queue.h"
#include "mutex.h"
#include "asm_spinlock.h"

typedef struct _hippo_is_going_to_sleep_cond {
  int lock;
  queue* q;
} cond_t;


int cond_init(cond_t * cv);
int cond_destroy(cond_t * mp);
int cond_wait(cond_t * cv,mutex_t * mp);
int cond_wait_spin(cond_t * cv, int * spinlock);
int cond_signal(cond_t * cv);
int cond_broadcast(cond_t * cv);

#endif /* COND__H */
