#ifndef ASM_SYSEXIT__H
#define ASM_SYSEXIT__H

extern void asm_unlock_sysexit(int * );
extern void asm_default_exit(void);


#endif /* ASM_SYSEXIT__H */
