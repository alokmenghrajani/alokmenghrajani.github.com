#ifndef THRUTIL__H
#define THRUTIL__H

#define NULL 0

#define MAGIC_BREAK asm("xchg %ebx, %ebx;");

#ifdef DEBUG
#define ASSERT(ex) \
if (!(ex)) {{\
lprintf("Assert failed %s, %d !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", __FILE__, __LINE__); \
MAGIC_BREAK; \
for(;;) \
  sys_yield(sys_get_pid()); \
}}
//#define ASSERT(ex) ((ex) ? 1 : (lprintf("Assert failed %s, %d", __FILE__, __LINE__)))
#else
#define ASSERT(ex) (ex)
#endif /* DEBUG */

#endif /* THRUTIL__H */
