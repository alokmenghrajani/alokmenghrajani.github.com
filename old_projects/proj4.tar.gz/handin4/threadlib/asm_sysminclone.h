#ifndef ASM_SYSMINCLONE__H
#define ASM_SYSMINCLONE__H

extern int asm_sysminclone(void *stack);

#endif /* ASM_SYSCALL__H */
