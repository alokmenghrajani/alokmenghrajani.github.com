#include "mutex.h"
#include "util.h"
#include "asm_spinlock.h"
#include "thr.h"

int mutex_init(mutex_t *mp){
  if(mp ==NULL)
    sys_print (6, "shit!!");
  mp->lock = 1;
  mp->qlock = 1;
  mp->q = new_queue();
  return (mp->q == NULL ? -1 : 0);
}



int mutex_destroy(mutex_t * mp){
  clear(mp->q);
  thread_safe_free(mp->q);
  return 0;
}


int mutex_lock(mutex_t * mp){
  int t = 0;
  thread_t * me = find_thread_t(sys_get_pid());
  
  get_spinlock(&(mp->qlock));
  t = asm_XCHG(&(mp->lock),t);
  if(!t){
    enqueue(mp->q, (void*)me);
    me->runlock = 0;
    put_spinlock(&(mp->qlock));
    sys_stopme(&(me->runlock));
  }
  else{
    put_spinlock(&(mp->qlock));
  }
}

int mutex_unlock(mutex_t * mp){
  thread_t * t ;
  get_spinlock(&(mp->qlock));
  if(isempty(mp->q))
    asm_XCHG(&(mp->lock),1);
  else{
    t =(thread_t*) dequeue(mp->q);
    t ->runlock = 1;
    ASSERT(sys_markrunnable(t->tid)!=-1);
  }
  put_spinlock(&(mp->qlock));

}

