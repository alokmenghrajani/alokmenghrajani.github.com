
/*

  loader.c: the funtion load_code is defined here. It loads all the 
  user code which is in a.out format. 

  Authors: Alok Menghrajani & Vikram Manjunath

  Note: that we don't use a c runtime or an idle process.
  We always bootstrap with the shell and respawn it when it dies.
  The default exit code which is used as a default exit routine for any user 
  code is loded right after text and data and is set as the return adress.
  One of the input values is a pointer and the value at that address
  is set to the address of this default exit code.

 */
#include "loader.h"
#include "util.h"
#include "page.h"
#include <oskit/c/string.h>
#include <oskit/c/malloc.h>
#include "exec2obj.h"
#include "kernel.h"
#include "inc/seg.h"
#include "inc/x86_regs.h"
#include "inc/interrupts.h"

typedef struct _exec_struct {
  unsigned long a_midmag;
  unsigned long a_text;
  unsigned long a_data;
  unsigned long a_bss;
  unsigned long a_syms;
  unsigned long a_entry;
  unsigned long a_trsize;
  unsigned long a_drsize;
} exec_struct;


/* default sys_exit is the code that we ask the user functions to jumpt to when
   (and if) it returns. This basically does a syscall for exit */
char default_sys_exit[16] = {0xbf, 0x05, 0x00, 0x00, 0x00, 0x89, 0xc6, 0xcd, 0x40, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90};

/* getbytes reads size bytes from filename to buf, starting at byte number offset 
   in the file. 
   negative values are returned in case of failure.
*/
int getbytes(char* filename, int offset, int size, char* buf) {
  int i, j;
//  printf("GETBYTES filename=%s, offset=%d, size=%d, buf=%x\n", filename, offset, size, (int) buf);

  // ASSUME filename is max 256
  for (i=0; i<128; i++) {
    // compare exec2obj_userapp_TOC[i] with filename
    if (strncmp(filename, exec2obj_userapp_TOC[i].execname, 256)==0) {
      if (offset==exec2obj_userapp_TOC[i].execlen)
	return 0;
      for (j=0; (j<size) && ((j+offset)<exec2obj_userapp_TOC[i].execlen); j++) {
	buf[j] = exec2obj_userapp_TOC[i].execbytes[j+offset];
      }
      return (j==0) ? -1 : j;
    }
  }
  return -2; // FILE NOT FOUND
}


/* returns where the usercode starts.
   default_exit_addr is set to the address of the begining of the default
   exit code.
   ptd points to the ptd in which we want to load the code.
*/
mem_t loader_loadcode(char* filename, ptd_struct *ptd, mem_t *default_exit_addr, int bootstrapping) {
  exec_struct e;
  int t,k, i;
  char *c,*datastart;
  int oldcr3;
  pcb_struct *pcb;
  ptd_struct *oldptd;
  char filename2[256];

  /* make a local copy, in kernel mem, of the filename so that we can safely
     change the ptd */
  for(i = 0; i< 255 && filename[i] != NULL; i++)
    filename2[i] = filename[i];
  filename2[i]=0;

  /* read in the code's header, in the form of an exec_struct */
  t=getbytes(filename2, 0, sizeof(exec_struct), (char*) &e);


  if ((t<sizeof(exec_struct)) || ((e.a_midmag & 0xFFFF)!=NMAGIC) || (e.a_entry<USER_MEM_START)) {
    // File not found, or too small or invalid
    return 0;
  }
  // Check that user code is inside VM
  t = e.a_text + e.a_data + e.a_bss + SYS_EXIT_SIZE;

  if ((unsigned int) (t+USER_MEM_START)>0xffffffff)
    return 0;
  // calculate number of pages needed for all the code
  t = t / PAGE_SIZE + ((t % PAGE_SIZE) == 0 ? 2 : 3);  // round up by three ((even quicker) quick hack)

  for (i=0; i<t; i++) {
    /* Allocate each of the pages that we'll be using to store the code */
    k = page_get_new(ptd, USER_MEM_START + i * PAGE_SIZE);
    if (k==-1) {
      // something bad happened, purge the pages and return
      disable_interrupts();
      page_ptd_purge(ptd);
      enable_interrupts();
      return 0;
    }
  }
  // We must set the ptd
  oldcr3 = get_cr3();
  oldptd = pcb->ptd;
  // If we are not bootstrapping, then we might have an intterupt, so we must protect ourseleves:
  if (!bootstrapping) {
    pcb = GET_PCB(get_esp());
    oldptd = pcb->ptd;
    pcb->ptd = ptd;
  }
  set_cr3((int) ptd);
  // load text 
  t=getbytes(filename2, sizeof(exec_struct), e.a_text, (char*)USER_MEM_START);

  // Make sure that the loader worked
  if(t != e.a_text) {
    return 0;
  }
  
  if (e.a_data>0) {
    //load data in the page starting after the the text
    datastart =  (char*) (t / PAGE_SIZE + ((t % PAGE_SIZE) == 0 ? 0 : 1));
    datastart = (char*)((int)datastart *  PAGE_SIZE);
    t = getbytes(filename2,  sizeof(exec_struct)+ t, e.a_data, (char*)(USER_MEM_START + (int)datastart));
  
    // Make sure that the loader worked
    if(t != e.a_data) {
      return 0;
    }
  } else {
    datastart = (char*)t;
  }

  // Assert is ok here, cos we don't have a file system, so no chance of failing.
  //  ASSERT(t==(e.a_text + e.a_data));

  // set the bss
  c = (char*)USER_MEM_START + (int)datastart + e.a_data;
  for (i=0; i<e.a_bss; i++) {
    c[i] = 0;
  }

  // put the default sys exit
  c = (char *)USER_MEM_START + (int)datastart + e.a_data + e.a_bss;
  for (i=0; i<SYS_EXIT_SIZE; i++) {
    c[i] = default_sys_exit[i];
  }
  // Restore it
  set_cr3(oldcr3);
  if (!bootstrapping)
    pcb->ptd = oldptd;

  ASSERT(default_exit_addr);
  *default_exit_addr= USER_MEM_START + (int)datastart + e.a_data + e.a_bss;

  return e.a_entry;
}

