#ifndef UTIL__H
#define UTIL__H

#include "syscalls/syscalls.h"
#include <oskit/c/stdio.h>

#define DEBUG

#define NULL 0

#define FALSE 0
#define TRUE 1



#ifdef DEBUG
#define ASSERT(ex) {\
if (!(ex)) {{\
printf("Assert failed %s, %d !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", __FILE__, __LINE__); \
for(;;); \
}}}
#else
#define ASSERT(ex) {(ex) ? 1 : 0;}
#endif /* DEBUG */


#define MAGIC_BREAK asm("xchg %ebx, %ebx;");

#endif /* UTIL__H */
