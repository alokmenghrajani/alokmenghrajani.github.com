#ifndef TIMER__H
#define TIMER__H

#include "kernel.h"

/* from proj1 timer_defines.h */
#define TIMER_IDT_ENTRY 0x20
#define TIMER_PERIOD_IO_PORT 0x40
#define TIMER_MODE_IO_PORT 0x43
#define TIMER_SQUARE_WAVE 0x36
/* -------------------------- */

#define TIMER_FREQ 1193182
#define TIMER_RATE 100           /* one tick every 10 milliseconds -> 100 times per second */
#define TIMER_QUANTUM 20        /* Maximum time quantum a process gets.
				    200 milliseconds -> every 20 ticks */



/* Incremented once every ten milliseconds */
volatile unsigned int timer_ticks;

/* init the chip, set the timer to zero and install the handler */
void timer_init();

/* must install this !!! */
extern void timer_handler_wrapper();
void timer_handler();

#endif /* TIMER__H */
