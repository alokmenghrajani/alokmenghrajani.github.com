/*

  timer.c: the C code for the timer handler

  Authors: Alok Menghrajani & Vikram Manjunath

 */

#include "timer.h"
#include "idt.h"
#include "inc/interrupts.h"
#include "inc/io_map.h"
#include "inc/seg.h"
#include "context.h"
#include "kernel.h"
#include "inc/x86_regs.h"
#include <oskit/c/stdio.h>
#include "process.h"

void timer_init() {
  /* Initialize the timer and install the handler */
  unsigned short t;
  void* idt=sidt();
  struct idt_entry *entry;

  timer_ticks=0;

  // Complete the TIMER_IDT_ENTRY
  entry = (struct idt_entry*) idt;
  entry+=TIMER_IDT_ENTRY;
  entry->hoffset = ((unsigned short int)(((unsigned int)timer_handler_wrapper)>>16));
  entry->P = 1;
  entry->DPL = 0;
  entry->D = 0xF;
  entry->Ze = 0;
  entry->Seg = KERNEL_CS;
  entry->loffset = (unsigned short int) timer_handler_wrapper;

  // Set mode to square wave
  outb(TIMER_SQUARE_WAVE, TIMER_MODE_IO_PORT);
  t = TIMER_FREQ / TIMER_RATE;
  outb((unsigned char) t, TIMER_PERIOD_IO_PORT);
  outb((unsigned char) (t>>8), TIMER_PERIOD_IO_PORT);
}

void timer_handler() {
  pcb_struct * pcb;
  if (getting_started_flag==1) {
    outb(INT_CTL_DONE, INT_CTL_REG);
    return;
  }
  pcb = GET_PCB(get_esp());
  timer_ticks++;

  // Acknowledge
  outb(INT_CTL_DONE, INT_CTL_REG);
 
  // Context switch if process is not stopped and quantum has elapsed.
  if ( (pcb -> sleep_time < timer_ticks)&& (pcb -> state != STOPPED) && (timer_ticks % TIMER_QUANTUM) == 0)
    context_switch(-1);
  else
    return;

}



