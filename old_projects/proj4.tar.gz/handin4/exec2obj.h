/*
  Name: exec2obj.h
  Date: February 24th 2003
  Author: Steve Muckle

  Provides the interface to access user programs compiled as const char
  arrays.
*/

/* Format of entries in the table of contents. */
typedef struct {
  const char execname[256];
  const char* execbytes;
  int execlen;
} exec2obj_userapp_TOC_entry;

/* The number of user executables in the table of contents. */
const int exec2obj_userapp_count;

/* The table of contents. */
const exec2obj_userapp_TOC_entry exec2obj_userapp_TOC[128];
