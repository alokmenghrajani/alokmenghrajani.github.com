#ifndef IDT__H
#define IDT__H

/* Structure used to put data into the idt */

struct idt_entry {
  unsigned short int loffset; /* Offset 15..0 */
  unsigned short int Seg; /* Segment Selector */
  unsigned int Ze:8; /* should be zeros */
  unsigned int D:5; /* Size of gate. 7=16bits, F=32 bits */
  unsigned int DPL:2; /* Descriptor Privilege Level */
  unsigned int P:1; /* Present flag */
  unsigned short int hoffset;  /* Offset 31..16 */
};


#endif /* IDT__H */
