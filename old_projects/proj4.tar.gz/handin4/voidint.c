#include "voidint.h"
#include "idt.h"
#include "inc/interrupts.h"
#include "inc/seg.h"

void voidint_init(int nb) {
  /* Initialize the void handler */
  void* idt=sidt();
  struct idt_entry *entry;

  // Complete the TIMER_IDT_ENTRY
  entry = (struct idt_entry*) idt;
  entry+=nb;
  entry->hoffset = ((unsigned short int)(((unsigned int)voidint_handler_wrapper)>>16));
  entry->P = 1;
  entry->DPL = 0;
  entry->D = 0xF;
  entry->Ze = 0;
  entry->Seg = KERNEL_CS;
  entry->loffset = (unsigned short int) voidint_handler_wrapper;
}
