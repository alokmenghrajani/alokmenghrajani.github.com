#ifndef VOIDINT__H
#define VOIDINT__H

#include "kernel.h"

/* install the handler */
void voidint_init(int nb);

/* must install this !!! */
extern void voidint_handler_wrapper();

#endif /* VOIDINT__H */
