/*
 * disk.c
 * Steve Muckle
 * 15-412 Project Set
 */

#include <oskit/c/stdlib.h>

Do not compile this!
This source file is for browsing only.
Please use the library libproj4.a, which will always
contain the most up to date version of this code.

/* Private kernel includes. */
#include "disk.h"
#include "console.h"
#include "kernstructs.h"

/* 412 includes. */
#include <412/io_map.h>
#include <412/interrupts.h>
#include <412/seg.h>
#include <412/kerndebug.h>
#include <412/common.h>

/* Selects which disk will be used for data transfers. */
int disk_select = 0;

/* Disk information structures (filled in by disk_init). */
disk ide0;
disk ide1;

/* Disk completion callback functions. */
extern void disk_read_callback();
extern void disk_write_callback();

/* Keep track of what kind of disk op we're doing, 
   where the transfer is from/to, and how many blocks 
   there are involved. */
int ide_busy = 0;
char* io_buf = NULL;
int block_cnt = 0;

/* Assembly wrapper for disk interrupts. */
void asm_disk_handle();

/*
 * int get_num_sectors(int drive)
 * Returns the number of sectors on the drive.
 */
int get_num_sectors() {
  return ide0.blks;
}

/*
 * void disk_install()
 * Installs the disk interrupt handler into the IDT.
 */
void disk_install() {
  trap_idt_t* IDT = 0;

  /* Get address of IDT. Note: The IDT MUST have been allocated
     before this can be used! */
  IDT = (trap_idt_t*)sidt();

  IDT[DISK_IDT_ENTRY].int_handler_lower = (int)asm_disk_handle & 0xFFFF;
  IDT[DISK_IDT_ENTRY].segment_selector = KERNEL_CS_SEGSEL;
  IDT[DISK_IDT_ENTRY].reserved = 0;
  IDT[DISK_IDT_ENTRY].type = INTR_GATE;
  IDT[DISK_IDT_ENTRY].d = 1;
  IDT[DISK_IDT_ENTRY].dpl = 0;
  IDT[DISK_IDT_ENTRY].present = 1;
  IDT[DISK_IDT_ENTRY].int_handler_upper = ((int)asm_disk_handle >> 16) & 0xFFFF;
}

/*
 * int disk_init()
 * Installs the disk interrupt handler via disk_install(),
 * waits until the disks are ready, and finds out how big
 * they are (filling in the ide0 and ide1 data structures).
 */
int disk_init() {
  int error_code,i;
  static int initcode = ERROR;
  short sector_buf_s[256];

  if (initcode == SUCCESS) return SUCCESS;

  /* Install the disk interrupt handler. */
  disk_install();

  /* The IDE controller clears the DRIVE READY bit upon power up.
     We need to wait for this bit to clear. Also wait for heads
     to settle over track (DRIVE SEEK COMPLETE). */
  while(inb(IDE_STATUS_REGISTER) !=
	(IDE_STATUS_DRIVE_READY | 
	 IDE_STATUS_DRIVE_SEEK_COMPLETE));

  /* Probe hard disks to make sure they are working correctly. */
  outb(IDE_COMMAND_DIAGNOSTIC,IDE_COMMAND_REGISTER);
  while((inb(IDE_STATUS_REGISTER) & IDE_STATUS_DRIVE_BUSY));

  /* Read error code from drive 0. */
  error_code = inb(IDE_ERROR_REGISTER);  
  /* Check error code. The top bit of drive 0's error code 
     indicates whether there is an error on drive 1. */
  if ((error_code & 0xF) != 0x1) {
    /* Drive 0 has responded with some sort of hardware error. */
    lprintf_kern("Drive 0 has a hardware error!\n");
    switch(error_code) {
    case 0x02:
      lprintf_kern("Drive 0 reported a formatter device error.\n");
      break;
    case 0x03:
      lprintf_kern("Drive 0 reported a sector buffer error.\n");
      break;
    case 0x04:
      lprintf_kern("Drive 0 reported a ECC circuitry error.\n");
      break;
    case 0x05:
      lprintf_kern("Drive 0 reported a controlling microprocessor error.\n");
      break;
    default:
      lprintf_kern("Drive 0 reported an unknown error.\n");
    }
    return ERROR;
  }

  if (error_code & 0x80) {
    /* Drive 1 has responded with some sort of hardware error. */
    lprintf_kern("Drive 1 has a hardware error!\n");
    return ERROR;
  } 
  
  /* Get drive parameters for drive 0. */
  outb(0xE0,IDE_DRIVE_HEAD_REGISTER);
  /* Enable disk interrupts. */
  outb(0x8,IDE_DEVICE_CONTROL_REGISTER);
  ide_busy = IDE_BUSY_DIAGNOSTIC;
  outb(IDE_COMMAND_IDENTIFY_DRIVE, IDE_COMMAND_REGISTER);
  /* For now, poll for the status. */
  while(ide_busy);
  /* Copy bytes into sector buffer. */
  for (i=0;i<256;i++) sector_buf_s[i] = inw(IDE_DATA_REGISTER);
  /* Get the drive parameters. */
  ide0.cyl = sector_buf_s[IDE_IDENTIFY_NUM_CYLINDERS];
  ide0.heads = sector_buf_s[IDE_IDENTIFY_NUM_HEADS];
  ide0.spt = sector_buf_s[IDE_IDENTIFY_NUM_SECTORS_TRACK];
  ide0.blks = ide0.cyl * ide0.heads * ide0.spt;

#ifdef ENABLE_SECOND_DISK
  /* Get drive parameters for drive 1. */
  outb(0xF0,IDE_DRIVE_HEAD_REGISTER);
  outb(0x8,IDE_DEVICE_CONTROL_REGISTER);
  ide_busy = IDE_BUSY_DIAGNOSTIC;
  outb(IDE_COMMAND_IDENTIFY_DRIVE, IDE_COMMAND_REGISTER);
  /* For now, poll for the status. */
  while(ide_busy);
  /* Copy bytes into sector buffer. */
  for (i=0;i<256;i++) sector_buf_s[i] = inw(IDE_DATA_REGISTER);
  /* Get the drive parameters. */
  ide1.cyl = sector_buf_s[IDE_IDENTIFY_NUM_CYLINDERS];
  ide1.heads = sector_buf_s[IDE_IDENTIFY_NUM_HEADS];
  ide1.spt = sector_buf_s[IDE_IDENTIFY_NUM_SECTORS_TRACK];
  ide1.blks = ide1.cyl * ide1.heads * ide1.spt;
#endif

  initcode = SUCCESS;
  return SUCCESS;
}

/*
 * void select_drive(int drive)
 * Selects the drive, 0 or 1, that will be used for future
 * reads and writes.
 */
void select_drive(int drive) {
  if (drive != 0 && drive != 1) return;
  else disk_select = drive;
}

/* 
 * int setup_address(int lba_addr, int blocks)
 * Sends LBA address, drive number, and the number of sectors
 * to transfer to IDE controller. 
 */
int setup_address(int lba_addr, int blocks) {
  char temp;

  /* We want to transfer 1 sector. */
  outb(blocks,IDE_SECTOR_COUNT_REGISTER);
  
  /* Make sure LBA address is within bounds. */
  if (disk_select) {
    if (lba_addr < 0 || lba_addr >= ide1.blks) {
      lprintf_kern("Invalid write attempt to disk 1: block %d/%d\n",
	     lba_addr,ide1.blks);
      return ERROR;
    }
  } else {
    if (lba_addr < 0 || lba_addr >= ide0.blks) {
      lprintf_kern("Invalid write attempt to disk 0: block %d/%d\n",
	     lba_addr,ide0.blks);
      return ERROR;
    }
  }

  /* LBA address bits...
     Sector number register: bits 0-7.
     Cylinder low register: bits 8-15.
     Cylinder high register: bits 16-23.
     Drive head register (bits 0-3): bits 24-27.

     Set up LBA address and drive number in registers. 
  */
  outb(lba_addr & 0xFF, IDE_SECTOR_NUMBER_REGISTER);
  outb((lba_addr & 0xFF00)>>8,IDE_CYLINDER_LOW_REGISTER);
  outb((lba_addr & 0xFF0000)>>16,IDE_CYLINDER_HIGH_REGISTER);
  temp = (lba_addr & 0xF000000)>>24;
  if (disk_select) temp |= 0xF0;
  else temp |= 0xE0;
  outb(temp,IDE_DRIVE_HEAD_REGISTER);

  return SUCCESS;
}

/*
 * void ide_write_sector(int lba_addr, char* source, int num)
 *                      
 * Initiates an IDE operation to write the specified sectorss
 * to the disk. The sectors will be taken sequentially from the
 * address source.
 */
void ide_write_sector(int lba_addr, char* source, int num) {
  int i;

  if (!num || num < 0) return;

  /* Setup address registers. */
  if (setup_address(lba_addr,num) == ERROR) return;

  if (ide_busy != IDE_NOT_BUSY) {
    lprintf_kern("ide_write_sector called with an outstanding IDE request!\n");
    panic("ide_write_sector called with an outstanding IDE request!\n");
  }

  /* Set ide_busy. */
  ide_busy = IDE_BUSY_WRITE;

  /* Send the write command code. */
  outb(IDE_COMMAND_WRITE_SECTORS,IDE_COMMAND_REGISTER);

  /* Must wait for DRQ to be set. Eventually we might want to break out
     and do useful work, then come back to this (there is no interrupt
     after this). */
  while(!(inb(IDE_STATUS_REGISTER) & 0x8));

  /* Write the first sector into the buffer. */
  io_buf = source + SECTOR_SIZE;
  block_cnt = num;
  for (i=0;i<256;i++) outw(((short*)source)[i],IDE_DATA_REGISTER);
  
}

/*
 * void ide_read_sector(int lba_addr, char* source, int num)
 *                  
 * Initiates an IDE operation to read the specified sectors
 * from the disk. The sectors will be stored sequentially starting
 * at the address source.
 */
void ide_read_sector(int lba_addr, char* dest, int num) {
  if (!num || num < 0) return;

  if (ide_busy != IDE_NOT_BUSY) {
    lprintf_kern("ide_read_sector called with an outstanding IDE request!\n");
    panic("ide_read_sector called with an outstanding IDE request!\n");
  }


  /* Setup address registers. */
  if (setup_address(lba_addr,num) == -1) return;

  /* Set ide_busy. */
  ide_busy = IDE_BUSY_READ;

  /* Save destination so interrupt handler knows where to copy
     the data. */
  io_buf = dest;

  /* Set block_cnt. */
  block_cnt = num;

  /* Send the read command code. */
  outb(IDE_COMMAND_READ_SECTORS,IDE_COMMAND_REGISTER);
}

/*
 * void disk_handler()
 * Handles disk interrupts by reading in/writing out data 
 * and manipulating process queues.
 */
void disk_handler() {
  int i;
  
  /* Read status register to clear interrupt. */
  inb(IDE_STATUS_REGISTER);

  switch(ide_busy) {
  case IDE_BUSY_READ:
    /* A pending read has completed. */
    block_cnt--;
    if (!io_buf) {
      lprintf_kern("disk_handler: read with null io_buf");
      ide_busy = IDE_NOT_BUSY;
      return;
    }
    /* Save the data. */
    for (i=0;i<256;i++) ((short*)io_buf)[i] = inw(IDE_DATA_REGISTER);
    if (block_cnt) {
      /* If we're not done set the read pointer and wait for the next
	 sector. */
	io_buf += SECTOR_SIZE;
    } else {
      /* The read has completed. Manipulate disk queue, etc. */

      /* If we're done just close up shop. */
      io_buf = NULL;
      ide_busy = IDE_NOT_BUSY;

      disk_read_callback();

    }
    break;
  case IDE_BUSY_WRITE:
    block_cnt--;
    /* A pending write has completed. */
    if (block_cnt) {
      /* If we have more sectors to write then write another one. */
      for (i=0;i<256;i++) outw(((short*)io_buf)[i],IDE_DATA_REGISTER);
      io_buf += SECTOR_SIZE;
    } else {
      /* The write has completed. Manipulate disk queue, etc. */
 
      /* If we're done just close up shop. */
      io_buf = NULL;
      ide_busy = IDE_NOT_BUSY;

      disk_write_callback();

    }
    break;
  default:
    ide_busy = IDE_NOT_BUSY;
  }

  /* Ack the PIC. */
  outb(0x60|(0x7&14),0xA0);
  outb(0x62,0x20);
}
