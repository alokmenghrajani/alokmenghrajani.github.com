/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Buffercache.c
*/


/*
  buffercache.c: 
  this provides a wrapper for the harware primatives that read and write 
  sectors to the disk. The units of read and write are now blocks.
  Reads and writes are now cached. 
  A cache size of CACHESIZE (defined in buffercache.h) is used, with an LRU 
  eviction policy.
 */

/* OSKit libc includes. */
#include <oskit/c/stdio.h>

#include "buffercache.h"

/* proj 4 */
#include "filesystem.h"
#include "../inc/disk.h"
#include "../inc/common.h"
#include "../util.h"
#include "iocontrol.h"

#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))


int get_new_line();
int evict();

/* there are 64 lines in the cache */
cache_line_t buffer_cache[CACHESIZE];


int accessstamp = 0; // not unsigned since we don't have this protected.

/*
  initialize the cache data structures and locks
 */
int cache_init(void){
  int i;
  for(i = 0; i < CACHESIZE; i++){
    buffer_cache[i].dirty = 0;
    buffer_cache[i].accessstamp = 0;
    buffer_cache[i].p = 0;
    //    for(j =0; j <BLOCK_SIZE; j++) 
    //      cache[j] =0;
    init_lock3(&(buffer_cache[i].lock));
  }
  init_lock3(&big_lock);
  iocontrol_init();
  return SUCCESS;
}

/*
  cache_write_block(n,src, m) writes m bytes from src to the nth block on disc. m must be less than the size of a block.
 */

void cache_write_block(int block_num, char* source, int num){
  int i,j,line = -1;

  ASSERT(num <= BLOCK_SIZE);

  /* check if the block that we want is in the cache. If so, set hit to 1 */  

  shared_lock(&big_lock);
  for(i = 0; i < CACHESIZE; i++){
    if(buffer_cache[i].block_num == block_num && buffer_cache[i].p){
      exc_lock(&(buffer_cache[i].lock));
      line = i;
      break;
    }
  }
  shared_unlock(&big_lock);

  if (line == -1){ /*miss*/
    exc_lock(&big_lock);
    for(i = 0; i < CACHESIZE; i++){
      if(buffer_cache[i].block_num == block_num && buffer_cache[i].p){
	exc_lock(&(buffer_cache[i].lock));
	line = i;
	exc_unlock(&big_lock);
	break;
      }
    }

    if(line == -1){
      line = get_new_line(); /* get the new line in the cache */
      buffer_cache[line].block_num = block_num;
      buffer_cache[line].p = 1;

      exc_unlock(&big_lock);   

      if (num!=BLOCK_SIZE) {
	/* since it was a cache miss, we need to copy the required block from disk */
	ide_read_block(BLOCK2SECTOR(buffer_cache[line].block_num), buffer_cache[line].cache);
      }
      
      /* Now, we have this line in the cache being valid (present) */
    }
  }
  /* after fetching the block, we can make the changes requested in the write call */
  for(j = 0; j < num; j ++)
    buffer_cache[line].cache[j] = source[j];

  buffer_cache[line].dirty = 1; /* now that we have written to this line, it is "dirty" */

  /* update the access stamp since we just accessed this block */
  buffer_cache[line].accessstamp = accessstamp ++;

  /* Worry about what happens when you exceed MAXINT many disk accesses */
  if(accessstamp < 0){
    exc_lock (&big_lock);
    for(j = 0; j < CACHESIZE; j ++)
      buffer_cache[line].accessstamp = 0;
    exc_unlock (&big_lock);
    accessstamp = 0;
  }
  exc_unlock(&(buffer_cache[line].lock));

  return;
}

/*
  Analogous to cache_write_block
 */

void cache_read_block(int block_num, char* dest, int num){
  int i, hit = 0, j,line= -1;

  ASSERT(num <= BLOCK_SIZE);

  shared_lock(&big_lock);
  /* walk down the cache and see if the block we want is present */
  for(i = 0; i < CACHESIZE; i++){
    if(buffer_cache[i].block_num == block_num && buffer_cache[i].p){
      shared_lock(&(buffer_cache[i].lock));
      line = i;
      hit = 1; /* if it is present, set hit to 1 */
      break;
    }
  }
  shared_unlock(&big_lock);

  if(line == -1){ /* Cache miss */
    //    printf("read: miss\n");

    exc_lock(&big_lock);
    for(i = 0; i < CACHESIZE; i++){
      if(buffer_cache[i].block_num == block_num && buffer_cache[i].p){
	shared_lock(&(buffer_cache[i].lock));
	line = i;
	exc_unlock(&big_lock);
	break;
      }
    }

    if(line == -1){
      line = get_new_line(); /* get the new line in the cache */
      buffer_cache[line].p = 1;
      buffer_cache[line].block_num = block_num;
      exc_unlock(&big_lock);

      /* because we have a cache miss, we copy the line from memory */
      ide_read_block(BLOCK2SECTOR(buffer_cache[line].block_num), buffer_cache[line].cache);
      
      /* demote the lock from exc to shared */
      demote_lock (&(buffer_cache[line].lock));
    }
  }
  /* do the appropriate copying from the cache */
  for(j = 0; j < num; j ++)
    dest[j] = buffer_cache[line].cache[j];
  
  
  /* set the accessstamp */
  buffer_cache[line].accessstamp = accessstamp ++; // who cares about accessstamp concurrency right? no exc lock
  
  /* Worry about what happens when you exceed MAXINT many disk accesses */
  if(accessstamp < 0){
    exc_lock (&big_lock);
    for(j = 0; j < CACHESIZE; j ++)
      buffer_cache[line].accessstamp = 0;
    exc_unlock(&big_lock);
    accessstamp = 0;
  }
  
  shared_unlock(&(buffer_cache[line].lock));
  return;
}


int get_num_blocks(void){
  int bytes = get_num_sectors() * SECTOR_SIZE;
  return (bytes/BLOCK_SIZE + (bytes % BLOCK_SIZE == 0? 0 : 1 ));
}



/*************eviction ********************/


/* get_new_line returns an exclusively locked free block
 assumes that big_lock is exclusively locked.
 */
int get_new_line() {
  int i;

  /* see if there is an unused line in the buffer cache */
  for(i = 0; i < CACHESIZE; i++) {
    if(exc_lock_maybe(&buffer_cache[i].lock)) {
      if (buffer_cache[i].p == 0)
	return i;
      exc_unlock(&buffer_cache[i].lock);
    }
  }
  return evict(); /* if not, then evict a block and return its position */
}

/* evict finds a line that can be freed and frees it and returns an exclusively locked version of it.
   follows an LRU evivtion policy.
 */ 
int evict(){
  int temp_slot = -1, temp_stamp = INT_MAX,i;

  while(temp_stamp == INT_MAX) {
    for(i = 0; i < CACHESIZE; i++) {
      /* find the block index with the least stamp */
      if(exc_lock_maybe(&buffer_cache[i].lock)) {
	if(buffer_cache[i].accessstamp < temp_stamp){
	  if(temp_slot != -1)
	    exc_unlock(&buffer_cache[temp_slot].lock);
	  temp_stamp = buffer_cache[i].accessstamp;
	  temp_slot = i;
	} else {
	    exc_unlock(&buffer_cache[i].lock);
	}
      }
    }
  }
  /* at this point we have an exc lock on a line in the buffer cache */

  /* if the line that we are evicting is "dirty" then write it to disc */
  if(buffer_cache[temp_slot].dirty)
    ide_write_block(BLOCK2SECTOR(buffer_cache[temp_slot].block_num), buffer_cache[temp_slot].cache);

  /* set it to not present and not dirty */
  buffer_cache[temp_slot].dirty = 0;
  buffer_cache[temp_slot].p = 0;
  
  return temp_slot;
}

/*
  call cache_sync if we want to commit all the changes in the buffer to disc 
 */
void cache_sync(){
  int i; 
  exc_lock(&big_lock);
  for( i = 0 ; i < CACHESIZE; i++) /* (exc) lock each line */
    exc_lock(&buffer_cache[i].lock);
 
  for(i = 0; i < CACHESIZE; i++){
    /* write anything that is present AND dirty to disc */
    if(buffer_cache[i].p && buffer_cache[i].dirty) {
      ide_write_block(BLOCK2SECTOR(buffer_cache[i].block_num), buffer_cache[i].cache);
      
      // deschedule
      buffer_cache[i].dirty = 0;
    }
  }
  for( i = 0 ; i < CACHESIZE; i++) /* (exc) lock each line */
    exc_unlock(&buffer_cache[i].lock);
  exc_unlock(&big_lock);
}
