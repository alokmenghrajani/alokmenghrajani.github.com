/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Iocontrol.h
*/


#ifndef __IO_CONTROL_H
#define __IO_CONTROL_H


#include "../kernel.h"
#include "lock3.h"

#define READ 0
#define WRITE 1



typedef struct __ioqueue{
  pcb_struct* pcb; //  the pcb of the guy doing the read/write
  int sector_num; // sctor to read from
  char* data; // where the write data comes from or read data goes to
  char read_write; // is it a read? is it a write?
  struct __ioqueue * next; // next guy in the queue
} ioqueue_t;

void disk_read_callback();
void disk_write_callback();

/* read or write a BLOCK starting at sector_num */
void ide_read_block(int sector_num, char* dest);
void ide_write_block(int sector_num, char* source);

ioqueue_t * waiting_queue;
lock3_t waiting_queue_lock; 

void iocontrol_init();// CALL THIS FIRST!!

#endif
