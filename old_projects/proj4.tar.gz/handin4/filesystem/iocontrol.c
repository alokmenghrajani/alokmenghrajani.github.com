/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   IOcontrol.c
*/

// Routines that handle the callback from the HD and queuing the requests

#include "../util.h"
#include "iocontrol.h"
#include "../inc/interrupts.h"
#include <oskit/c/malloc.h>
#include "../kernel.h"
#include "../inc/disk.h"
#include "../inc/x86_regs.h"
#include "../context.h"
#include <oskit/c/stdio.h>
#include "filesystem.h"


/* this function is called when the disk is done 
   it takes whats on the queue (if there is anything) and executes that.
 */
void disk_read_callback(){
  // pop the queue
  ioqueue_t * front;

  if (asych_disk_flag == 1) {
    asych_disk_flag = 0;
    return;
  }
  
  exc_lock(&waiting_queue_lock);
  front = waiting_queue;
  ASSERT(front != NULL); // make sure the queue isn't empty to begin with. Coz that would just be fucked up
  waiting_queue = waiting_queue -> next;
  
  disable_interrupts();
  // mark the pcb runnable
  front -> pcb -> state = RUNNABLE;
  front -> pcb -> flags = NORMAL;
  enable_interrupts();
  
  // call the ide_read/write_sector function for the next guy if the queue ain't empty yet.
  free(front);

  if(waiting_queue){
    if(waiting_queue -> read_write == READ){
      ide_read_sector(waiting_queue -> sector_num, waiting_queue->data, SECTORSPERBLOCK);
    }
    else{
      ide_write_sector(waiting_queue -> sector_num, waiting_queue->data, SECTORSPERBLOCK);
    }
  }
  exc_unlock(&waiting_queue_lock);

  return;
}


void disk_write_callback(){
  disk_read_callback();
  return;
}

/*
  to do a read or a write, the queue is checked if its empty,
  queue up the process making the request and call the disk primitive.
  else, queue up the request. Also, put the currentprocess to sleep!
 */
void ide_read_write_block(int sector_num, char* dest_source, int read_write){
  ioqueue_t *t,* back = malloc (sizeof(ioqueue_t));
  
  
  back->pcb = GET_PCB(get_esp());
  back -> data = dest_source;
  back -> read_write = read_write;
  back -> next = NULL;
  back -> sector_num = sector_num;
  // put yourself on the queue

  exc_lock(&waiting_queue_lock);
  t = waiting_queue;

  // stop yourself
  disable_interrupts();  
  /* Once we are marked as stopped, we are not going to be run */
  back->  pcb -> state = STOPPED;
  back->  pcb -> flags = IO_WAITING;

  
  if(t){
    while(t->next) 
      t = t->next;
    t->next = back;
  }
  else{
    waiting_queue = back;
    if(read_write == READ)
      ide_read_sector(sector_num, dest_source, SECTORSPERBLOCK);
    else 
      ide_write_sector(sector_num, dest_source, SECTORSPERBLOCK);
  }
  exc_unlock (&waiting_queue_lock);
  enable_interrupts();

  // context switch
  context_switch(-1);
}

void ide_read_block(int sector_num, char* dest){
  ide_read_write_block(sector_num, dest, READ);
}

void ide_write_block(int sector_num, char* source){
  ide_read_write_block(sector_num, source, WRITE);
}

void iocontrol_init(){
  init_lock3(&waiting_queue_lock);
}
