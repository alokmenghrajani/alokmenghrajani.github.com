/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   fs_mkfs.c
*/

#include "buffercache.h"
#include "bitvec.h"
#include "../inc/disk.h"
#include "../inc/common.h"
#include "filesystem.h"
#include "../process_file.h"

#include <oskit/c/string.h>
#include <oskit/c/stdio.h>


/* This is the format:
   0:    untouched (boot sector);
   1:    Superblock
   2-6:  bitmap_vector
   7-N:  inodes (N ~ 6+i/1k)
 N+1-oo: userblocks and block index tables
*/

// Reads the formatting stored on the disk. This function bypasses the cache, queue, etc...
// It should be called only when the kernel boots (before the first process starts to live).
int fs_readmkfs() {
  // Bypasses the cache, queue and what not...
  int i;
  int num;
  int block_num = 6;
  char* source = (char*) inodes;
  int offset;
  char data[BLOCK_SIZE];

  // Read the Superblock and check the magic number.
  // We are going to do asynchronus read using a flag.
  asych_disk_flag = 1;
  ide_read_sector(BLOCK2SECTOR(1), data, SECTORSPERBLOCK);
  while (asych_disk_flag!=0)
    ;
  memcpy(&superblock, data, sizeof(superblock_t));

  if ((superblock.max_inodes>8192) || (superblock.magic_number != 0x69696969))
    return -1;

  // Read the bitvec that tells which blocks are allocated and which ones are not.
  for(i = 0; i < BITVEC_SIZE/BLOCK_SIZE; i ++) {

    asych_disk_flag = 1;
    ide_read_sector(BLOCK2SECTOR(i+2), data, SECTORSPERBLOCK);
    while (asych_disk_flag!=0)
      ;
    memcpy(block_bitvec + i*BLOCK_SIZE, data, BLOCK_SIZE);

  }

  // Read the inodes
  num = sizeof(inode_t)*superblock.max_inodes;
  offset = MIN(num, BLOCK_SIZE);
  while(offset > 0){

    asych_disk_flag = 1;
    ide_read_sector(BLOCK2SECTOR(block_num), data, SECTORSPERBLOCK);
    while (asych_disk_flag!=0)
      ;
    memcpy(source, data, offset);

    block_num++;
    num -= offset;
    source += offset;
    offset = MIN(num, BLOCK_SIZE);
  }
  return SUCCESS;
}

// Format the HD. This function doesn't grab locks, so don't call it concurrently.
int fs_mkfs(int max) {
  int i, t;
  // Check that max_inodes is compatible with the current disk size
  // and that max_inodes is in the range 0-8192
	
  cache_init();
  superblock.max_inodes = max;
  superblock.magic_number = 0x69696969;
  i = sizeof(inode_t)*superblock.max_inodes;
  t = 6+i/BLOCK_SIZE+(i%BLOCK_SIZE==0 ? 0 : 1);

  // block_bitvec (4k) is a bit vector indicating which blocks are free, and which ones aren't.
  // first block is super block, next 4 are block_bitvec
  for (i=0; i<t; i++)
    bitmap_set(block_bitvec, i, 1);
  for (i=t; i<BITVEC_SIZE*8; i++)
    bitmap_set(block_bitvec, i, 0);

  // write the bitvec to the disk
  cache_write_block(1, (char*) &superblock, sizeof(superblock_t));
  for(i = 0; i < BITVEC_SIZE/BLOCK_SIZE; i ++)
    cache_write_block(i+2, block_bitvec + i*BLOCK_SIZE, BLOCK_SIZE);

  // First inode is the root inode. Points to an empty directory.
  inodes[0].type = DIRECTORY;
  strncpy(inodes[0].name, "root", MAXFILENAMESIZE);
  inodes[0].name[MAXFILENAMESIZE-1] = 0; // cos strncpy doesn't always zero-terminate

  inodes[0].prev_file = -1;
  inodes[0].next_file = -1;
  inodes[0].child = -1;
  inodes[0].parent = 0; //the parent of root dir is itself.
  inodes[0].block_index = -1;
	
  // Mark all other as free
  for (i=1; i<superblock.max_inodes; i++) {
    inodes[i].type = FREEINODE;
  }
  save_inodes();
  // Make sure the cache is flushed to disk.
  cache_sync();

  // set all the cur_inodes to 0
  reset_currents();
  return SUCCESS;
}

// superblock should be set before calling this function
// writes all the inodes to disk. Flush cache after wards.
void save_inodes() {
  int num = sizeof(inode_t)*superblock.max_inodes;
  int block_num = 6;
  char* source = (char*) inodes;
  int offset = MIN(num, BLOCK_SIZE);
  while(offset > 0){
    cache_write_block(block_num, source, offset);
    block_num++;
    num -= offset;
    source += offset;
    offset = MIN(num, BLOCK_SIZE);
  }

}
