/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Read_write.c
*/

#include "buffercache.h"
#include "bitvec.h"
#include "filesystem.h"
#include "../inc/common.h"
#include "../inc/interrupts.h"


#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>
#include "../process_file.h"


extern int enter_directory(int inode, int *recurse_level);
extern int find_file(int inode, char *filename);
extern int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);
extern void add_inode_to_dir(int parent, int new_inode);
extern int resolve_symlink(int inode, int *recurse_level);


extern int find_empty_inode();
extern int get_new_block();



/*
  fs_read(fd, buf, size) reads size bytes from the file pointed to be
  the file descriptor fd and puts it into buf.
 */
int fs_read(int fd, void *buf, int size){
  int block_table[BLOCK_INDEX_SIZE];
  int block_dir[BLOCK_INDEX_SIZE];
  char block [BLOCK_SIZE];
  int offset;
  int inode,blocknum;
  int BIdir_num;
  int actual_block;
  int i,index=0;
  int rights, end, filesize,t[2];


  // check if it pointsto something in the global table
  if(fd < 0 || fd > 31)
    return -1;

  /* check that the user is allowed to access that file */
  rights = get_process_fds();
  if(!((1 << fd) & rights)){
    return -1;
  }
  
  if(system_wide_fds[fd].inode == -1){
    // check that its a valid fiel descriptor
    return -1;
  }


  shared_lock(&system_wide_fds_lock);
  offset = system_wide_fds[fd].offset;
  inode =  system_wide_fds[fd].inode;

  shared_unlock(&system_wide_fds_lock);

  shared_lock(&inodes_lock);
  blocknum = inodes[inode].block_index;
  shared_unlock(&inodes_lock);


  cache_read_block(blocknum, (char*) t, 8);
  filesize = t[1];


  size = ((offset+size > filesize)? filesize-offset : size);

  end = offset + size;



  shared_lock(&(spec_in_lock[inode]));
  // get the block_dir
  cache_read_block(blocknum, (char*)block_dir, BLOCK_SIZE);  

  while(offset< end){
    //compute the block number to begin reading from.
    int  block_to_read = ((offset + BLOCK_SIZE - (offset % BLOCK_SIZE))/BLOCK_SIZE) - 1; // round down
    // compute the block index dir number
    BIdir_num = block_dir[(block_to_read /BLOCK_INDEX_SIZE) +2]; // The +1 is just to accomodate the first feild which is a counter.
    i = 1; // using as a flag

    if(BIdir_num != -1){
      // get the block_table
      cache_read_block(BIdir_num, (char*)block_table, BLOCK_SIZE);  
      
      // finally we can now get the actual page to read.
      actual_block = block_table[block_to_read % BLOCK_INDEX_SIZE];
			
      if(actual_block != -1){
	cache_read_block(actual_block, block, BLOCK_SIZE);  
				
				// copy shit from the block we just got to the actual buffer
	for(i = offset % BLOCK_SIZE; i <   BLOCK_SIZE && index < size; i ++){
	  ((char*)buf)[index] = block[i];
	  offset++;
	  index ++;
	}
	i = 0;// flag that write was made
      }
    }
    if(i){
      for(i = offset % BLOCK_SIZE; i <  BLOCK_SIZE && index <size; i ++){
	((char*)buf)[index] = 0;
	index ++;
	offset++;
      }
    }
  }
  shared_unlock(&(spec_in_lock[inode]));
  
  shared_lock(&system_wide_fds_lock);
  system_wide_fds[fd].offset = end;
  shared_unlock(&system_wide_fds_lock);

  return size;  
}
/*
  fs_write(fd, buf, size) writes size bytes from buf to the file pointed to be
  the file descriptor fd
 */

int fs_write(int fd, void *buf, int size){ 
  int block_table[BLOCK_INDEX_SIZE];
  int block_dir[BLOCK_INDEX_SIZE];
  char block [BLOCK_SIZE];
  int offset;
  int inode, blocknum;
  int BIdir_num;
  int actual_block;
  int i,index= 0;
  int rights, end,t[2];
  int originaloffset;


  if((0 > fd) || (fd > 31))
    return -1;

  /* check that the user is allowed to access that file */
  rights = get_process_fds();
  if(!((1 << fd) & rights)){
    return ERROR;
  }


  shared_lock(&system_wide_fds_lock);
  if(system_wide_fds[fd].inode == -1){
    shared_unlock(&system_wide_fds_lock);
    return ERROR;
  }

  offset = system_wide_fds[fd].offset;
  inode = system_wide_fds[fd].inode;
  end = offset + size;
  originaloffset = offset;
  system_wide_fds[fd].offset = end;

  shared_unlock(&system_wide_fds_lock);

  shared_lock(&inodes_lock);
  blocknum = inodes[inode].block_index;
  shared_unlock(&inodes_lock);


  // get the block_dir
  exc_lock(&(spec_in_lock[inode]));
  cache_read_block(blocknum, (char*)block_dir, BLOCK_SIZE);  
  

  while(offset< end){
    //compute the block number to begin writing to.
    int  block_to_write = ((offset + BLOCK_SIZE - (offset % BLOCK_SIZE))/BLOCK_SIZE) - 1; // round down

    // compute the block index dir number
    BIdir_num = block_dir[(block_to_write /BLOCK_INDEX_SIZE) +2]; // The +1 is just to accomodate the first feild which is a counter.
    i = 1; // using as a flag

    if(BIdir_num != -1){
      // get the block_table
      cache_read_block(BIdir_num, (char*)block_table, BLOCK_SIZE);  
      // finally we can now get the actual page to read.
      actual_block = block_table[block_to_write % BLOCK_INDEX_SIZE];
     
      if(actual_block != -1){

	cache_read_block(actual_block, (char*)block, BLOCK_SIZE);  
		
	for(i = offset % BLOCK_SIZE; i <  BLOCK_SIZE && index < size; i ++){
	  block[i]= ((char*)buf)[index];
	  index ++;
	  offset++;
	}
	i = 0;// flag that write was made
	cache_write_block(actual_block, (char*)block, BLOCK_SIZE);
      }
    }
    if(i){
      //get a new block
      int new_block = get_new_block();
      int j;
      if(new_block == -1){
	printf("DISKFULL!!!\n");
	break;
	
      }

      //set the buffer to zeros
      for(j = 0; j < BLOCK_SIZE; j ++)
	block[j] = 0;
      // fill in what we have of this buffer
      for(j = offset % BLOCK_SIZE; j <  BLOCK_SIZE && index < size; j ++){
	block[j]= ((char*)buf)[index];
	offset++;
	index++;
      }
      //write the new block to disc
      cache_write_block(new_block, (char*)block, BLOCK_SIZE);
      if(BIdir_num == -1){
	//get a new block for the BItable
	int new_table = get_new_block();
	if(new_block == -1){
	  //free new_block
	  exc_lock(&block_bitvec_lock);
	  bitmap_set(block_bitvec,new_block,0);
	  exc_unlock(&block_bitvec_lock);
	  printf("DISKFULL!!!\n");
	  break;
	}

	for(j = 0; j < BLOCK_INDEX_SIZE; j++)
	  block_table[j] = -1;

	// new to keep people from overwriting each other.
	/*	exc_lock(&(spec_in_lock[inode]));
		cache_read_block(blocknum, (char*)block_dir, BLOCK_SIZE); */

	block_table[block_to_write % BLOCK_INDEX_SIZE]= new_block;
	block_dir[(block_to_write /BLOCK_INDEX_SIZE) +2] = new_table;
	cache_write_block(new_table, (char*) block_table, BLOCK_SIZE);
	cache_write_block(blocknum, (char*) block_dir, BLOCK_SIZE);

	//	exc_unlock(&(spec_in_lock[inode]));
      }
      //update the tables
      else if(actual_block == -1){
	//this is new also
	//	exc_lock(&(spec_in_lock[inode]));
	//	cache_read_block(BIdir_num, (char*)block_table, BLOCK_SIZE);  

	block_table[block_to_write % BLOCK_INDEX_SIZE] = new_block;
	cache_write_block(BIdir_num, (char*)block_table, BLOCK_SIZE);

	//	exc_unlock(&(spec_in_lock[inode]));
      }

    }
  
  }

  if(offset < end){
    exc_lock(&system_wide_fds_lock);
    system_wide_fds[fd].offset =  offset;
    exc_unlock(&system_wide_fds_lock);
  }

  cache_read_block(blocknum, (char*) t, 8);
  t[1] = MAX(offset, t[1]);
  cache_write_block(blocknum, (char*) t, 8);

  exc_unlock(&(spec_in_lock[inode]));


  return (offset -originaloffset);
}

