/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Dir.c
*/

// This is the main directory handling file

#include "buffercache.h"
#include "bitvec.h"
#include "filesystem.h"
#include "../inc/common.h"
#include "../inc/interrupts.h"


#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>
#include "../process_file.h"


int enter_directory(int inode, int *recurse_level);
int find_file(int inode, char *filename);
int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);



extern int find_empty_inode();
extern int resolve_symlink(int inode, int *recurse_level);
extern int get_new_block();


#define MAX_SOFT_LINK_RECURSE_LEVEL 5

// Adds an inode to a directory (updates linked lists)
/* assume here that we have already exc locked the inodes */
void add_inode_to_dir(int parent, int new_inode) {
  // new_inode should be exc_locked.
  // Check lock here
  ASSERT(inodes_lock.flag); 
  // add yourself to list
  inodes[new_inode].next_file = inodes[parent].child;
  inodes[parent].child = new_inode;
  if (inodes[new_inode].next_file != -1) {
    inodes[inodes[new_inode].next_file].prev_file = new_inode;	
  }
  inodes[new_inode].prev_file = -1;
}

// Removes an inode from a directory. updates the linked lists.
/* assume here that we have already exc locked the inodes */
void remove_inode_from_dir(int node) {
  // Check lock here
  ASSERT(inodes_lock.flag); 
  // remove yourself from list
  // Check if you are the first element
  if (inodes[inodes[node].parent].child==node)
    inodes[inodes[node].parent].child=inodes[node].next_file;
  else {
    ASSERT(inodes[node].prev_file!=-1);
    inodes[inodes[node].prev_file].next_file = inodes[node].next_file;
  }
  // Check if you are the last element
  if (inodes[node].next_file!=-1) {
    inodes[inodes[node].next_file].prev_file = inodes[node].prev_file;
  }
}

// Finds a file in the children of inode
/* assume that we already have at least a shared lock on the inodes */
int find_file(int inode, char *filename) {
  int child;
  // if filename == "." then return inode
  // if it's ".." then return the parent
  // otherwise find the filename in the children of inode.
  // inode must be a directory.
  // if not found, return -1;
  ASSERT(inodes[inode].type==DIRECTORY);
  if (strcmp(filename, ".")==0)
    return inode;
  if (strcmp(filename, "..")==0) {
    return inodes[inode].parent;
  }
  child = inodes[inode].child;
  while (child!=-1) {
    if (strcmp(inodes[child].name, filename)==0)
      return child;
    child = inodes[child].next_file;
  }
  return -1;
}

// Resolves a pathname. Takes as input a string (and current_inode) and returns an inode corresponding
// to the last dir. Also returns the filename (as string) if any.

// return the filename in char **filename
// and inode no
// filenames / directory names larger then MAXFILENAME are truncated ! No error reported !
// returns -1 on error.

/* assume that we already have a shared lock on the inodes */
int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level) {
  int i,j, t;
  char buf[MAXFILENAMESIZE];
  // i will always point to the first character of the directory or filename being parsed.
  // so it will usually be right after the /.
  i=0;
  // See if pathname is absolute or relative
  if (pathname[0]=='/') {
    current_inode = 0; // start from root inode
    i=1; // Set i right after slash.
  }
  
  if (pathname[0]==0)
    return -1;
  while (1) {
    // test for strings like '//'
    while (pathname[i]=='/') {
      // return -1;
      i++;
    }

    // find the next slash
    for (j=i+1; (pathname[j]!='/') && (pathname[j]!=0); j++);
    if (pathname[j]==0) {
      // WE MUST COPY THE FILENAME
      strncpy(filename, &pathname[i], MIN(j-i, MAXFILENAMESIZE));
      filename[MIN(j-i, MAXFILENAMESIZE-1)]=0;
      // Make sure that filename is at most as big as MAXFILENAMESIZE+1
      return current_inode;
    } else {
      // We have a folder name from i to j-1
      strncpy(buf, &pathname[i], MIN(j-i, MAXFILENAMESIZE));
      buf[MIN(j-i, MAXFILENAMESIZE-1)] = 0;
      
      // Find the folder in the directory
      t = find_file(current_inode, buf);
      if (t==-1)
	return -1; // Folder not found
      // now resolve it if we have a symlink
      current_inode = resolve_symlink(t, recurse_level);
      if (current_inode==-1)
	return -1; // Invalid symlink
      i=j+1; // set i right after slash.
      if (pathname[i]==0) {
	// WE DON'T HAVE ANY FILENAME
	filename[0]=0;
	return current_inode;
      }
    }
  }
}

// Create a directory.
int fs_mkdir(char *pathname) {
  // strip any tailing '/'
  int t;
  int parent, new;
  char buf[MAXPATHNAMELEN];
  int recurse_level;
  // I know that pathname cannot be null (tested at syscall level)
  if (pathname[0]==0) {
    return ERROR;
  }
  strncpy(buf, pathname, MAXPATHNAMELEN);
  buf[MAXPATHNAMELEN-1] = 0;

  for (t=0; buf[t+1]!=0; t++);
  if (buf[t]=='/')
    buf[t]=0;
  // find an empty inode
  new = find_empty_inode();

  if(new == -1){
    return -1; 
  }

  exc_lock(&inodes_lock);
  recurse_level = 0;
  parent = resolve_pathname(buf, get_process_current_inode(), inodes[new].name, &recurse_level);
  if (parent==-1){
    exc_unlock(&inodes_lock);
    return -1;
  }

  // make sur parent doesn't already have this file
  if (find_file(parent, inodes[new].name)!=-1) {
    inodes[new].type = FREEINODE;
    exc_unlock(&inodes_lock);    
    return -1; // file name already taken.
  }

  // fill up structure
  inodes[new].type = DIRECTORY;
  inodes[new].child = -1;
  inodes[new].parent = parent;
  inodes[new].block_index = -1;
  add_inode_to_dir(parent, new);

  exc_unlock(&inodes_lock);
  return new;

}

// Delete a directory.
int fs_rmdir(char *pathname) {
  char buf[MAXFILENAMESIZE];
  char buf2[MAXPATHNAMELEN];
  int dir, parent, t;
  int recurse_level = 0;

  // if the format is path1/dir/ convert it to path1/dir
  if (pathname[0]==0)
    return ERROR;
  strncpy(buf2, pathname, MAXPATHNAMELEN);
  buf2[MAXPATHNAMELEN-1] = 0;

  for (t=0; buf2[t+1]!=0; t++);
  if (buf2[t]=='/')
    buf2[t]=0;
  exc_lock(&inodes_lock);
  parent = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);

  if (parent==-1){
    exc_unlock(&inodes_lock);
    return ERROR; // directory not found
  }
  dir = find_file(parent, buf);
  if (dir==-1){
    exc_unlock(&inodes_lock);
    return ERROR; // directory not found
  }
  if (dir==0){
    exc_unlock(&inodes_lock);
    return ERROR; // Disallow remove the root directory !
  }
  if (inodes[dir].type != DIRECTORY){
    exc_unlock(&inodes_lock);
    return ERROR; // not a directory  (We do not accept symlinks here)
  }
  if (inodes[dir].child != -1){
    exc_unlock(&inodes_lock);
    return ERROR; // not empty
  }
  remove_inode_from_dir(dir);
  exc_unlock(&inodes_lock);
  return SUCCESS;
}


// Changes the process' directory.
int fs_chdir(char *pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int dir;

  shared_lock (&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock(&inodes_lock);
    return -1;
  }

  if (buf[0]!=0) { // case where pathname is /path1/dir
    // CHECK FOR dir to be a directory
    int t = find_file(dir, buf);
    if (t==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
  }
  shared_unlock(&inodes_lock);

  // otherwise if pathname is /path1/dir/ no need to change anything
  if(inodes[dir].type == DIRECTORY){
    set_process_current_inode(dir);
    return 0;
  }
  return -1;
}

// returns the size of directory (number of files inside)
int fs_dirsize(char *pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int t, n;
  int dir;
  shared_lock(&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock(&inodes_lock);
    return -1;
  }
  if (buf[0]!=0) {
    t = find_file(dir, buf);
    if (t==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
  }
  if (inodes[dir].type != DIRECTORY)
    return 0;
  /* calculate number of children */
  t = inodes[dir].child;
  n = 0;
  while (t!=-1) {
    t = inodes[t].next_file;
    n++;
  }
  shared_unlock(&inodes_lock);

  return n+2;
}

// returns entry in directory.
int fs_direntry(char *pathname, int entrypos, char *entryname) {
  char buf[MAXFILENAMESIZE];
  int child, i;
  int recurse_level=0;
  int dir;
  shared_lock (&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock (&inodes_lock);
    return -1;
  }
  if (buf[0]!=0) {
    int t = find_file(dir, buf);
    if (t==-1){
      shared_unlock (&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock (&inodes_lock);
      return -1;
    }
  }
  if (entrypos==0) {
    strcpy(entryname, ".");
    shared_unlock (&inodes_lock);
    return 0;
  }
  if (entrypos==1) {
    strcpy(entryname, "..");
    shared_unlock (&inodes_lock);
    return 0;
  }
  child = inodes[dir].child;
  if (child==-1) {
    // Entry pos too large
    return -1;
  }
  for (i=0; i<(entrypos-2); i++) {
    child = inodes[child].next_file;
    if (child==-1) {
      // Entry pos too large
      return -1;
    }
  }

  strncpy(entryname, inodes[child].name, MAXFILENAMESIZE);
  entryname[MAXFILENAMESIZE-1]=0;
  shared_unlock (&inodes_lock);
  return 0;
}
