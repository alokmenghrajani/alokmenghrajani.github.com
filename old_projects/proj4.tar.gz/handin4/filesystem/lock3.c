/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Lock3.c
*/

// locks used by the file system

#include "lock3.h"
#include "../inc/common.h"

#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>


#include "../kernel.h"
#include "../inc/x86_regs.h"

#include "../context.h"
#include "../inc/interrupts.h"


/* the anames of each of these functions explains exactl what they do.
   the locks are three state locks, shared, exc and unlocked.
   any number of processes can hodl a shared lock. 
   One process can hold an exc lock (when nobody is sharing it).
*/


void init_lock3(lock3_t* lock){
  lock -> flag = 0;
  lock -> counter = 0;
  //  lock -> pid = 0;
}

void shared_lock(lock3_t* lock){
  int locked = 0;
  int deadlock_det = 0;
  while(!locked){
    disable_interrupts();
    if(lock -> flag == 0){
      (lock -> counter)++;
      locked = 1;  
      enable_interrupts();
      return;
    }
    enable_interrupts();
    context_switch(-1);
    deadlock_det++;
    if (deadlock_det==10000000) {
      printf("Potential deadlock %x!\n", (int) lock);
    }
  }
}


void shared_unlock(lock3_t* lock){
  disable_interrupts();
  (lock->counter)--;
	ASSERT(lock->counter>=0);
  enable_interrupts();
}

void exc_lock(lock3_t* lock){
  int locked = 0;
  int deadlock_det = 0;
  //  pcb_struct * pcb = GET_PCB(get_esp());

  while(!locked){
    disable_interrupts();
    if(lock -> flag == 0 && lock -> counter ==0){
      locked = 1;
      lock -> flag = 1;
      //      lock ->pid = pcb ->pid;
      enable_interrupts();
      return;
    }
    enable_interrupts();
    context_switch(-1);
    deadlock_det++;
    if (deadlock_det==10000000) {
      printf("Potential deadlock %x!\n", (int)lock);
    }
  }

}

void exc_unlock(lock3_t* lock){
  disable_interrupts();
  ASSERT(lock->flag == 1);
  ASSERT(lock->counter == 0);
  lock->flag = 0;
  //  lock -> pid = 0;
  enable_interrupts();
}

// Get an exc_lock if possible, otherwise return 0 (doesn't block)
int exc_lock_maybe(lock3_t* lock) {
  //  pcb_struct * pcb = GET_PCB(get_esp());
  disable_interrupts();
  if (lock->flag == 0 && lock->counter == 0) {
    lock->flag = 1;
    //    lock -> pid = pcb -> pid;
    return 1;
  }
  return 0;
  enable_interrupts();
}


// take an exc locked lock andmake it shared.
void demote_lock(lock3_t* lock) {
  disable_interrupts();
  ASSERT(lock->flag == 1);
  ASSERT(lock->counter == 0);
  lock->flag = 0;
  lock->counter = 1;
  //  lock -> pid = 0;  
  enable_interrupts();
}


