/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Filesystem.c
*/

// The main filesystem file.


#include "buffercache.h"
#include "bitvec.h"
#include "filesystem.h"
#include "../inc/common.h"
#include "../inc/interrupts.h"


#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>
#include "../process_file.h"


extern int enter_directory(int inode, int *recurse_level);
extern int find_file(int inode, char *filename);
extern int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);
extern void add_inode_to_dir(int parent, int new_inode);
extern int resolve_symlink(int inode, int *recurse_level);
extern int check_open(int n);

int find_empty_inode();
int get_new_block();

/* This function must be called before anything else is, */
void fs_init() {
  int i;
  // Init locks
  // and also check the disk to see if there is a formatted fs.
  init_lock3(&link_lock);
  init_lock3(&inodes_lock);
  init_lock3(&block_bitvec_lock);
  init_lock3(&system_wide_fds_lock);


  for(i = 0; i < SYS_MAX_OPEN_FILES; i++)
    system_wide_fds[i].inode = -1;

  for(i = 0; i < MAX_FILES; i++)
    init_lock3(&(spec_in_lock[i]));
}

/* assume that we have NOT locked the inodes 
   gives the next available inode (if we have any left).
*/
int find_empty_inode() {
  int i;

  for (i=0; i<superblock.max_inodes; i++) {
    exc_lock (&inodes_lock);
    if (inodes[i].type == FREEINODE) {
      inodes[i].type = USEDINODE;
      exc_unlock (&inodes_lock);     
      return i;
    }
    exc_unlock (&inodes_lock);       // release lock
  }
  return -1;
}



/* assumes that system_wide_fds_lock is exclusively held. 
   Next available filedescriptor (if we have any left).
 */
int get_next_fd(){
  int i = 0;
  while (i<SYS_MAX_OPEN_FILES){
    if(system_wide_fds[i].inode == -1){
      return i;
    }
    i ++;
  }
  return ERROR;
}


/*
  fs_create (filename) creates a filen in the appropriate directory
  as specified by filename.
 */

int fs_create(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent_dir;

  if(new_inode == -1){
    return -1;
  }
  
  exc_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, inodes[new_inode].name, &recurse_level);

  if(parent_dir == -1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return ERROR;
  }
  
  if(inodes[new_inode].name[0] == 0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return ERROR;
  }

  if(find_file(parent_dir, inodes[new_inode].name) == -1) {
    int buffer[BLOCK_INDEX_SIZE]; // This is because we have the entries in the block index dir as ints.
    int new_block = get_new_block();
    inode_t * inode = &inodes[new_inode]; // get a pointer to the inode that we want. 
    int i, fdnum;
    if(new_block == -1){
      printf("DISKFULL!!!\n");
      inodes[new_inode].type = FREEINODE;
      exc_unlock(&inodes_lock);
      return -1;
    }
    
    buffer[0] = 2; // This is the counter as the number of hard links to this file. One for the link and the other for the fd
    buffer[1] = 0; //set the initial size to 0
    for(i = 2; i< BLOCK_INDEX_SIZE; i++)
      buffer[i] = -1;
    
    inode->type = NORMALFILE;
    //    inode->filesize = 0; // Thisisn't necessary!!
    
    /* insert this new file into the parent's list */
    add_inode_to_dir(parent_dir, new_inode);    

    /* set the data in the inode */
    inode->parent = parent_dir;
    inode->child = -1;
    inode->block_index = new_block;
    exc_unlock(&inodes_lock);    
    cache_write_block(new_block, (char*)buffer, BLOCK_SIZE);
    
    exc_lock(&system_wide_fds_lock);    

    fdnum = get_next_fd();
    if(fdnum == ERROR){
      exc_unlock(&system_wide_fds_lock);    
      exc_lock(&inodes_lock);
      inodes[new_inode].type = FREEINODE;
      exc_unlock(&inodes_lock);

      exc_lock(&block_bitvec_lock);
      bitmap_set(block_bitvec, new_block, 0);
      exc_unlock(&block_bitvec_lock);

      return ERROR;
    }
    system_wide_fds[fdnum].inode = new_inode;
    system_wide_fds[fdnum].offset = 0;
    system_wide_fds[fdnum].counter = 1;
    exc_unlock(&system_wide_fds_lock);    

    i = get_process_fds();
    set_process_fds(i | 1 << fdnum);
    
    return fdnum;
  }
  inodes[new_inode].type = FREEINODE;
  exc_unlock(&inodes_lock);    
  return ERROR;
}


/*
  fs_open(filename) opens a file specified byfilename andreturns a filedescriptor to it.
 */

int fs_open(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  char filename[MAXFILENAMESIZE];
  int inode,filetype, blocknum;
  int parent_dir;
  
  shared_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, filename, &recurse_level);
  shared_unlock(&inodes_lock);
    
  if(filename[0] == 0) {
    // bad filename
    return ERROR;
  }

  if(parent_dir == -1) {
    // no such dir
    return ERROR;
  }

  if((inode = find_file(parent_dir, filename)) != -1){
    // make sure the file exists.
    int i, fdnum;
    int t =0;
    inode = resolve_symlink(inode, &t);
    if (inode==-1) {
      return ERROR;
    }
    exc_lock(&system_wide_fds_lock);
    fdnum = get_next_fd();
    if(fdnum == ERROR){
      // too many open files
      exc_unlock(&system_wide_fds_lock);
      return ERROR;
      
    }

    shared_lock(&inodes_lock);
    filetype = inodes[inode].type;
    blocknum = inodes[inode].block_index;
    shared_unlock(&inodes_lock);
    
    if(filetype == NORMALFILE){
      // increment the ref count.
      int t;
      ASSERT(blocknum!=-1);
      exc_lock(&link_lock);
      cache_read_block(blocknum, (char*) &t, 4);
      t++;
      cache_write_block(blocknum, (char*) &t, 4);
      exc_unlock(&link_lock);
    }

    system_wide_fds[fdnum].inode = inode;
    system_wide_fds[fdnum].offset = 0;
    system_wide_fds[fdnum].counter = 1;
    exc_unlock(&system_wide_fds_lock);
    i = get_process_fds();
    set_process_fds(i | 1 << fdnum);
        
    return fdnum;
  }   
  // no such file in this dir
  return ERROR;
}


/*
  fs_close(fd) closes the fdth filedescriptor in the system wide table
 */
int fs_close(int fd){ 
  int i;
  int rights = get_process_fds();
  int inode,filetype, blocknum;
  if(!((1 << fd) & rights))
    return ERROR;
  shared_lock(&system_wide_fds_lock);
  if(fd >= 32 || system_wide_fds[fd].inode == -1){
    shared_unlock(&system_wide_fds_lock);
    return ERROR;
  }
  shared_unlock(&system_wide_fds_lock);

  i = get_process_fds();
  set_process_fds(i & (~(1 << fd)));
  
  exc_lock(&system_wide_fds_lock);
  system_wide_fds[fd].counter --;
  if(system_wide_fds[fd].counter){
    // if there are more processes using it, don't delete it.
    exc_unlock(&system_wide_fds_lock);
    return SUCCESS;
  }
  
  inode = system_wide_fds[fd].inode;

  shared_lock(&inodes_lock);
  filetype = inodes[inode].type;
  blocknum = inodes[inode].block_index;
  shared_unlock(&inodes_lock);
  
  if(filetype == NORMALFILE){
    // increment the ref count.
    int t;
    ASSERT(blocknum!=-1);
    exc_lock(&link_lock);
    cache_read_block(blocknum, (char*) &t, 4);
    t--;
    if (t==0) {
      // optimization: tell the cache that these blocks are no more allocated
      // this way if the block is dirty, it won't be rewritten.
      // DELETE the block index directory, block indexes and blocks
      int i, j;
      int buffer1[BLOCK_INDEX_SIZE];
      int buffer2[BLOCK_INDEX_SIZE];
      
      cache_read_block(blocknum, (char*) buffer1, BLOCK_SIZE);
      for (i=2; i<BLOCK_INDEX_SIZE; i++) {
        // we can have holes in our block index table
	if (buffer1[i]==-1)
	  continue;
	cache_read_block(buffer1[i], (char*) buffer2, BLOCK_SIZE);
	for (j=0; j<BLOCK_INDEX_SIZE; j++) {
	  if (buffer2[j]==-1)
	    continue;
	  exc_lock(&block_bitvec_lock);
	  bitmap_set(block_bitvec, buffer2[j], 0);
	  exc_unlock(&block_bitvec_lock);
	}
	exc_lock(&block_bitvec_lock);
	bitmap_set(block_bitvec, buffer1[i], 0);
	exc_unlock(&block_bitvec_lock);
      }
      exc_lock(&block_bitvec_lock);
      bitmap_set(block_bitvec, blocknum, 0);
      exc_unlock(&block_bitvec_lock);
      
      inodes[inode].type = FREEINODE;

    } else {
      cache_write_block(blocknum, (char*) &t, 4);
    }
    exc_unlock(&link_lock);
  }
  
  system_wide_fds[fd].inode = -1;
  exc_unlock(&system_wide_fds_lock);

  return SUCCESS;
}


/*
  if the process hasaccess to the fdth filedescriptor in 
  the flobal table, set the offset in it.
 */
int fs_seek(int fd, int offset){ 
  /* check that the user is allowed to access that file */
  int rights = get_process_fds();
  int inode, t[2],blockn;
  if(!((1 << fd) & rights))
    return ERROR;

  if(offset < 0) return ERROR;

  exc_lock(&system_wide_fds_lock);
  system_wide_fds[fd].offset = offset;
  inode = system_wide_fds[fd].inode;
  exc_unlock(&system_wide_fds_lock);

  exc_lock(&inodes_lock);
  blockn = inodes[inode].block_index;
  exc_unlock(&inodes_lock);

  //Increase the size of the file if required.
  cache_read_block(blockn, (char*) t, 8);
  t[1] = MAX(offset, t[1]);
  cache_write_block(blockn, (char*) t, 8);


  return offset;
}

int fs_filesize(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  char filename[MAXFILENAMESIZE];
  int parent_dir;
  int inode,t,t1[2];
  shared_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, filename, &recurse_level);

  if(filename[0] == 0) {
    shared_unlock(&inodes_lock);
    return ERROR;
  }

  if(parent_dir == -1) {
    shared_unlock(&inodes_lock);
    return ERROR;
  }

  if((inode = find_file(parent_dir, filename)) == -1){
    shared_unlock(&inodes_lock);
    return ERROR;
  }
  
  t=0;
  inode = resolve_symlink(inode, &t);
  if (inode==-1) {
    shared_unlock(&inodes_lock);
    return ERROR;
  }

  if(inodes[inode].type != NORMALFILE){
    shared_unlock(&inodes_lock);
    return ERROR;
  }

  if (inode == -1) {
    shared_unlock(&inodes_lock);
    return ERROR;
  }
  shared_unlock(&inodes_lock);
  cache_read_block(inodes[inode].block_index, (char*) t1, 8);

  return t1[1];
}

int fs_sync(){
  int i;

  exc_lock(&inodes_lock);
  save_inodes();
  shared_lock(&block_bitvec_lock);
  for(i = 0; i < BITVEC_SIZE/BLOCK_SIZE; i ++)
    cache_write_block(i+2, block_bitvec + i*BLOCK_SIZE, BLOCK_SIZE);
  cache_sync();
  shared_unlock(&block_bitvec_lock);
  exc_unlock(&inodes_lock);

  return SUCCESS;
}

/*
  returns the path name of the current directory of a process.
 */
int fs_pwd(char* buf){
  int curr = get_process_current_inode(), pos = MAXPATHNAMELEN -1,i ;
  int total_len= 0;

  do{
    int len = strlen(inodes[curr].name);
    strncpy(buf + pos -len, inodes[curr].name, len);
    pos -= len;
    total_len += len;
    curr = inodes[curr].parent;
    // adding the slashes
    buf[--pos] = '/';
    total_len++;
  }  while(curr != 0 && pos >= 0);
  if(pos < 0){
    printf(" pathname too long \n");
    return -1; //path longer than MAXPATHNAMELEN
  }
  for(i = 0; i < total_len; i++){
    buf[i] = buf[i+pos];
  }
  buf[total_len] = NULL;

  return (total_len);
}


/* when a process exits, all the filedescriptors in it needto be
   closed
*/

void close_fds(){
  int i, open = get_process_fds();
  exc_lock(&system_wide_fds_lock);
  for(i = 0; i < 32; i++){
    if(open & (1 << i)){
      system_wide_fds[i].counter--;
      if(system_wide_fds[i].counter == 0){
	system_wide_fds[i].inode = -1;
	system_wide_fds[i].offset = 0;
      }
    }
  }
  exc_unlock(&system_wide_fds_lock);
}


/*
  when a process forks, the counters in all the file descriptors
  need to be incremented.
 */
void fd_update(){
  int i, open = get_process_fds();
  exc_lock(&system_wide_fds_lock);
  for(i = 0; i < 32; i++){
    if(open & (1 << i)){
      system_wide_fds[i].counter++;
    }
  }
  exc_unlock(&system_wide_fds_lock);
}

/*
  get_new_block returns a new block number that hasn't been allocated yet.
*/
int get_new_block() {
  int i;
  for (i=5; i<BITVEC_SIZE*8; i++) { //!!! bitvec_size is the number of chars not bits!!!
    exc_lock(&block_bitvec_lock);
    if (bitmap_test(block_bitvec,i) == 0) {
      bitmap_set(block_bitvec,i,1);
      exc_unlock(&block_bitvec_lock);
      return i;
    }
    exc_unlock(&block_bitvec_lock);
  }
  // DISK FULL!!!
  return -1;
}

