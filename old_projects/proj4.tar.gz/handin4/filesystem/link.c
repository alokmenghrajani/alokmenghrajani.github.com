/*
   15-412 OS - Proj 4
   Vikram (vikramm@andrew.cmu.edu)
   & Alok (amenghra@andrew.cmu.edu)

   Link.c
*/
   
#include "buffercache.h"
#include "bitvec.h"
#include "filesystem.h"
#include "../inc/common.h"
#include "../inc/interrupts.h"


#include <oskit/c/stdio.h>
#include <oskit/c/string.h>
#include <oskit/lmm.h>
#include "../process_file.h"


int enter_directory(int inode, int *recurse_level);
int find_file(int inode, char *filename);
int find_empty_inode();

extern int get_new_block();
extern void add_inode_to_dir(int parent, int new_inode);
extern void remove_inode_from_dir(int node);
extern int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);


#define MAX_SOFT_LINK_RECURSE_LEVEL 5


// Takes an inode and resolves the symlink if it is a symlink.
/* assume that we already have at least a shared lock on the inodes. */
/* Takes a symlink and returns the inode pointed by it. */
/* If the inode in input is not a symlink, the function returns */
int resolve_symlink(int inode, int *recurse_level) {
  ASSERT(inode!=-1);
  if (inodes[inode].type==SOFTLINK) {
    int t;
    char buf[MAXFILENAMESIZE];
    char pathname[MAXPATHNAMELEN];
    (*recurse_level)++;
    if (*recurse_level>MAX_SOFT_LINK_RECURSE_LEVEL)
      return -1; // max recurse level reached
    /* Read the pathname */
    ASSERT(inodes[inode].block_index != -1);
    cache_read_block(inodes[inode].block_index, pathname, MAXPATHNAMELEN);
    
    t = resolve_pathname(pathname, inodes[inode].parent, buf, recurse_level);
    // now we either have no filename, in which case return t
    // or we try to enter the file (might be symlink too)
    if (buf[0]==0)
      return t;
    t = find_file(t, buf);
    if (t==-1)
      return -1;
    return resolve_symlink(t, recurse_level);
  }
  return inode;
}


// Creates a symlink
int fs_symlink(char *oldname, char *newname) {
  // check that new name doesn't exist:
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent;
  int new_block;

  if(new_inode == -1){
    return -1;
  }

  exc_lock(&inodes_lock);

  parent = resolve_pathname(newname, get_process_current_inode(), inodes[new_inode].name, &recurse_level);
  if (parent==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    printf("invalid pathname to symlink\n");
    return -1; // pathname invalid
  }
  if (inodes[new_inode].name[0]==0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    printf("No filename supplied\n");
    return -1; // No filename supplied
  }
  // Check file name doesn't exist:
  if (find_file(parent, inodes[new_inode].name)!=-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    printf("file [%s] exists\n",  inodes[new_inode].name);
    return -1;  // file exists
  }
  // create symlink
  inodes[new_inode].type = SOFTLINK;
//  strncpy(inodes[new_inode].symlink, oldname, MAXFILENAMESIZE);
//  inodes[new_inode].symlink[MAXFILENAMESIZE-1]=0;
  new_block = get_new_block();   // HOW DO WE REACT ON OUT OF MEMORY ??? FIXME
  if(new_block == -1){
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    printf("DISKFULL!!!\n");
    return -1;
  }
  inodes[new_inode].block_index = new_block;
  inodes[new_inode].child = -1;
  inodes[new_inode].parent = parent;
  add_inode_to_dir(parent, new_inode);
  cache_write_block(new_block, oldname, strlen(oldname)+1);
  exc_unlock(&inodes_lock);
  return new_inode;
}

// create a link
int fs_link(char *oldname, char *newname) {
  // check that the new name doesn't exist:
  char buf[MAXFILENAMESIZE];
  int source;
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent;
  

  if(new_inode == -1){
    return -1;
  }

  exc_lock(&inodes_lock);  

  parent = resolve_pathname(newname, get_process_current_inode(), inodes[new_inode].name, &recurse_level);
  if (parent==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // pathname invalid
  }
  if (inodes[new_inode].name[0]==0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // No filename supplied
  }
  // Check file name doesn't exist:
  if (find_file(parent, inodes[new_inode].name)!=-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1;  // file exists
  }
  // create hardlink
  recurse_level = 0;
  source = resolve_pathname(oldname, get_process_current_inode(), buf, &recurse_level);
  if (source==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1;
  }
  if (buf[0]!=0) {
    source = find_file(source, buf);
    if (source == -1){
      inodes[new_inode].type = FREEINODE;      
      exc_unlock(&inodes_lock);  
      return -1;
    }
  }
  if (inodes[source].type == DIRECTORY){
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // We don't allow hardlink on directories.
  }
  if (inodes[source].type == SOFTLINK) {
    int new_block = get_new_block();   // HOW DO WE REACT ON OUT OF MEMORY ??? FIXME
    char pathname[MAXPATHNAMELEN];
    int t;

    if(new_block == -1){
      inodes[new_inode].type = FREEINODE;
      exc_unlock(&inodes_lock); 
      printf("DISKFULL!!!\n");
      return -1;
    }

    // Read the pathname
    t = inodes[source].block_index;
    exc_unlock(&inodes_lock);
    cache_read_block(t, pathname, MAXPATHNAMELEN);
    exc_lock(&inodes_lock);

    inodes[new_inode].block_index = new_block;
    inodes[new_inode].type = SOFTLINK;
//    strncpy(inodes[new_inode].symlink, inodes[source].symlink, MAXPATHNAMELEN);
//    inodes[new_inode].symlink[MAXPATHNAMELEN-1]=0;
    cache_write_block(new_block, pathname, MAXPATHNAMELEN);
  } else {
    int t;
    ASSERT(inodes[source].type == NORMALFILE);
    inodes[new_inode].type = NORMALFILE;
    //    inodes[new_inode].filesize = inodes[source].filesize;
    inodes[new_inode].block_index = inodes[source].block_index;
    // Increment counter
    exc_lock(&link_lock);
    exc_unlock(&inodes_lock);
    cache_read_block(inodes[new_inode].block_index, (char*) &t, 4);
    t++;
    cache_write_block(inodes[new_inode].block_index, (char*) &t, 4);
    exc_lock(&inodes_lock);
    exc_unlock(&link_lock);
  }
  inodes[new_inode].child = -1;
  inodes[new_inode].parent = parent;
  add_inode_to_dir(parent, new_inode);
  
  exc_unlock(&inodes_lock);  
  return new_inode;
}

/*
  returns non zero if the file with inode n is open, ie. has an entry in the global
  descriptor table.
*/

int check_open(int n){
  int i;
  exc_lock(&system_wide_fds_lock);
  for(i=0; i < MAX_OPEN_FILE; i ++)
    if(system_wide_fds[i].inode == n){
      exc_unlock(&system_wide_fds_lock);
      return 1;
    }
  exc_unlock(&system_wide_fds_lock);
  return 0;
}

// delete a file
int fs_unlink(char* pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int file;
  int dir, filetype, blocknum;
  exc_lock(&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);


  if (dir==-1){
    exc_unlock(&inodes_lock);
    return -1; // path unresolved
  }
  file = find_file(dir, buf);
  if (file==-1){
    exc_unlock(&inodes_lock);
    return -1; // file not found
  }

  if (inodes[file].type == DIRECTORY){
    exc_unlock(&inodes_lock);
    return -1; // invalid type
  }

  // if it's a hardlink decrement the counter
  // and free the block directory and blocks if need be
  filetype = inodes[file].type;
  blocknum = inodes[file].block_index;
  remove_inode_from_dir(file);

  if(!(check_open(file)))
    inodes[file].type = FREEINODE;

  exc_unlock(&inodes_lock);
    
  if (filetype == NORMALFILE) {
    int t;

    // if it's not a softlink, it's a hardlink.
    ASSERT(blocknum!=-1);
    exc_lock(&link_lock);
    cache_read_block(blocknum, (char*) &t, 4);
    t--;
    if (t==0) {
      // optimization: tell the cache that these blocks are no more allocated
      // this way if the block is dirty, it won't be rewritten.
     
      // DELETE the block index directory, block indexes and blocks
      int i, j;
      int buffer1[BLOCK_INDEX_SIZE];
      int buffer2[BLOCK_INDEX_SIZE];
     
      cache_read_block(blocknum, (char*) buffer1, BLOCK_SIZE);
      for (i=2; i<BLOCK_INDEX_SIZE; i++) {
        // we can have holes in our block index table
	if (buffer1[i]==-1)
	  continue;
	cache_read_block(buffer1[i], (char*) buffer2, BLOCK_SIZE);
	for (j=0; j<BLOCK_INDEX_SIZE; j++) {
	  if (buffer2[j]==-1)
	    continue;
	  exc_lock(&block_bitvec_lock);
	  bitmap_set(block_bitvec, buffer2[j], 0);
	  exc_unlock(&block_bitvec_lock);
	}
	exc_lock(&block_bitvec_lock);
	bitmap_set(block_bitvec, buffer1[i], 0);
	exc_unlock(&block_bitvec_lock);
      }
      exc_lock(&block_bitvec_lock);
      bitmap_set(block_bitvec, blocknum, 0);
      exc_unlock(&block_bitvec_lock);
    } else {
      cache_write_block(blocknum, (char*) &t, 4);
    }
    exc_unlock(&link_lock);
  }

  return 0;
}
