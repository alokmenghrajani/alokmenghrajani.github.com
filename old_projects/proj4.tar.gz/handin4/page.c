/*

  page.c: All the paging goodness happens here.
  
  Authors: Alok Menghrajani & Vikram Manjunath

  Note: we use a bytearray to keep track of unsused frames.
  
 */

#include "page.h"
#include "util.h"
#include "kernel.h"
#include <oskit/c/malloc.h>
#include "inc/interrupts.h"
#include "idt.h"
#include "inc/seg.h"
#include "inc/x86_regs.h"
#include "syscalls/syscalls.h"

/* Number of available page is memory in machine minus 16MB allocated for the 
   kernel */
#define TOTAL_PAGES ((MACHINE_MEMORY_SIZE_MB - 16)* 1024 * 1024 / PAGE_SIZE)
#define FREE 0
#define ALLOCATED 1

#define PTD_INDEX(a) (((int)(a)>>22) & 0x3FF)  // Get highest 10 bits
#define PT_INDEX(a) (((int)(a)>>12) & 0x3FF)   // Get mid 10 bits
#define ADDRESS_FROM_INDEX(a) ((a) * PAGE_SIZE + 16 * 1024 * 1024)
#define BITMAP_INDEX(a) (((a) - 16 * 1024 * 1024) / PAGE_SIZE)


int pages_available;
char memory_bitmap[TOTAL_PAGES];


/* This function must be called in order to initialize paging.
   It installs the page fault handler and initializes the datstructures
   required for paging
*/
ptd_struct* page_init() {
  int i,j;
  struct idt_entry *entry;
  void* idt=sidt();
  ptd_struct* ptd;
  pt_struct* pt;

  pages_available = TOTAL_PAGES;

  for (i=0; i<TOTAL_PAGES; i++) {
    memory_bitmap[i] = FREE;
  }
  
  // install the page_fault_handler
  entry = (struct idt_entry*) idt;
  entry+=14;
  entry->hoffset = ((unsigned short int)(((unsigned int)page_fault_handler_wrapper)>>16));
  entry->P = 1;
  entry->DPL = 0;
  entry->D = 0xF;
  entry->Ze = 0;
  entry->Seg = KERNEL_CS;
  entry->loffset = (unsigned short int) page_fault_handler_wrapper;

  // Get a page which will be the first page table dir.
  ptd = (ptd_struct*) smemalign(PAGE_SIZE, PAGE_SIZE);

  //make sure that smemalign worked
  if (ptd==NULL) {
    return NULL;
  }
  /* Now, we map the first four entries in the ptd as  the bottom 16 megs of
     EVERY address spacs. This is the kernel mem. */
  for (i=0; i<4; i++) { 
    ptd[i].p = 1;
    ptd[i].rw = 1;
    ptd[i].us = 0;
    ptd[i].pwt = 0;
    ptd[i].pcd = 0;
    ptd[i].a = 0;
    ptd[i].z = 0;
    ptd[i].ps = 0;
    
  }
  // mark all other entries as not present
  for (i=5; i<PAGE_TABLE_SIZE; i++) {
    ptd[i].p = 0;
  }

  // Create four page tables to map the bottom 16 MB
  for (i=0; i<4; i++) {
    pt = (pt_struct*) smemalign(PAGE_SIZE, PAGE_SIZE);

    //make sure that smemalign worked
    if (pt==NULL)
      return NULL;
    // Enter the page table in the directory
    ptd[i].base = (int) pt >> 12;
    /* initialize the values in the page table*/
    for (j=0; j<PAGE_TABLE_SIZE; j++) {
      pt[j].p = 1;
      pt[j].rw = 1; 
      pt[j].us = 0;
      pt[j].pwt = 0;
      pt[j].pcd = 0;
      pt[j].a = 0;
      pt[j].d = 0;
      pt[j].pat = 0;
      pt[j].g = 1;     // We don't want these page_tables to be flushable.
      pt[j].base = (PAGE_TABLE_SIZE * i + j) * PAGE_SIZE >> 12;
    }
  }

  // set the cr3
  set_cr3((int) ptd ); // We don't need to clear the bit 3 & 4 of cr3 since the lower bits of ptd are already 0
  // The the PG (paging flag), bit 31 of CR0

  SET_PG;
//  i = (int) (*(int*)10);
  // Enable global pages, bit 7 of CR4
  i = get_cr4();
  set_cr4(i | (1 << 7));

  return ptd;
}


/*
  page_get_new gets a new page corresponding to the virt. address  virtual_addr
  and puts it in ptd.
 */

int page_get_new(ptd_struct* ptd, mem_t virtual_addr) {
  int i;
  int physical_addr;
  pt_struct* pt;
 
  /* make sure that we have pages to allocate */
  if (pages_available==0)
    return -1;
  if(virtual_addr < 0x1000000)
    printf("asdasdsa!!!! WHAT THE FUCK??!?!?!?\n");
  ASSERT((unsigned int)virtual_addr>=0x1000000);


  if(ptd == NULL)
    return -1;

  disable_interrupts();
  /* Find first free frame */
  for (i=0; memory_bitmap[i]!=FREE; i++);
  memory_bitmap[i] = ALLOCATED;
  pages_available--;
  enable_interrupts();

  /* compute what the physical address of the new frame is */
  physical_addr = ADDRESS_FROM_INDEX(i);

  /* Add the page in the ptd */
  if (ptd[PTD_INDEX(virtual_addr)].p == 0) {
    /* We need to allocate a page table */
    disable_interrupts();

    /* allocate a new page table, if necessary*/
    pt = (pt_struct*) smemalign(PAGE_SIZE, PAGE_SIZE);
    enable_interrupts();

    /* Make sure that smemalign didn't barf */
    if (pt==NULL) {
      disable_interrupts();
      memory_bitmap[i] = FREE;
      pages_available++;
      enable_interrupts();
      return -1;
    }
    for(i = 0; i < PAGE_TABLE_SIZE; i++)
      pt[i].p = 0;
    ptd[PTD_INDEX(virtual_addr)].p = 1;
    ptd[PTD_INDEX(virtual_addr)].rw = 1;
    ptd[PTD_INDEX(virtual_addr)].us = 1;
    ptd[PTD_INDEX(virtual_addr)].pwt = 0;
    ptd[PTD_INDEX(virtual_addr)].pcd = 0;
    ptd[PTD_INDEX(virtual_addr)].a = 0;
    ptd[PTD_INDEX(virtual_addr)].z = 0;
    ptd[PTD_INDEX(virtual_addr)].ps = 0;
    ptd[PTD_INDEX(virtual_addr)].base = (int)pt >> 12;
  } else {
    pt = (pt_struct*) ((int) ptd[PTD_INDEX(virtual_addr)].base << 12);
    ASSERT(pt[PT_INDEX(virtual_addr)].p == 0);
  }
  pt[PT_INDEX(virtual_addr)].p = 1;
  pt[PT_INDEX(virtual_addr)].rw = 1;
  pt[PT_INDEX(virtual_addr)].us = 1;
  pt[PT_INDEX(virtual_addr)].pwt = 0;
  pt[PT_INDEX(virtual_addr)].pcd = 0;
  pt[PT_INDEX(virtual_addr)].a = 0;
  pt[PT_INDEX(virtual_addr)].d = 0;
  pt[PT_INDEX(virtual_addr)].pat = 0;
  pt[PT_INDEX(virtual_addr)].g = 0;
  pt[PT_INDEX(virtual_addr)].base = physical_addr >> 12;
//  printf("Allocating ptd=%x, pt=%x, virtual=%x, physical=%x\n", (int) ptd, (int) pt, (int) virtual_addr, (int) physical_addr);
  return 0;
}


/*
  sometimes, a time comes when you just have to set a page table directory down.
  And when that time comes, you should call this function.
  It goes through each entry in the directory and then each entry in that table.
  It frees all the frames in that page table and then frees that page table.
  finally, We free the page table dir.
 */
void page_ptd_purge(ptd_struct* ptd) {
  int i, j, addr;
  pt_struct *pt;

  if(ptd == NULL)
    return;

  for (i=4; i<PAGE_TABLE_SIZE; i++) {
    if (ptd[i].p == 1) {
      pt = (pt_struct*)((int)ptd[i].base << 12);
      for (j=0; j<PAGE_TABLE_SIZE; j++) {
	if (pt[j].p == 1) {
	  addr = pt[j].base << 12;
	  ASSERT(memory_bitmap[BITMAP_INDEX(addr)] == ALLOCATED);
	  memory_bitmap[BITMAP_INDEX(addr)] = FREE;
	  pages_available++;
	  pt[j].p=0;
	}
      }
      sfree(pt, PAGE_SIZE);
    }
  }
  sfree(ptd, PAGE_SIZE); 
}

/*
  page_new_ptd returns a pointer to a ptd which is initialized with only
  the bottom 16 megs of memory.
 */
ptd_struct* page_new_ptd() {
  int i;
  // grab a page in memory
  ptd_struct *current = (ptd_struct*) get_cr3();
  ptd_struct *ptd;
  disable_interrupts();
  ptd = (ptd_struct*) smemalign(PAGE_SIZE, PAGE_SIZE);

  enable_interrupts();
  if (ptd==NULL)
    return NULL;
  for (i=0; i<4; i++) {
    ptd[i] = current[i];
  }
  // mark all other entries as not present
  for (i=4; i<PAGE_TABLE_SIZE; i++) {
    ptd[i].p = 0;
  }
  return ptd;
}

/*
  page_fault_handler is installed in page_init() as the handler for a page fault.
*/
void page_fault_handler(mem_t mem, mem_t esp){
  pcb_struct *pcb = GET_PCB(get_esp());
  /* Make sure that the offending memory is within reasonable bounds for the process
     that caused the error. i.e. it is within 2 pages of the stack or under the mem_limit (brk)*/
  
  if (mem>USER_MEM_START  && (mem >(esp - 2*PAGE_SIZE) || mem < pcb->mem_limit)){
    // allocate mem
    if (page_get_new(pcb->ptd,mem) == -1) {
      printf("Killing the process %d for running out of memory\n", pcb -> pid);
      our_exit(-1); // if this is the case, kill it
    }
  }
  else {

    printf("Killing process %d for page fault (ip=0x%x, esp=0x%x, mem=0x%x)\n", pcb -> pid, get_cr2(), esp, mem);
    our_exit(-1);
  }
}

/* 
   valid_user_mem(ptd, ad) checks if ad is a valid (mapped) address in ptd,
   and is accessinble for the user
*/

int valid_user_mem(ptd_struct* ptd, mem_t addr){
  if(ptd[PTD_INDEX(addr)].p == 1 && ptd[PTD_INDEX(addr)].us == 1){ // this pagetable dir entry must be present and available to the user
    pt_struct * pt = (pt_struct *)((int) ptd[PTD_INDEX(addr)].base <<12);
    if(pt[PT_INDEX(addr)].p == 1 && pt[PT_INDEX(addr)].us == 1 ) // this entry must be present and available to the user.
      return 1;
  }
  return 0;
}

