#include "process.h"
#include "util.h"
#include "kernel.h"
#include "page.h"
#include "loader.h"
#include "inc/seg.h"
#include <oskit/c/malloc.h>
#include "inc/x86_regs.h"
#include "inc/interrupts.h"

mem_t process_create_user_stack(ptd_struct* ptd, char** argv, mem_t def_exit);

pcb_struct* process_create(ptd_struct* ptd, pid_t pid, char** argv) {
  mem_t ks, esp, us;
  pcb_struct* pcb;
  mem_t code_start, exit_default;

  code_start  = loader_loadcode("shell", ptd,&exit_default,1);
  if(code_start == NULL) {
    return NULL;
  }
    
  disable_interrupts();
  ks =  (mem_t) smemalign(KERNEL_STACK_SIZE, KERNEL_STACK_SIZE);

//  printf("Smemalign (%d) returned ks=%x\n", __LINE__, (int) ks);
  enable_interrupts();
  if(ks == NULL)
    return NULL;
  pcb = (pcb_struct*)GET_PCB(ks);
  ks = (mem_t) pcb;
  pcb->state = STOPPED;
  pcb->flags = NORMAL;
  pcb->sleep_time = 0;
  pcb->pid = pid;
  pcb->tid = pid;
  pcb->parent = pid;
  pcb->ptd = ptd;
  pcb -> mem_limit = exit_default + SYS_EXIT_SIZE;//(mem_t) bss + USER_MEM_START;
  pcb->deadkids = NULL;
  pcb -> num_children = 0;

  // proj 4
  pcb -> next_io_waiting = NULL;
  pcb -> fds = 0;
  pcb -> cur_inode= 0;

  // The caller of this function must set pcb->next and pcb->prev !
  // As well as the state

  us = process_create_user_stack(ptd, argv, exit_default);
  if (us==NULL)
    return NULL;
  PUSH(ks, USER_DS | 3);
  PUSH(ks, us);
  PUSH(ks, 0x202);     /* FIXME IS THIS VALUE CORRECT ??? */
  PUSH(ks, USER_CS | 3);
  PUSH(ks, code_start);//USER_CODE_START);

  PUSH(ks, 0); // No error code
  
  //Setting the stack to have the regs on it.
  esp = get_esp();
  set_esp(ks);
  asm("pusha");
  ks = get_esp();
  set_esp(esp);

  // pushing the data segment registers
  PUSH(ks, USER_DS | 3); // ds
  PUSH(ks, USER_DS | 3); //es
  PUSH(ks, USER_DS | 3);// fs
  PUSH(ks, USER_DS | 3);// gs
  PUSH(ks, get_cr0());
  pcb -> kesp = ks;

  return pcb;
}
  
void process_launch(pcb_struct* pcb){
  /* assuming that the useful stack starts at pcb-18*4 bytes */
  //  mem_t ks = pcb->kesp; //(mem_t) ((int*)pcb-18);
  mem_t ks = (mem_t) ((int*)pcb-19);
//  printf("PROCESS LAUNCH CALLED\n");
  pcb -> state =  RUNNING;
  pcb -> flags = NORMAL;
//  printf("Houston all systems are go: %d (pcb=%x)\n", pcb->pid, (int) pcb);
  // set the page table directory.
  set_cr3((int) pcb->ptd);
  set_esp0((void*) pcb);
  // get the pcb and set the bss
  set_cr0(POP(ks));
  set_gs(POP(ks));
  set_fs(POP(ks));
  set_es(POP(ks));
  set_ds(POP(ks));
  set_esp((int) ks);
  asm("popa");
  asm("addl $4, %esp");
  asm("asm_iret: iret");
  return;
}



mem_t process_create_user_stack(ptd_struct* ptd, char** argv, mem_t def_exit) {
  // Convert argv to argc, argv... WHAT IF PAGE OVERFLOWS ???!!!  FIXEME   XXXXXXX
  mem_t userstack = (mem_t) -1;
  int t,i;
  char **s, *c;
  char* arguments;
  char** argvec2;
  int total_size, size, argc;
  int oldcr3;
  
  ASSERT(argv!=NULL);
  t=page_get_new(ptd, (mem_t) userstack);
  if(t == -1) 
    return NULL;
  // Calculate total length of strings
  s = argv;
  argc = 0;
  total_size = 0;
  while (*s != NULL) {
    size = strlen(*s)+1;
    total_size += size;
    s++;
    argc++;
  }

  //grab a chunk of memory as big as the arguments
  disable_interrupts();
  arguments = malloc(total_size);
  //grab a new array for the pointers
  argvec2 = malloc(argc * (sizeof(char*)));
  enable_interrupts();
  c = arguments;
  for (i=0; i<argc; i++) {
    argvec2[i] = c;
    strcpy (c,argv[i]);
    c += strlen(argv[i])+1;
  }

  disable_interrupts();
  oldcr3=get_cr3();
  set_cr3((int) ptd);

  // Now move sp down by total_size (four byte aligned)
  userstack=(mem_t) ((char*)userstack - total_size);
  userstack = (mem_t) ((char*) userstack -  ((unsigned int)userstack % 4)); // round down
  c = (char*) userstack;
  for (t=argc-1; t>=0; t--) {
    PUSH(userstack, c);
    strcpy(c, argvec2[t]);
    c+=(strlen(argvec2[t])+1);
  }

  free(argvec2);
  free(arguments);

  c = (char*)userstack;
  // Push argc and return address (def_sys_exit)
  PUSH(userstack, c);
  PUSH(userstack, argc);
  PUSH(userstack, def_exit);
  set_cr3(oldcr3);
  enable_interrupts();
  return userstack;
}


