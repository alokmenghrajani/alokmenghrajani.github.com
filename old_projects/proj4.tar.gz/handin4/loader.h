#ifndef LOADER__H
#define LOADER__H

#include "inc/seg.h"
#include "page.h"

#define NMAGIC 0410 /* 0x108 */

#define SYS_EXIT_SIZE 16

int getbytes(char* filename, int offset, int size, char* buf);

/* Loads code/data and returns the start */
mem_t loader_loadcode(char* filename, ptd_struct *ptd, mem_t *default_exit_addr, int bootstrapping);

#endif /* LOADER__H */
