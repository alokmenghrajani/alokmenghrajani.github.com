#ifndef FILESYSTEM__H
#define FILESYSTEM__H

#include "lock3.h"

/* Limits on the numbers of files and names */
#define MAXFILENAMESIZE 32 // (including terminating zero)
#define MAXPATHNAMELEN 256
#define MAX_OPEN_FILE 32
#define MAX_FD 16
#define MAX_FILES 8192
#define MAX_HD (32*1024*1024)

/* The different types of files: */
#define FREEINODE 0 
#define USEDINODE 1
#define NORMALFILE 2
#define SOFTLINK 3
#define DIRECTORY 4

/* Size of a block that is written or read at a time from disk */
#define BLOCK_SIZE 1024
#define BLOCK_INDEX_SIZE 256

/* block index  */
typedef int block_t;

/* Structure of an inode representing a single file */
typedef struct _hippo_inode{
  char type;  /* is it a directory? is it a symbolic link?*/
  char name[MAXFILENAMESIZE];
  char symlink[MAXPATHNAMELEN];
  int filesize; /* used as no of subfiles for directories */
  short prev_file, next_file; /* inode no of next file in same level (brother) */
  short child;    /* Indicates first file (for directories) */
  short parent;
  block_t block_index; /* the block number of the block index for this file */
} inode_t;

typedef struct superblock__ {
  int max_inodes;
  int first_userblock;
} superblock_t;



/*file descriptors*/

#define SYS_MAX_OPEN_FILES 32

typedef struct _hippo_fd{
  int offset;
  int inode;
  int counter;
} file_desc;

file_desc system_wide_fds [SYS_MAX_OPEN_FILES];
lock3_t system_wide_fds_lock;

/******************/




#define BITVEC_SIZE 4096 // 32 MB => 32k blocks => 4k bytes (8 bits per byte => 8 blocks per byte)
char block_bitvec[BITVEC_SIZE];
lock3_t block_bitvec_lock;
inode_t inodes[MAX_FILES];
lock3_t inodes_lock;
lock3_t link_lock;
superblock_t superblock;


// #define DEFAULT_RECURSE 5 ????


// for debugging this is here in the .h
int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);
void fs_listing(char *pathname);
void fs_tree(char *pathname, int ident);


void fs_init();

void save_inodes();

int fs_mkfs(int max_inodes);    // ok
int fs_open(char *pathname);
int fs_close(int fd);
int fs_create(char *pathname);
int fs_read(int fd, void *buf, int size);
int fs_write(int fd, void *buf, int size);
int fs_seek(int fd, int offset);
int fs_link(char *oldname, char *newname);
int fs_symlink(char *oldname, char *newname);
int fs_unlink(char* pathname);
int fs_filesize(char *pathname);
int fs_mkdir(char *pathname);   // we must strip a tailing / if exists...
int fs_rmdir(char *pathname);
int fs_chdir(char *pathname);
int fs_dirsize(char *pathname);
int fs_direntry(char *pathname, int entrypos, char *entryname);
int fs_sync();

void disk_write_callback();
void disk_read_callback();
#endif /* FILESYSTEM__H */
