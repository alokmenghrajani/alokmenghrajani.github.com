#include "buffercache.h"
#include <stdio.h>

#include "filesystem.h"


int main(){
  char buf[MAXFILENAMESIZE];
  int c1,c2,c3,i;  
  int recurse_level = 0;
  char buffer[1024];
  lock3_t l;

  cache_init();
  disk_init();
  fs_init();

  printf("hello\n");
  fs_mkfs(100);
  printf("%d\n", fs_mkdir("./alok/"));
  printf("%d\n", fs_symlink("../alok", "alok/symlink"));
/// c2 = fs_create("tree");
//  fs_link("tree", "vik");
//

  c1 = fs_create("vikram");
  printf("fd for shit = %d \n",c1);
//  c2 = fs_open("shit");
//  printf("fd for shit = %d \n",c2);
  fs_write(c1,"crapcrap",8);
  fs_write(c1,"crapcrap",8);
//  printf("asdasd\n");  

//  fs_read(c2, buffer, 10);
//  for(i = 0; i < 10; i++)
//    printf("%c", buffer[i]);
  printf("size of the file shit: %d\n", fs_filesize("vikram"));
  printf("%d\n", fs_link("vikram", "/alok/symlink/link"));
  fs_tree(".", 0);
  fs_sync();
}
