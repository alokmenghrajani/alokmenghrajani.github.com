#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "hdsim.h"

/* proj 4 */
#include "../inc/common.h"
#include "../inc/disk.h"
#include "filesystem.h"

//The file descriptor for the HD
int HDfd;

/*
 * int disk_init()
 * Installs the disk interrupt handler via disk_install(),
 * waits until the disks are ready, and finds out how big
 * they are (filling in the ide0 and ide1 data structures).
 * Returns SUCCESS if the disks were initialized, and ERROR
 * otherwise.
 */
int disk_init(void){
  HDfd = open("hard_disk",O_CREAT|O_TRUNC|O_RDWR,S_IRWXU); 
  return SUCCESS;
}

/*
 * void ide_write_sector(int lba_addr, char* source, int num)
 * Initiates an IDE operation to write the specified sectors
 * to the disk. The sectors will be taken sequentially from the
 * address source.
 */
void ide_write_sector(int lba_addr, char* source, int num){
  int start_bytes_to_write = lba_addr * SECTOR_SIZE;
  int size;
  lseek(HDfd, start_bytes_to_write, SEEK_SET);
  size = write(HDfd, source, num * SECTOR_SIZE);

}

/*
 * void ide_read_sector(int lba_addr, char* source, int num)
 * Initiates an IDE operation to read the specified sectors
 * from the disk. The sectors will be stored sequentially starting
 * at the address source.
 */
void ide_read_sector(int lba_addr, char* dest, int num){
  int start_bytes_to_read = lba_addr * SECTOR_SIZE;
  int size;

  lseek(HDfd, start_bytes_to_read, SEEK_SET);
  size = read(HDfd, dest, num*SECTOR_SIZE);
}

/*
 * int get_num_sectors()
 * Returns the number of sectors on the drive.
 * You must call disk_init(), and have it return SUCCESS, before
 * this function will function properly.
 */
int get_num_sectors(void){
  int bytes = (int)lseek(HDfd, 0, SEEK_END);
  return (bytes/SECTOR_SIZE + (bytes % SECTOR_SIZE == 0? 0 : 1 ));
}

