#include "bitvec.h"
#include "filesystem.h"
#include "../inc/common.h"

void disk_write_callback() {
  ;
}
void disk_read_callback() {
  ;
}

int enter_directory(int inode, int *recurse_level);
int find_file(int inode, char *filename);
int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level);
int find_empty_inode();

// TO BE MOVED INSIDE THE KERNEL:
int process_current_inode = 0;  //root by default.
void set_process_current_inode(int t) {
  process_current_inode = t;
}
int get_process_current_inode() {
  return process_current_inode;
}

int get_process_fds(){
  return -1; 
}

void set_process_fds(int t){
  ;
}
// TILL HERE ?

#define MAX_SOFT_LINK_RECURSE_LEVEL 5

void fs_init() {
  // Init locks
  // and also check the disk to see if there is a formatted fs.
  int i;
  init_lock3(&link_lock);
  init_lock3(&inodes_lock);
  init_lock3(&block_bitvec_lock);
  init_lock3(&system_wide_fds_lock);
  for(i = 0; i < SYS_MAX_OPEN_FILES; i++)
    system_wide_fds[i].inode = -1;

}

/* assume here that we have already exc locked the inodes */

void add_inode_to_dir(int parent, int new_inode) {
  // new_inode should be exc_locked.
  // Check lock here
  ASSERT(inodes_lock.flag); 
  inodes[parent].filesize++;
  // add yourself to list
  inodes[new_inode].next_file = inodes[parent].child;
  inodes[parent].child = new_inode;
  if (inodes[new_inode].next_file != -1) {
    inodes[inodes[new_inode].next_file].prev_file = new_inode;	
  }
  inodes[new_inode].prev_file = -1;
}

/* assume here that we have already exc locked the inodes */
void remove_inode_from_dir(int node) {
  // Check lock here
  ASSERT(inodes_lock.flag); 
  inodes[inodes[node].parent].filesize--;
  // remove yourself from list
  // Check if you are the first element
  if (inodes[inodes[node].parent].child==node)
    inodes[inodes[node].parent].child=inodes[node].next_file;
  else {
    ASSERT(inodes[node].prev_file!=-1);
    inodes[inodes[node].prev_file].next_file = inodes[node].next_file;
  }
  // Check if you are the last element
  if (inodes[node].next_file!=-1) {
    inodes[inodes[node].next_file].prev_file = inodes[node].prev_file;
  }
  inodes[node].type = FREEINODE;
}


/* assume that we already have at least a shared lock on the inodes. */
int resolve_symlink(int inode, int *recurse_level) {
  ASSERT(inode!=-1);
  if (inodes[inode].type==SOFTLINK) {
    int t;
    char buf[MAXFILENAMESIZE];
    (*recurse_level)++;
    if (*recurse_level>MAX_SOFT_LINK_RECURSE_LEVEL)
      return -1; // max recurse level reached
    t = resolve_pathname(inodes[inode].symlink, inodes[inode].parent, buf, recurse_level);
    // now we either have no filename, in which case return t
    // or we try to enter the file (might be symlink too)
    if (buf[0]==0)
      return t;
    t = find_file(t, buf);
    if (t==-1)
      return -1;
    return resolve_symlink(t, recurse_level);
  }
  return inode;
}


/* assume that we already have at least a shared lock on the inodes */
int find_file(int inode, char *filename) {
  int child;
  // if filename == "." then return inode
  // if it's ".." then return the parent
  // otherwise find the filename in the children of inode.
  // inode must be a directory.
  // if not found, return -1;
  ASSERT(inodes[inode].type==DIRECTORY);
  if (strcmp(filename, ".")==0)
    return inode;
  if (strcmp(filename, "..")==0) {
    return inodes[inode].parent;
  }
  child = inodes[inode].child;
  while (child!=-1) {
    if (strcmp(inodes[child].name, filename)==0)
      return child;
    child = inodes[child].next_file;
  }
  return -1;
}

// return the filename in char **filename
// and inode no
// filenames / directory names larger then MAXFILENAME are truncated ! No error reported !
// returns -1 on error.

/* assume that we already have a shared lock on the inodes */
int resolve_pathname(char *pathname, int current_inode, char *filename, int *recurse_level) {
  int i,j, t;
  char buf[MAXFILENAMESIZE];
  // i will always point to the first character of the directory or filename being parsed.
  // so it will usually be right after the /.
  i=0;
  // See if pathname is absolute or relative
  if (pathname[0]=='/') {
    current_inode = 0; // start from root inode
    i=1; // Set i right after slash.
  }
  
  if (pathname[0]==0)
    return -1;
  while (1) {
    // find the next slash
    for (j=i+1; (pathname[j]!='/') && (pathname[j]!=0); j++);
    if (pathname[j]==0) {
      // WE MUST COPY THE FILENAME
      strncpy(filename, &pathname[i], MIN(j-i, MAXFILENAMESIZE));
      filename[MIN(j-i, MAXFILENAMESIZE-1)]=0;
      // Make sure that filename is at most as big as MAXFILENAMESIZE+1
      return current_inode;
    } else {
      // We have a folder name from i to j-1
      strncpy(buf, &pathname[i], MIN(j-i, MAXFILENAMESIZE));
      buf[MIN(j-i, MAXFILENAMESIZE-1)] = 0;
      
      // Find the folder in the directory
      t = find_file(current_inode, buf);
      if (t==-1)
	return -1; // Folder not found
      // now resolve it if we have a symlink
      current_inode = resolve_symlink(t, recurse_level);
      if (current_inode==-1)
	return -1; // Invalid symlink
      i=j+1; // set i right after slash.
      if (pathname[i]==0) {
	// WE DON'T HAVE ANY FILENAME
	filename[0]=0;
	return current_inode;
      }
      // test for strings like '//' (this is not linux' behaviour)
      if (pathname[i]=='/') {
	return -1;
      }
    }
  }
}

/* assume that we have NOT locked the inodes */
int find_empty_inode() {
  int i;

  for (i=0; i<superblock.max_inodes; i++) {
    exc_lock (&inodes_lock);
    if (inodes[i].type == FREEINODE) {
      inodes[i].type = USEDINODE;
      exc_unlock (&inodes_lock);     
      return i;
    }
    exc_unlock (&inodes_lock);       // release lock
  }
  ASSERT(0); // No more inodes, should never happen ... 
  return -1;
}

int fs_mkdir(char *pathname) {
  // strip any tailing '/'
  int t;
  int parent, new;
  char buf[MAXPATHNAMELEN];
  int recurse_level;
  // I know that pathname cannot be null (tested at syscall level)
  if (pathname[0]==0)
    return ERROR;
  strncpy(buf, pathname, MAXPATHNAMELEN);
  buf[MAXPATHNAMELEN-1] = 0;

  for (t=0; buf[t+1]!=0; t++);
  if (buf[t]=='/')
    buf[t]=0;
  // find an empty inode
  new = find_empty_inode();

  exc_lock(&inodes_lock);
  recurse_level = 0;
  parent = resolve_pathname(buf, get_process_current_inode(), inodes[new].name, &recurse_level);
  if (parent==-1){
    exc_unlock(&inodes_lock);
    return -1;
  }

  // make sur parent doesn't already have this file
  if (find_file(parent, inodes[new].name)!=-1) {
    inodes[new].type = FREEINODE;
    exc_unlock(&inodes_lock);    
    return -1; // file name already taken.
  }

  // fill up structure
  inodes[new].type = DIRECTORY;
  inodes[new].filesize = 0;
  inodes[new].child = -1;
  inodes[new].parent = parent;
  inodes[new].block_index = -1;
  add_inode_to_dir(parent, new);

  exc_unlock(&inodes_lock);
  return new;

}

int fs_rmdir(char *pathname) {
  char buf[MAXFILENAMESIZE];
  char buf2[MAXPATHNAMELEN];
  int dir, parent, t;
  int recurse_level = 0;

  // if the format is path1/dir/ convert it to path1/dir
  if (pathname[0]==0)
    return ERROR;
  strncpy(buf2, pathname, MAXPATHNAMELEN);
  buf2[MAXPATHNAMELEN-1] = 0;

  for (t=0; buf2[t+1]!=0; t++);
  if (buf2[t]=='/')
    buf2[t]=0;
  exc_lock(&inodes_lock);
  parent = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);

  if (parent==-1){
    exc_unlock(&inodes_lock);
    return ERROR; // directory not found
  }
  dir = find_file(parent, buf);
  if (dir==-1){
    exc_unlock(&inodes_lock);
    return ERROR; // directory not found
  }
  if (dir==0){
    exc_unlock(&inodes_lock);
    return ERROR; // Disallow remove the root directory !
  }
  if (inodes[dir].type != DIRECTORY){
    exc_unlock(&inodes_lock);
    return ERROR; // not a directory  (We do not accept symlinks here)
  }
  if (inodes[dir].child != -1){
    exc_unlock(&inodes_lock);
    return ERROR; // not empty
  }
  remove_inode_from_dir(dir);
  exc_unlock(&inodes_lock);
  return SUCCESS;
}

/*
  get_new_block returns a new block number that hasn't been allocated yet.
*/
int get_new_block() {
  int i;
  for (i=5; i<BITVEC_SIZE; i++) {
    exc_lock(&block_bitvec_lock);
    if (bitmap_test(block_bitvec,i) == 0) {
      bitmap_set(block_bitvec,i,1);
      exc_unlock(&block_bitvec_lock);
      return i;
    }
    exc_unlock(&block_bitvec_lock);
  }
  // DISK FULL!!!
  return -1;
}

/* assumes that system_wide_fds_lock is exclusively held. */
int get_next_fd(){
  int i = 0;
  while (i<SYS_MAX_OPEN_FILES){
    if(system_wide_fds[i].inode == -1){
      return i;
    }
    i ++;
  }
  return ERROR;
}

int fs_create(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent_dir;
  
  exc_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, inodes[new_inode].name, &recurse_level);

  if(parent_dir == -1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return ERROR;
  }
  
  if(inodes[new_inode].name[0] == 0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return ERROR;
  }

  if(find_file(parent_dir, inodes[new_inode].name) == -1) {
    int buffer[BLOCK_INDEX_SIZE]; // This is because we have the entries in the block index dir as ints.
    int new_block = get_new_block();
    inode_t * inode = &inodes[new_inode]; // get a pointer to the inode that we want. 
    int i, fdnum;
    
    buffer[0] = 1; // This is the counter as the number of hard links to this file
    for(i = 1; i< BLOCK_INDEX_SIZE; i++)
      buffer[i] = -1;
    
    inode->type = NORMALFILE;
    inode->filesize = 0;
    
    /* insert this new file into the parent's list */
    add_inode_to_dir(parent_dir, new_inode);    

    /* set the data in the inode */
    inode->parent = parent_dir;
    inode->child = -1;
    inode->block_index = new_block;
    exc_unlock(&inodes_lock);    
    cache_write_block(new_block, (char*)buffer, BLOCK_SIZE);
    
    exc_lock(&system_wide_fds_lock);    

    fdnum = get_next_fd();
    if(fdnum == ERROR){
      exc_unlock(&system_wide_fds_lock);    
      exc_lock(&inodes_lock);
      inodes[new_inode].type = FREEINODE;
      exc_unlock(&inodes_lock);

      exc_lock(&block_bitvec_lock);
      bitmap_set(block_bitvec, new_block, 0);
      exc_unlock(&block_bitvec_lock);

      return ERROR;
    }
    system_wide_fds[fdnum].inode = new_inode;
    system_wide_fds[fdnum].offset = 0;
    system_wide_fds[fdnum].counter = 1;
    exc_unlock(&system_wide_fds_lock);    

    i = get_process_fds();
    set_process_fds(i | 1 << fdnum);
    
    return fdnum;
  }
  inodes[new_inode].type = FREEINODE;
  exc_unlock(&inodes_lock);    
  return ERROR;
}

int fs_symlink(char *oldname, char *newname) {
  // check that new name doesn't exist:
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent;
  
  exc_lock(&inodes_lock);
  parent = resolve_pathname(newname, get_process_current_inode(), inodes[new_inode].name, &recurse_level);
  if (parent==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return -1; // pathname invalid
  }
  if (inodes[new_inode].name[0]==0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return -1; // No filename supplied
  }
  // Check file name doesn't exist:
  if (find_file(parent, inodes[new_inode].name)!=-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);
    return -1;  // file exists
  }
  // create symlink
  inodes[new_inode].type = SOFTLINK;
  strncpy(inodes[new_inode].symlink, oldname, MAXFILENAMESIZE);
  inodes[new_inode].symlink[MAXFILENAMESIZE-1]=0;
  inodes[new_inode].child = -1;
  inodes[new_inode].parent = parent;
  inodes[new_inode].block_index = -1;
  add_inode_to_dir(parent, new_inode);
  exc_unlock(&inodes_lock);

  return new_inode;
}

int fs_link(char *oldname, char *newname) {
  // check that the new name doesn't exist:
  char buf[MAXFILENAMESIZE];
  int source;
  int recurse_level = 0;
  int new_inode = find_empty_inode();
  int parent;
  
  exc_lock(&inodes_lock);  
  parent = resolve_pathname(newname, get_process_current_inode(), inodes[new_inode].name, &recurse_level);
  if (parent==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // pathname invalid
  }
  if (inodes[new_inode].name[0]==0) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // No filename supplied
  }
  // Check file name doesn't exist:
  if (find_file(parent, inodes[new_inode].name)!=-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1;  // file exists
  }
  // create hardlink
  recurse_level = 0;
  source = resolve_pathname(oldname, get_process_current_inode(), buf, &recurse_level);
  if (source==-1) {
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1;
  }
  if (buf[0]!=0) {
    source = find_file(source, buf);
    if (source == -1){
      inodes[new_inode].type = FREEINODE;      
      exc_unlock(&inodes_lock);  
      return -1;
    }
  }
  if (inodes[source].type == DIRECTORY){
    inodes[new_inode].type = FREEINODE;
    exc_unlock(&inodes_lock);  
    return -1; // We don't allow hardlink on directories.
  }
  if (inodes[source].type == SOFTLINK) {
    inodes[new_inode].type = SOFTLINK;
    strncpy(inodes[new_inode].symlink, inodes[source].symlink, MAXPATHNAMELEN);
    inodes[new_inode].symlink[MAXPATHNAMELEN-1]=0;
    inodes[new_inode].filesize = 0;
    inodes[new_inode].block_index = -1;
  } else {
    int t, block_num;
    ASSERT(inodes[source].type == NORMALFILE);
    inodes[new_inode].type = NORMALFILE;
    inodes[new_inode].filesize = inodes[source].filesize;
    inodes[new_inode].block_index = inodes[source].block_index;
    // Increment counter
    exc_lock(&link_lock);
    exc_unlock(&inodes_lock);
    cache_read_block(inodes[new_inode].block_index, (char*) &t, 4);
    t++;
    cache_write_block(inodes[new_inode].block_index, (char*) &t, 4);
    exc_lock(&inodes_lock);
    exc_unlock(&link_lock);
  }
  inodes[new_inode].child = -1;
  inodes[new_inode].parent = parent;
  add_inode_to_dir(parent, new_inode);
  
  exc_unlock(&inodes_lock);  
  return new_inode;
}

int fs_chdir(char *pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int t;
  int dir;

  shared_lock (&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock(&inodes_lock);
    return -1;
  }
  if (buf[0]!=0) { // case where pathname is /path1/dir
    int t = find_file(dir, buf);
    if (t==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
  }
  shared_unlock(&inodes_lock);
  // otherwise if pathname is /path1/dir/ no need to change anything
  set_process_current_inode(dir);
  return 0;
}

int fs_dirsize(char *pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int t;
  int dir;
  shared_lock(&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock(&inodes_lock);
    return -1;
  }
  if (buf[0]!=0) {
    t = find_file(dir, buf);
    if (t==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock(&inodes_lock);
      return -1;
    }
  }
  t = inodes[dir].filesize+2;
  shared_unlock(&inodes_lock);

  return t;
}

int fs_direntry(char *pathname, int entrypos, char *entryname) {
  char buf[MAXFILENAMESIZE];
  int child, i;
  int recurse_level=0;
  int dir;
  shared_lock (&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    shared_unlock (&inodes_lock);
    return -1;
  }
  if (buf[0]!=0) {
    int t = find_file(dir, buf);
    if (t==-1){
      shared_unlock (&inodes_lock);
      return -1;
    }
    dir=resolve_symlink(t, &recurse_level);
    if (dir==-1){
      shared_unlock (&inodes_lock);
      return -1;
    }
  }

  if (entrypos==inodes[dir].filesize) {
    strcpy(entryname, ".");
    shared_unlock (&inodes_lock);
    return 0;
  }
  if (entrypos==inodes[dir].filesize+1) {
    strcpy(entryname, "..");
    shared_unlock (&inodes_lock);
    return 0;
  }
  child = inodes[dir].child;
  for (i=0; i<entrypos; i++) {
    child = inodes[child].next_file;
    ASSERT(child != -1);
  }
  strncpy(entryname, inodes[child].name, MAXFILENAMESIZE);
  entryname[MAXFILENAMESIZE-1]=0;
  shared_unlock (&inodes_lock);
  return 0;
}

int fs_unlink(char* pathname) {
  char buf[MAXFILENAMESIZE];
  int recurse_level=0;
  int file;
  int dir, filetype, blocknum;
  exc_lock(&inodes_lock);
  dir = resolve_pathname(pathname, get_process_current_inode(), buf, &recurse_level);
  if (dir==-1){
    exc_unlock(&inodes_lock);
    return -1; // path unresolved
  }
  file = find_file(dir, buf);
  if (file==-1){
    exc_unlock(&inodes_lock);
    return -1; // file not found
  }
  if (inodes[file].type == DIRECTORY){
    exc_unlock(&inodes_lock);
    return -1; // invalid type
  }

  // if it's a hardlink decrement the counter
  // and free the block directory and blocks if need be
  filetype = inodes[file].type;
  blocknum = inodes[file].block_index;
  remove_inode_from_dir(file);
  exc_unlock(&inodes_lock);
    
  if (filetype == NORMALFILE) {
    int t;

    // if it's not a softlink, it's a hardlink.
    ASSERT(blocknum!=-1);
    exc_lock(&link_lock);
    cache_read_block(blocknum, (char*) &t, 4);
    t--;
    if (t==0) {
      // optimization: tell the cache that these blocks are no more allocated
      // this way if the block is dirty, it won't be rewritten.
      // DELETE the block index directory, block indexes and blocks
      int i, j;
      int buffer1[BLOCK_INDEX_SIZE];
      int buffer2[BLOCK_INDEX_SIZE];
      
      cache_read_block(blocknum, (char*) buffer1, BLOCK_SIZE);
      for (i=1; i<BLOCK_INDEX_SIZE; i++) {
        // we can have holes in our block index table
	if (buffer1[i]==-1)
	  continue;
	cache_read_block(buffer1[i], (char*) buffer2, BLOCK_SIZE);
	for (j=0; j<BLOCK_INDEX_SIZE; j++) {
	  if (buffer2[j]==-1)
	    continue;
	  exc_lock(&block_bitvec_lock);
	  bitmap_set(block_bitvec, buffer2[j], 0);
	  exc_unlock(&block_bitvec_lock);
	}
	exc_lock(&block_bitvec_lock);
	bitmap_set(block_bitvec, buffer1[i], 0);
	exc_unlock(&block_bitvec_lock);
      }
      exc_lock(&block_bitvec_lock);
      bitmap_set(block_bitvec, blocknum, 0);
      exc_unlock(&block_bitvec_lock);
    } else {
      cache_write_block(blocknum, (char*) &t, 4);
    }
    exc_unlock(&link_lock);
  }
  return 0;
}

int fs_open(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  char filename[MAXFILENAMESIZE];
  int inode;
  int parent_dir;
  
  shared_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, filename, &recurse_level);
  shared_unlock(&inodes_lock);
    
  if(filename[0] == 0) {
    printf("bad filename\n");
    return ERROR;
  }

  if(parent_dir == -1) {
    printf("no such dir \n");
    return ERROR;
  }

  if((inode = find_file(parent_dir, filename)) != -1){
    int i, fdnum;
    exc_lock(&system_wide_fds_lock);
    fdnum = get_next_fd();
    if(fdnum == ERROR){
      printf("too many open files\n");
      exc_unlock(&system_wide_fds_lock);
      return ERROR;
      
    }
    system_wide_fds[fdnum].inode = inode;
    system_wide_fds[fdnum].offset = 0;
    system_wide_fds[fdnum].counter = 1;
    exc_unlock(&system_wide_fds_lock);
    i = get_process_fds();
    set_process_fds(i | 1 << fdnum);
        
    return fdnum;
  }   
  printf("no such file in this dir\n");  
  return ERROR;
}

int fs_close(int fd){ 
  int i;
  int rights = get_process_fds();
  if(!((1 << fd) & rights))
    return ERROR;
  shared_lock(&system_wide_fds_lock);
  if(fd >= 32 || system_wide_fds[fd].inode == -1){
    shared_unlock(&system_wide_fds_lock);
    return ERROR;
  }
  shared_unlock(&system_wide_fds_lock);

  i = get_process_fds();
  set_process_fds(i & (~(1 << fd)));
  
  exc_lock(&system_wide_fds_lock);
  system_wide_fds[fd].counter --;
  if(system_wide_fds[fd].counter){
    exc_unlock(&system_wide_fds_lock);
    return SUCCESS;
  }
  system_wide_fds[fd].inode = -1;
  exc_unlock(&system_wide_fds_lock);


  return SUCCESS;
}


int fs_read(int fd, void *buf, int size){
  int block_table[BLOCK_INDEX_SIZE];
  int block_dir[BLOCK_INDEX_SIZE];
  char block [BLOCK_SIZE];
  int offset;
  int inode,blocknum;
  int BIdir_num;
  int actual_block;
  int i,index=0;
  int rights, end;

  shared_lock(&system_wide_fds_lock);
  offset = system_wide_fds[fd].offset;
  inode =  system_wide_fds[fd].inode;
  shared_unlock(&system_wide_fds_lock);

  end = offset + size;

  /* check that the user is allowed to access that file */
  rights = get_process_fds();
  if(!((1 << fd) & rights))
    return ERROR;


  if(system_wide_fds[fd].inode == -1)
    return ERROR;


  shared_lock(&inodes_lock);
  blocknum = inodes[inode].block_index;
  shared_unlock(&inodes_lock);

  // get the block_dir
  cache_read_block(blocknum, block_dir, BLOCK_SIZE);  

  while(offset< end){
    //compute the block number to begin reading from.
    int  block_to_read = ((offset + BLOCK_SIZE - (offset % BLOCK_SIZE))/BLOCK_SIZE) - 1; // round down
    // compute the block index dir number
    BIdir_num = block_dir[(block_to_read /BLOCK_INDEX_SIZE) +1]; // The +1 is just to accomodate the first feild which is a counter.
//    printf("%d %d\n", offset, end);
    i = 1; // using as a flag

    if(BIdir_num != -1){
      // get the block_table
      int k;
      cache_read_block(BIdir_num, block_table, BLOCK_SIZE);  
      
      // finally we can now get the actual page to read.
      actual_block = block_table[block_to_read % BLOCK_INDEX_SIZE];
			
      if(actual_block != -1){
	cache_read_block(actual_block, block, BLOCK_SIZE);  
				
				// copy shit from the block we just got to the actual buffer
	for(i = offset % BLOCK_SIZE; i <   BLOCK_SIZE && index < size; i ++){
	  ((char*)buf)[index] = block[i];
	  offset++;
	  index ++;
	}
	i = 0;// flag that write was made
      }
    }
    if(i){
      for(i = offset % BLOCK_SIZE; i <  BLOCK_SIZE && index <size; i ++){
	((char*)buf)[index] = 0;
	index ++;
	offset++;
      }
    }
  }
  exc_lock(&inodes_lock);
  inodes[inode].filesize = MAX(offset, inodes[inode].filesize);
  exc_unlock(&inodes_lock);
}

int fs_write(int fd, void *buf, int size){ 
  int block_table[BLOCK_INDEX_SIZE];
  int block_dir[BLOCK_INDEX_SIZE];
  char block [BLOCK_SIZE];
  int offset;
  int inode, blocknum;
  int BIdir_num;
  int actual_block;
  int i,index= 0;
  int rights, end;

  shared_lock(&system_wide_fds_lock);
  offset = system_wide_fds[fd].offset;
  inode = system_wide_fds[fd].inode;
  shared_unlock(&system_wide_fds_lock);

  end = offset + size;

  /* check that the user is allowed to access that file */
  rights = get_process_fds();
  if(!((1 << fd) & rights))
    return ERROR;

  shared_lock(&system_wide_fds_lock);
  if(system_wide_fds[fd].inode == -1){
    shared_unlock(&system_wide_fds_lock);
    return ERROR;
  }
  shared_unlock(&system_wide_fds_lock);

  shared_lock(&inodes_lock);
  blocknum = inodes[inode].block_index;
  shared_unlock(&inodes_lock);


  // get the block_dir
  cache_read_block(blocknum, block_dir, BLOCK_SIZE);  
  
  while(offset< end){
    //compute the block number to begin writing to.
    int  block_to_write = ((offset + BLOCK_SIZE - (offset % BLOCK_SIZE))/BLOCK_SIZE) - 1; // round down

    // compute the block index dir number
    BIdir_num = block_dir[(block_to_write /BLOCK_INDEX_SIZE) +1]; // The +1 is just to accomodate the first feild which is a counter.
    i = 1; // using as a flag

    if(BIdir_num != -1){
      // get the block_table
      cache_read_block(BIdir_num, block_table, BLOCK_SIZE);  
      // finally we can now get the actual page to read.
      actual_block = block_table[block_to_write % BLOCK_INDEX_SIZE];
     
      if(actual_block != -1){
	cache_read_block(actual_block, block, BLOCK_SIZE);  
		
	// copy shit from the block we just got to the actual buffer
	for(i = offset % BLOCK_SIZE; i <  BLOCK_SIZE && index < size; i ++){
	  block[i]= ((char*)buf)[index];
	  index ++;
	  offset++;
	}
	i = 0;// flag that write was made
	cache_write_block(actual_block, block, BLOCK_SIZE);
      }
    }
    if(i){
      //get a new block
      int new_block = get_new_block();
      int j;
      //set the buffer to zeros
      for(j = 0; j < BLOCK_SIZE; j ++)
	block[j] = 0;
      // fill in what we have of this buffer
      for(j = offset % BLOCK_SIZE; j <  BLOCK_SIZE && index < size; j ++){
	block[j]= ((char*)buf)[index];
	offset++;
	index++;
      }
      //write the new block to disc
      cache_write_block(new_block, block, BLOCK_SIZE);
      //update the tables
      if(actual_block == -1){
	block_table[block_to_write % BLOCK_INDEX_SIZE] = new_block;
	cache_write_block(block_dir[BIdir_num], block_table, BLOCK_SIZE);
      }
      if(BIdir_num == -1){
	//get a new block for the BItable
	int new_table = get_new_block();
	for(j = 0; j < BLOCK_INDEX_SIZE; j++)
	  block_table[j] = -1;
	block_table[block_to_write % BLOCK_INDEX_SIZE]= new_block;
	block_dir[(block_to_write /BLOCK_INDEX_SIZE) +1] = new_table;
	cache_write_block(new_table, block_table, BLOCK_SIZE);
	cache_write_block(blocknum, block_dir, BLOCK_SIZE);
      }
    }
  
  }
  exc_lock(&system_wide_fds_lock);
  system_wide_fds[fd].offset =  end;
  exc_unlock(&system_wide_fds_lock);

  exc_lock(&inodes_lock);
  inodes[inode].filesize = MAX(offset, inodes[inode].filesize);
  exc_unlock(&inodes_lock);
  return SUCCESS;
}

int fs_seek(int fd, int offset){ 
  /* check that the user is allowed to access that file */
  int rights = get_process_fds();
  if(!((1 << fd) & rights))
    return ERROR;

  exc_lock(&system_wide_fds_lock);
  system_wide_fds[fd].offset = offset;
  exc_unlock(&system_wide_fds_lock);
  return SUCCESS;
}

void fs_listing(char *pathname) {
  char buf[MAXFILENAMESIZE];
  int s=fs_dirsize(pathname);
  int i;
  for (i=0; i<s; i++) {
    fs_direntry(pathname, i, buf);
    printf("%d %s\n", i, buf);
  }
}

char treebuf[MAXFILENAMESIZE];
void fs_tree(char *pathname, int ident) {
  char treebuf2[MAXPATHNAMELEN];
  int s=fs_dirsize(pathname);
  int i, t;
  if (ident==0) {
    printf("%s\n", pathname);
    ident++;
  }
  for (i=0; i<s; i++) {
    fs_direntry(pathname, i, treebuf);
    if (strcmp(treebuf, ".")==0)
      continue;
    if (strcmp(treebuf, "..")==0)
      continue;
    for (t=0; t<ident; t++)
      printf(" ");
    printf("%s\n", treebuf);
    strncpy(treebuf2, pathname, MAXPATHNAMELEN);
    strcat(treebuf2, "/");
    strcat(treebuf2, treebuf);
    fs_tree(treebuf2, ident+1);
  }
}

int fs_filesize(char *pathname){ 
  int curr = get_process_current_inode();
  int recurse_level = 0;
  char filename[MAXFILENAMESIZE];
  int parent_dir;
  int inode,t;
  shared_lock(&inodes_lock);
  parent_dir = resolve_pathname(pathname, curr, filename, &recurse_level);


  if(filename[0] == 0) {
    shared_unlock(&inodes_lock);
    printf("bad filename\n");
    return ERROR;
  }

  if(parent_dir == -1) {
    shared_unlock(&inodes_lock);
    printf("no such dir \n");
    return ERROR;
  }

  if((inode = find_file(parent_dir, filename)) == -1){
    shared_unlock(&inodes_lock);
    printf("bad filename\n");
    return ERROR;
  }
  t=0;
  inode = resolve_symlink(inode, &t);
  if (inode == -1) {
    shared_unlock(&inodes_lock);
    printf("bad symlink\n");
    return ERROR;
  }
  t = inodes[inode].filesize;
  shared_unlock(&inodes_lock);
  return t;
}

int fs_sync(){
  int i;
  save_inodes();
  for(i = 0; i < BITVEC_SIZE/BLOCK_SIZE; i ++)
    cache_write_block(i+2, block_bitvec + i*BLOCK_SIZE, BLOCK_SIZE);
  cache_sync();
  return SUCCESS;
}
