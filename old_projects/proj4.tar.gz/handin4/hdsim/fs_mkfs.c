#include "buffercache.h"
#include "bitvec.h"
#include "../inc/disk.h"
#include "../inc/common.h"

/* This is the format:
   0:    untouched (boot sector);
   1:    Superblock
   2-6:  bitmap_vector
   7-N:  inodes (N ~ 6+i/1k)
 N+1-oo: userblocks and block index tables
*/



int fs_mkfs(int max) {
  int i, t;
  // Check that max_inodes is compatible with the current disk size
  // and that max_inodes is in the range 0-8192
	
  superblock.max_inodes = max;
  i = sizeof(inode_t)*superblock.max_inodes;
  t = 6+i/BLOCK_SIZE+(i%BLOCK_SIZE==0 ? 0 : 1);

  // block_bitvec (4k) is a bit vector indicating which blocks are free, and which ones aren't.
  // first block is super block, next 4 are block_bitvec
  for (i=0; i<t; i++)
    bitmap_set(block_bitvec, i, 1);
  for (i=t; i<BITVEC_SIZE*8; i++)
    bitmap_set(block_bitvec, i, 0);
	
  cache_write_block(1, (char*) &superblock, sizeof(superblock_t));
  for(i = 0; i < BITVEC_SIZE/BLOCK_SIZE; i ++)
    cache_write_block(i+2, block_bitvec + i*BLOCK_SIZE, BLOCK_SIZE);

  // First inode is the root inode. Points to an empty directory.
  inodes[0].type = DIRECTORY;
  strncpy(inodes[0].name, "root", MAXFILENAMESIZE);
  inodes[0].name[MAXFILENAMESIZE-1] = 0; // cos strncpy doesn't always zero-terminate

  inodes[0].filesize = 0;
  inodes[0].prev_file = -1;
  inodes[0].next_file = -1;
  inodes[0].child = -1;
  inodes[0].parent = 0; //the parent of root dir is itself.
  inodes[0].block_index = -1;
	
  // Mark all other as free
  for (i=1; i<superblock.max_inodes; i++) {
    inodes[i].type = FREEINODE;
  }
  save_inodes();


  return SUCCESS;
}

// superblock should be set before calling this function
void save_inodes() {
  int num = sizeof(inode_t)*superblock.max_inodes;
  int block_num = 6;
  char* source = (char*) inodes;
  int offset = MIN(num, BLOCK_SIZE);
  int remainder = num - offset;
  while(offset > 0){
    cache_write_block(block_num, source, offset);
    block_num++;
    num -= offset;
    source += offset;
    offset = MIN(num, BLOCK_SIZE);
    remainder = num - offset;
  }
}
