#ifndef __BUFFER_CACHE_
#define __BUFFER_CACHE_
#include "hdsim.h"
#include "lock3.h"
#include "filesystem.h"

#define CACHESIZE 128
#define BLOCKS_PER_SECTOR 2
#define INT_MAX 0x7fffffff

typedef struct _hippo_buffer_cache {
  int dirty:1; // written to?
  int p:1; // valid?
  lock3_t lock; // shared mutex
  int block_num; // the cached block number
  unsigned int accessstamp; // the last "time" at which this line was accessed
  char cache[BLOCK_SIZE];  // the actual line
} cache_line_t;

int cache_init(void);

void cache_write_bytes(int block_num, char* source, int num);
void cache_read_bytes(int block_num, char* dest, int num);

void cache_write_block(int block_num, char* source, int num);

void cache_read_block(int block_num, char* dest, int num);

int get_num_blocks(void);

void cache_sync(void);
#endif
