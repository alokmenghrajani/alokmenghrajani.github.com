#include "lock3.h"
#include "../inc/common.h"
/*********** this is shit */

void sys_yield(){
  return;
}
void enable_interrupts(){
  return;
}

void disable_interrupts(){
  return;
}


/***************/


void init_lock3(lock3_t* lock){
  lock -> flag = 0;
  lock -> counter = 0;
}

void shared_lock(lock3_t* lock){
  int locked = 0;
  int deadlock_det = 0;
  while(!locked){
    disable_interrupts();
    if(lock -> flag == 0){
      (lock -> counter)++;
      locked = 1;
    }
    enable_interrupts();
    sys_yield();
    deadlock_det++;
    if (deadlock_det==100) {
      printf("Potential deadlock !\n");
    }
  }
}

void shared_unlock(lock3_t* lock){
  disable_interrupts();
  (lock->counter)--;
	ASSERT(lock->counter>=0);
  enable_interrupts();
}

void exc_lock(lock3_t* lock){
  int locked = 0;
  int deadlock_det = 0;
  while(!locked){
    disable_interrupts();
    if(lock -> flag == 0 && lock -> counter ==0){
      locked = 1;
      lock -> flag = 1;
    }
    enable_interrupts();
    sys_yield();
    deadlock_det++;
    if (deadlock_det==100) {
      printf("Potential deadlock !\n");
    }
  }

}

void exc_unlock(lock3_t* lock){
  disable_interrupts();
  ASSERT(lock->flag == 1);
  ASSERT(lock->counter == 0);
  lock->flag = 0;
  enable_interrupts();
}

// Get an exc_lock if possible, otherwise return 0 (doesn't block)
int exc_lock_maybe(lock3_t* lock) {
  disable_interrupts();
  if (lock->flag == 0 && lock->counter == 0) {
    lock->flag = 1;
    return 1;
  }
  return 0;
  enable_interrupts();
}


/*
	Takes a shared_lock and promotes it to a exc_lock
*/

/* end of nice little dream....
void promote_lock(lock3_t* lock) {
  int locked = 0;
  while(!locked){
    disable_interrupts();
    if(lock -> flag == 0 && lock -> counter == 1){
      locked = 1;
      lock -> flag = 1;
      lock -> counter = 0;
    }
    enable_interrupts();
    sys_yield();
  }
}
*/


void demote_lock(lock3_t* lock) {
  disable_interrupts();
  ASSERT(lock->flag == 1);
  ASSERT(lock->counter == 0);
  lock->flag = 0;
  lock->counter = 1;
  enable_interrupts();
}


