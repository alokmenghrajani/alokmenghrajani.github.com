#ifndef _LOCK3_H__
#define _LOCK3_H__

typedef struct _hippo_three_state_lock{
  int counter;
  int flag;
} lock3_t;

void init_lock3(lock3_t* lock);

void shared_lock(lock3_t* lock);

void shared_unlock(lock3_t* lock);

void exc_lock(lock3_t* lock);
int exc_lock_maybe(lock3_t* lock);

void exc_unlock(lock3_t* lock);

#endif
