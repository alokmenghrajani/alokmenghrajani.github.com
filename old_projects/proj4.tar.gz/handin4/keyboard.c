
/*

  keyboard.c: the C code for the keyboard driver for our 
  extra special operating system that beats Windows (tm) any day!

  Authors: Alok Menghrajani & Vikram Manjunath

 */
#include "keyboard.h"
#include "kernel.h"
#include "util.h"
#include "inc/x86_regs.h"
#include "idt.h"
#include "inc/keyhelp.h"
#include "inc/interrupts.h"
#include "inc/seg.h"
#include "inc/io_map.h"
#include "console.h"

static unsigned char keyboard_ring[RING_SIZE];

static int keyboard_read_ptr;
static int keyboard_write_ptr;


void keyboard_init() {
  /* Initialize the keyboard ptrs and install the handler */
  void* idt=sidt();
  struct idt_entry *entry;

  keyboard_read_ptr = 0;
  keyboard_write_ptr = 0;

  // Complete the KEY_IDT_ENTRY
  entry = (struct idt_entry*) idt;
  entry+=KEY_IDT_ENTRY;
  entry->hoffset = ((unsigned short int)(((unsigned int)keyboard_handler_wrapper)>>16));
  entry->P = 1;
  entry->DPL = 0; /* FIXME is this right ? Why ? */
  entry->D = 0xF; /* FIXME is this the right size ??? */
  entry->Ze = 0;
  entry->Seg = KERNEL_CS;
  entry->loffset = (unsigned short int) keyboard_handler_wrapper;
  return;
}

void keyboard_handler() {
  // Check if ring is full. Do nothing if full
  if (((keyboard_write_ptr+1) % RING_SIZE) != keyboard_read_ptr) {
    unsigned char c = inb(KEYBOARD_PORT);
    keyboard_ring[keyboard_write_ptr] = c;
    keyboard_write_ptr = (keyboard_write_ptr+1) % RING_SIZE;
  }

  // Acknowledge
  outb(INT_CTL_DONE, INT_CTL_REG);

  // Handle readline and getchar processes
  disable_interrupts();
  if(key_wait_queue != NULL){
    // Put VM memory if disabled, change the cr3 to the key_wait_queue's
    int cr0 = get_cr0();
    int cr3 = get_cr3();
    unsigned char c;

    c = readchar();
    if (c==0xff) {
      enable_interrupts();
      return;
    }
    
    SET_PG;
    set_cr3((int) key_wait_queue->ptd);
    if (key_wait_queue->key_buf!=NULL) {
      // readline case
      if (c == '\b') {
	if (key_wait_queue->key_buf_index>0) {
	// a backspace was hit
	key_wait_queue->key_buf_index--;
	putbytes(&c, 1);
	}
      } else {
	key_wait_queue->key_buf[key_wait_queue->key_buf_index++] = c;
	putbytes(&c, 1);
      }
      if ((c== '\n') || (key_wait_queue->key_buf_index==(key_wait_queue->key_buf_len-1))) {
	// we hit the end of line (minus one, because we are going to add a zero termination
	key_wait_queue->key_buf[key_wait_queue->key_buf_index] = NULL;
	SET_EAX(key_wait_queue, key_wait_queue->key_buf_index);
	// remove the bastard
	key_wait_queue->state = RUNNABLE;
	key_wait_queue->flags = NORMAL;
	key_wait_queue=key_wait_queue->next_key_waiting;
      }
    } else {
      // readchar case
      SET_EAX(key_wait_queue, c);
      // remove the bastard
      key_wait_queue->state = RUNNABLE;
      key_wait_queue->flags = NORMAL;
      key_wait_queue=key_wait_queue->next_key_waiting;
    }
    // VM stuff restore
    set_cr3(cr3);
    set_cr0(cr0);
  }
  enable_interrupts();
}

unsigned char readchar() {
  unsigned char c;
  /* Check to see if the ring is not empty */
  while (keyboard_read_ptr!=keyboard_write_ptr) {
    c = keyboard_ring[keyboard_read_ptr];
    keyboard_read_ptr=(keyboard_read_ptr + 1) % RING_SIZE;

    c=process_scancode(c);
    if (c!=0xff)
      return c;
  }
  return 0xff;
}
