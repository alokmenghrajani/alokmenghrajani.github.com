///////////////////////////////////////////////////////////////////////////
//
// Name: Kernel.c
// Date: Today
// Author: amenghra & vikramm
//
// Description: Self-descriptif
// 
//
///////////////////////////////////////////////////////////////////////////

#ifndef KERNEL__H
#define KERNEL__H


#define MACHINE_MEMORY_SIZE_MB 256
#define KERNEL_STACK_SIZE 16384


// PCB (process control block)
// Our PCB reside in the top of the process' kernel stack.
// Which (the kernel stack) can be accessed directly (unlike in Linux where
// an and operation is required) since we know that it resides in 16MB + 4KB

#define RUNNING 0
#define RUNNABLE -1
#define STOPPED 1



// #define GET_KS_TOP(a) ((((int)(a) / KERNEL_STACK_SIZE) * KERNEL_STACK_SIZE) + KERNEL_STACK_SIZE)

// gets the pcb, a being any kernel stack pointer
// (by zeroing the lower bits and whatever)
#define GET_PCB(a) ((pcb_struct*)((((int)(a) / KERNEL_STACK_SIZE) * KERNEL_STACK_SIZE) + KERNEL_STACK_SIZE - sizeof(pcb_struct)))
#define SET_EAX(pcb, value) (*((int*)(pcb)-7) = (value))
#define CLEAR_PG {int i; i = get_cr0(); i = i & (~(1<<31)); set_cr0(i);}
#define SET_PG {int i; i = get_cr0(); set_cr0(i | (1 << 31));}


#define NEWBORN 2
#define SLEEPING 1
#define NORMAL 0
#define FORKING 3
#define WAITING 4
#define DESCHEDULED 5
#define KEY_WAITING 6
#define IO_WAITING 7

typedef unsigned int pid_t;
typedef int spinlock_t;
typedef unsigned int mem_t;

// Push data (as int) onto stack and decrement pointer by 4 bytes.
#define PUSH(sp, data) (*(--(int*)(sp))=(int)(data))
#define POP(sp) (*(((int*)(sp))++))

int next_pid;
int next_tgrp;

int getting_started_flag;


typedef struct _ptd_struct {
  unsigned int p:1;                 /* 1=Present */
  unsigned int rw:1;                /* 0=Read/1=Write (we want 1) */
  unsigned int us:1;                /* 1=User/0=Supervisor */
  unsigned int pwt:1;               /* 1=Write-through (we want 0) */
  unsigned int pcd:1;               /* 1=Cached disabled (we want 0) */
  unsigned int a:1;                 /* Accessed */
  unsigned int z:1;                 /* Reserved, set to 0 */
  unsigned int ps:1;                /* Page size, 0 indicates 4KB */
  unsigned int g:1;                 /* Global page (ignored) */
  unsigned int avail:3;             /* Available for us */
  unsigned int base:20;             /* Page-table Base Address */
} ptd_struct;

typedef struct _pt_struct {
  unsigned int p:1;                 /* 1=Present */
  unsigned int rw:1;                /* Read/Write */
  unsigned int us:1;                /* User/Supervisor */
  unsigned int pwt:1;               /* Write-through */
  unsigned int pcd:1;               /* Cached disabled */
  unsigned int a:1;                 /* Accessed */
  unsigned int d:1;                 /* Dirty */
  unsigned int pat:1;               /* Page Table Attribute Index */
  unsigned int g:1;                 /* 1=Global page */
  unsigned int avail:3;             /* Available for us */
  unsigned int base:20;             /* Page-table Base Address */
} pt_struct;

typedef struct _pcb_struct {
  volatile long state;              /* UNRUNNABLE, RUNNABLE or STOPPED */
  unsigned long flags;              /* per process flags:
                  			     SLEEPING, ZOMBIE, etc... NEW BORN
			            */
  unsigned long sleep_time;         /* time which you want to be sleeping till */
  struct _pcb_struct *next, *prev; /* links the linked list */
  int exit_code;       /* obvious */
  int * exit_code_ptr; /* if the parent is blocked, then put the value here */
  pid_t pid;
  pid_t tid;                       /* Thread group to know who shares memory with whom */
  mem_t mem_limit;                  /* Used by brk, top of the heap */
  ptd_struct *ptd;
  unsigned int num_children;                 /* how many children? */
  struct _pcb_struct* deadkids;     /* dead mofos whos asses you wanna reap */
  pid_t parent;                     /* Who's your daddy?? we have a pid_t so that we can 
				       know what the dealis if the parentis already dead*/
  struct _pcb_struct * next_key_waiting; /* waiting on keyboard input */
  char * key_buf;                   /* keyboard buffer */
  int key_buf_index;                /* index in the buffer */
  int key_buf_len;                   /* length of keyboard buffer */
  mem_t kesp;
  mem_t kebp;
  
  /* proj 4 */
  int fds; /* file descriptors */
  struct _pcb_struct* next_io_waiting; /* waiting on file io */
  int cur_inode;
} pcb_struct;



// queue for keyboard waiters
pcb_struct * key_wait_queue;


#endif /* KERNEL__H */
