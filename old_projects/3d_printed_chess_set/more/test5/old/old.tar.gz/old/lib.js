// The current piece
var piece = {
  render: 'mesh',
  base_resolution: 100,
  profile_resolution: 100,
  solid: {
    mesh: {
      buffer: null,
      vertices: null,
    },
    stl: {
      buffer: null,
      vertices: null,
    }
  },
};

function doKing() {
  debugger;
  // We create the crawn by extruding p.base_points

  var base_path = JSON.parse(JSON.stringify(this.base_points));
  var profile_path = JSON.parse(JSON.stringify(this.profile_points));

  // We need to move + resize open_path to fit inside [0, -0.5]-[1, 0.5]
  var bounds1 = getBounds(profile_path);
  var factor = 110; // TODO: iterate over piece_data.js's data?

  for (var i=0; i<profile_path.length; i++) {
    profile_path[i].x = (profile_path[i].x - bounds1.min_x) / factor;
    profile_path[i].y = -(profile_path[i].y - bounds1.min_y - bounds1.size_y/2) / factor;
  }

  // Resize base_path by the same factor. Center it.
  var bounds2 = getBounds(base_path);
  for (var i=0; i<base_path.length; i++) {
    base_path[i].x = (base_path[i].x - bounds2.center_x) / factor;
    base_path[i].y = (base_path[i].y - bounds2.center_y) / factor;
    base_path[i].x = base_path[i].x / bounds2.size_x * bounds1.size_x * 2;
    base_path[i].y = base_path[i].y / bounds2.size_x * bounds1.size_x * 2;
  }

  // We add an extra point, to close the path
  base_path[base_path.length] = base_path[0];

  return {
    mesh: mySolid1_mesh(base_path, profile_path),
    stl: mySolid1_full(base_path, profile_path),
  };

  debugger;
}

function setPiece(piece_name) {
  var p = PieceData[piece_name];
  // base_path refers to the DOM element
  base_path.setAttribute('d', p.base_svg);
  // profile_path refers to the DOM element
  profile_path.setAttribute('d', p.profile_svg);

  // Start scanning
/*  PathToPoints(base_path, piece.base_resolution, function(base_points) {
    PathToPoints(profile_path, piece.profile_resolution, function(profile_points) {
      console.log(JSON.stringify(profile_points));
      console.log(JSON.stringify(base_points));
      piece.solid = mySolid1(base_points, profile_points);
    });
  });*/
  if (piece.solid.mesh.buffer) {
    gl.deleteBuffer(piece.solid.mesh.buffer);
    piece.solid.mesh.buffer = null;
  }
  if (piece.solid.stl.buffer) {
    gl.deleteBuffer(piece.solid.stl.buffer);
    piece.solid.stl.buffer = null;
  }
  piece.solid = mySolid1(p.base_points, p.profile_points);
  if (p.custom) {
    p.custom();
  }

  return false;
}

/**
 * Given an array of points, returns information about the bounds.
 */
function getBounds(points) {
  var min_x = points[0].x;
  var max_x = points[0].x;
  var min_y = points[0].y;
  var max_y = points[0].y;
  for (var i=1; i<points.length; i++) {
    min_x = Math.min(min_x, points[i].x);
    max_x = Math.max(max_x, points[i].x);
    min_y = Math.min(min_y, points[i].y);
    max_y = Math.max(max_y, points[i].y);
  }
  var r = {min_x: min_x, max_x: max_x, min_y: min_y, max_y: max_y};
  r.size_x = max_x - min_x;
  r.size_y = max_y - min_y;
  r.center_x = (min_x + max_x) / 2;
  r.center_y = (min_y + max_y) / 2;
  return r;
}

/**
 * Does some resizing and then builds a solid by moving path1 along path2.
 *
 * path1 is resized based on the value of path2.x
 * path1's y value is based on path2.y.
 */
function mySolid1(base_path, profile_path) {
  base_path = JSON.parse(JSON.stringify(base_path));
  profile_path = JSON.parse(JSON.stringify(profile_path));

  // We need to move + resize open_path to fit inside [0, -0.5]-[1, 0.5]
  var bounds1 = getBounds(profile_path);
  var factor = 120; // TODO: iterate over piece_data.js's data?

  for (var i=0; i<profile_path.length; i++) {
    profile_path[i].x = (profile_path[i].x - bounds1.min_x) / factor;
    profile_path[i].y = -(profile_path[i].y - bounds1.min_y - bounds1.size_y/2) / factor;
  }

  // Resize base_path by the same factor. Center it.
  var bounds2 = getBounds(base_path);
  for (var i=0; i<base_path.length; i++) {
    base_path[i].x = (base_path[i].x - bounds2.center_x) / factor;
    base_path[i].y = (base_path[i].y - bounds2.center_y) / factor;
    base_path[i].x = base_path[i].x / bounds2.size_x * bounds1.size_x * 2;
    base_path[i].y = base_path[i].y / bounds2.size_x * bounds1.size_x * 2;
  }

  // We add an extra point, to close the path
  base_path[base_path.length] = base_path[0];

  return {
    mesh: mySolid1_mesh(base_path, profile_path),
    stl: mySolid1_full(base_path, profile_path),
  };
}

function mySolid1_full(base_path, profile_path) {  
  var pieceVertices = [];

  // Create vertices by "cloning" base path
  for (var i=0; i<profile_path.length-1; i++) {
    for (var j=0; j<base_path.length-1; j++) {
      // Render as triangles, by computing 4 points.
      // Triangles are P0-P1-P2 and P2-P1-P4
      var p0 = {
        x: base_path[j].x * (profile_path[i].x / profile_path[0].x),
        z: profile_path[i].y,
        y: base_path[j].y * (profile_path[i].x / profile_path[0].x)
      }

      var p1 = {
        x: base_path[j+1].x * (profile_path[i].x / profile_path[0].x),
        z: profile_path[i].y,
        y: base_path[j+1].y * (profile_path[i].x / profile_path[0].x)
      }

      var p2 = {
        x: base_path[j].x * (profile_path[i+1].x / profile_path[0].x),
        z: profile_path[i+1].y,
        y: base_path[j].y * (profile_path[i+1].x / profile_path[0].x)        
      }

      var p4 = {
        x: base_path[j+1].x * (profile_path[i+1].x / profile_path[0].x),
        z: profile_path[i+1].y,
        y: base_path[j+1].y * (profile_path[i+1].x / profile_path[0].x)
      }

      // build triangle P0-P1-P2
      pieceVertices.push(p0.x, p0.y, p0.z);
      pieceVertices.push(p1.x, p1.y, p1.z);
      pieceVertices.push(p2.x, p2.y, p2.z);

      // build triangle P2-P1-P4
      pieceVertices.push(p2.x, p2.y, p2.z);
      pieceVertices.push(p1.x, p1.y, p1.z);
      pieceVertices.push(p4.x, p4.y, p4.z);
    }
  }

  // Put bottom cap
  for (var j=0; j<base_path.length-1; j++) {
    var p0 = {
      x: base_path[j].x * (profile_path[0].x / profile_path[0].x),
      z: profile_path[0].y,
      y: base_path[j].y * (profile_path[0].x / profile_path[0].x)
    }

    var p1 = {
      x: base_path[j+1].x * (profile_path[0].x / profile_path[0].x),
      z: profile_path[0].y,
      y: base_path[j+1].y * (profile_path[0].x / profile_path[0].x)
    }

    var p2 = {
      x: 0,
      z: profile_path[0].y,
      y: 0
    }
    pieceVertices.push(p2.x, p2.y, p2.z);
    pieceVertices.push(p1.x, p1.y, p1.z);
    pieceVertices.push(p0.x, p0.y, p0.z);
  }

  // And top cap
  for (var j=0; j<base_path.length-1; j++) {
    var p0 = {
      x: base_path[j].x * (profile_path[profile_path.length-1].x / profile_path[0].x),
      z: profile_path[profile_path.length-1].y,
      y: base_path[j].y * (profile_path[profile_path.length-1].x / profile_path[0].x)
    }

    var p1 = {
      x: base_path[j+1].x * (profile_path[profile_path.length-1].x / profile_path[0].x),
      z: profile_path[profile_path.length-1].y,
      y: base_path[j+1].y * (profile_path[profile_path.length-1].x / profile_path[0].x)
    }

    var p2 = {
      x: 0,
      z: profile_path[profile_path.length-1].y,
      y: 0
    }
    pieceVertices.push(p2.x, p2.y, p2.z);
    pieceVertices.push(p0.x, p0.y, p0.z);
    pieceVertices.push(p1.x, p1.y, p1.z);
  }  

  var fullBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, fullBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pieceVertices), gl.STATIC_DRAW);
  fullBuffer.itemSize = 3;
  fullBuffer.numItems = pieceVertices.length/3;
  return {
    buffer: fullBuffer,
    vertices: pieceVertices,
  };
}

function saveStl() {
  var r = "";
  r += "solid pawn\n";
  for (var i=0; i<piece.fullVertices.length;) {
    var p0 = {};
    p0.x = piece.fullVertices[i++] * 50;
    p0.y = piece.fullVertices[i++] * 50;
    p0.z = piece.fullVertices[i++] * 50;
    
    var p1 = {}
    p1.x = piece.fullVertices[i++] * 50;
    p1.y = piece.fullVertices[i++] * 50;
    p1.z = piece.fullVertices[i++] * 50;
    
    var p2 = {}
    p2.x = piece.fullVertices[i++] * 50;
    p2.y = piece.fullVertices[i++] * 50;
    p2.z = piece.fullVertices[i++] * 50;

    var u = {
      x: p0.x - p1.x,
      y: p0.y - p1.y,
      z: p0.z - p1.z
    };
    var v = {
      x: p1.x - p2.x,
      y: p1.y - p2.y,
      z: p1.z - p2.z
    };
    var n = {
      x: -u.y * v.z + u.z * v.y,
      y: -u.z * v.x + u.x * v.z,
      z: -u.x * v.y + u.y * v.x
    };
    n = {x: 0, y: 0, z: 0};

    r += "facet normal " + n.x + " " + n.y + " " + n.z + "\n";
    r += "outer loop\n";
    r += "vertex " + p0.x + " " + p0.y + " " + p0.z + "\n";
    r += "vertex " + p1.x + " " + p1.y + " " + p1.z + "\n";
    r += "vertex " + p2.x + " " + p2.y + " " + p2.z + "\n";
    r += "endloop\n";
    r += "endfacet\n";
  }
  r += "endsolid\n";

  window.webkitRequestFileSystem(TEMPORARY, 100*1024*1024, function(fs) {
    fs.root.getFile('pawn'+Math.random()+'.stl', {create: true}, function(fileEntry) {
      fileEntry.createWriter(function(fileWriter) {
        fileWriter.onwriteend = function(e) {
          console.log('Write completed.');
          console.log(e);
          console.log(fileEntry.toURL());
        };
        // Create a new Blob and write it to log.txt.
        var blob = new Blob([r], {type: 'text/plain'});
        fileWriter.write(blob);
      }, console.error.bind(console));
    }, console.error.bind(console));
  }, console.error.bind(console));
}

function mySolid1_mesh(base_path, profile_path) {  
  var pieceVertices = [];

  // Create vertices by "cloning" base path
  for (var i=0; i<profile_path.length; i++) {
    for (var j=0; j<base_path.length-1; j++) {
      // For now, vertices will be rendered as lines, so we need to compute two
      // points. Once we switch to triangles, we'll have to compute 4 points.

      var p0 = {
        x: base_path[j].x * (profile_path[i].x / profile_path[0].x),
        z: profile_path[i].y,
        y: base_path[j].y * (profile_path[i].x / profile_path[0].x)
      }

      var p1 = {
        x: base_path[j+1].x * (profile_path[i].x / profile_path[0].x),
        z: profile_path[i].y,
        y: base_path[j+1].y * (profile_path[i].x / profile_path[0].x)
      }

      // build line P0-P1
      pieceVertices.push(p0.x, p0.y, p0.z);
      pieceVertices.push(p1.x, p1.y, p1.z);
    }
  }

  var fullBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, fullBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pieceVertices), gl.STATIC_DRAW);
  fullBuffer.itemSize = 3;
  fullBuffer.numItems = pieceVertices.length/3;
  return {
    buffer: fullBuffer,
    vertices: pieceVertices
  };
}

// Lots more webgl boiler plate.

var gl;
function initGL(canvas) {
  try {
    gl = canvas.getContext("experimental-webgl");
    gl.viewportWidth = canvas.width;
    gl.viewportHeight = canvas.height;
  } catch (e) {
  }
  if (!gl) {
    alert("Could not initialise WebGL, sorry :-(");
  }
}

function getShader(gl, id) {
  var shaderScript = document.getElementById(id);
  if (!shaderScript) {
    return null;
  }

  var str = "";
  var k = shaderScript.firstChild;
  while (k) {
    if (k.nodeType == 3) {
      str += k.textContent;
    }
    k = k.nextSibling;
  }

  var shader;
  if (shaderScript.type == "x-shader/x-fragment") {
      shader = gl.createShader(gl.FRAGMENT_SHADER);
  } else if (shaderScript.type == "x-shader/x-vertex") {
      shader = gl.createShader(gl.VERTEX_SHADER);
  } else {
      return null;
  }

  gl.shaderSource(shader, str);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert(gl.getShaderInfoLog(shader));
    return null;
  }

  return shader;
}

var shaderProgram;

function initShaders() {
  var fragmentShader = getShader(gl, "shader-fs");
  var vertexShader = getShader(gl, "shader-vs");

  shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  gl.linkProgram(shaderProgram);

  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
      alert("Could not initialise shaders");
  }

  gl.useProgram(shaderProgram);

  shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
  gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

  shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
  shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
}

var mvMatrix = mat4.create();
var pMatrix = mat4.create();

function setMatrixUniforms() {
  gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
  gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}

// Keeps track of the mouse related angle
var pos = mat4.create();
mat4.identity(pos);

function drawScene() {
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    mat4.perspective(45, gl.viewportWidth / gl.viewportHeight, 0.1, 100.0, pMatrix);

    mat4.identity(mvMatrix);

    // Setup camera 
    mat4.translate(mvMatrix, [0, 0.0, -2.0]);
    mat4.rotate(mvMatrix, -1.13, [1, 0, 0]);

    // Mouse induced rotation
    var newRotationMatrix = mat4.create();
    mat4.identity(newRotationMatrix);
    mat4.rotate(pos, lastMouseDX * 0.002, [0, 0, 1]);
    mat4.rotate(newRotationMatrix, lastMouseDY * 0.002, [1, 0, 0]);
    mat4.multiply(newRotationMatrix, pos, pos);
    mat4.multiply(mvMatrix, pos);

    if ((piece.render == "mesh") && piece.solid.mesh.buffer) {
      gl.bindBuffer(gl.ARRAY_BUFFER, piece.solid.mesh.buffer);
      gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, piece.solid.mesh.buffer.itemSize, gl.FLOAT, false, 0, 0);
      setMatrixUniforms();
      gl.drawArrays(gl.LINES, 0, piece.solid.mesh.buffer.numItems);
    } else if ((piece.render == "stl") && piece.solid.stl.buffer) {
      gl.bindBuffer(gl.ARRAY_BUFFER, piece.solid.stl.buffer);
      gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, piece.solid.stl.buffer.itemSize, gl.FLOAT, false, 0, 0);
      setMatrixUniforms();
      gl.drawArrays(gl.TRIANGLES, 0, piece.solid.stl.buffer.numItems);   
    }
}

function tick() {
  // make sure we come back here for the next frame
  requestAnimFrame(tick);

  // draw everything
  drawScene();
}

var mouseDown = false;
var lastMouseX = null;
var lastMouseY = null;
var lastMouseDX = 10;
var lastMouseDY = 0;
var lastMouseDownX = null;
var lastMouseDownY = null;

function handleMouseDown(event) {
  mouseDown = true;
  lastMouseX = event.clientX;
  lastMouseY = event.clientY;
  lastMouseDownX = event.clientX;
  lastMouseDownY = event.clientY;
}

function handleMouseUp(event) {
  mouseDown = false;
  var newX = event.clientX;
  var newY = event.clientY;

  if (((newX - lastMouseDownX)*(newX - lastMouseDownX)
       + (newY - lastMouseDownY)*(newY - lastMouseDownY)) < 10) {
    // the mouse was released close to where it went down, so we'll
    // stop rotating things
    lastMouseDX = 0;
    lastMouseDY = 0;
  }
}

function handleMouseMove(event) {
  if (!mouseDown) {
    return;
  }
  var newX = event.clientX;
  var newY = event.clientY;

  lastMouseDX = newX - lastMouseX;
  lastMouseDY = newY - lastMouseY;
  lastMouseX = newX;
  lastMouseY = newY;
}

function webGLStart() {
  var canvas = document.getElementById("canvas");
  initGL(canvas);
  initShaders();

  // Handle mouse movements
  canvas.onmousedown = handleMouseDown;
  document.onmouseup = handleMouseUp;
  document.onmousemove = handleMouseMove;

  gl.clearColor(1.0, 1.0, 1.0, 1.0);
  gl.enable(gl.DEPTH_TEST);

  // load pawn as default piece
  setPiece('king');

  tick();
}
